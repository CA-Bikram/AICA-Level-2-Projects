package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.DpdpDatabase
import com.example.data.model.DpdpCategory
import com.example.data.repository.DpdpRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("DPDP Act 2023", appName)
  }

  @Test
  fun `repository contains all 45 provisions`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = DpdpDatabase.getDatabase(context)
    val repo = DpdpRepository(db.dpdpUserDao())

    assertEquals(45, repo.allSections.size)
    assertEquals(10, repo.chapters.size)
    assertTrue(repo.penaltyEntries.isNotEmpty())
    assertTrue(repo.glossaryItems.isNotEmpty())
  }

  @Test
  fun `search by section number works`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = DpdpDatabase.getDatabase(context)
    val repo = DpdpRepository(db.dpdpUserDao())

    val results = repo.searchSections("6")
    assertTrue(results.any { it.number == 6 })
    assertEquals("Consent", results.first { it.number == 6 }.title)
  }

  @Test
  fun `search by penalty keyword works`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = DpdpDatabase.getDatabase(context)
    val repo = DpdpRepository(db.dpdpUserDao())

    val results = repo.searchSections("250 Crore")
    assertTrue(results.isNotEmpty())
  }
}
