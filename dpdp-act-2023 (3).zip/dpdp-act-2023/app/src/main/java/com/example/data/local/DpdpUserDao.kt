package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.DpdpUserData
import kotlinx.coroutines.flow.Flow

@Dao
interface DpdpUserDao {
    @Query("SELECT * FROM dpdp_user_data")
    fun getAllUserData(): Flow<List<DpdpUserData>>

    @Query("SELECT * FROM dpdp_user_data WHERE sectionNumber = :sectionNumber")
    fun getUserData(sectionNumber: Int): Flow<DpdpUserData?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(data: DpdpUserData)

    @Query("UPDATE dpdp_user_data SET isBookmarked = :isBookmarked, updatedAt = :timestamp WHERE sectionNumber = :sectionNumber")
    suspend fun updateBookmark(sectionNumber: Int, isBookmarked: Boolean, timestamp: Long)

    @Query("UPDATE dpdp_user_data SET isRead = :isRead, updatedAt = :timestamp WHERE sectionNumber = :sectionNumber")
    suspend fun updateReadStatus(sectionNumber: Int, isRead: Boolean, timestamp: Long)

    @Query("UPDATE dpdp_user_data SET userNote = :note, updatedAt = :timestamp WHERE sectionNumber = :sectionNumber")
    suspend fun updateNote(sectionNumber: Int, note: String, timestamp: Long)
}
