package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Spellcheck
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.Spellcheck
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.viewmodel.NavigationDestination

@Composable
fun AppBottomBar(
    currentDestination: NavigationDestination,
    bookmarkedCount: Int,
    onNavigate: (NavigationDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier.testTag("app_bottom_bar"),
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        // Provisions (Home)
        NavigationBarItem(
            selected = currentDestination == NavigationDestination.HOME,
            onClick = { onNavigate(NavigationDestination.HOME) },
            icon = {
                Icon(
                    imageVector = if (currentDestination == NavigationDestination.HOME) Icons.Filled.ListAlt else Icons.Outlined.ListAlt,
                    contentDescription = "Provisions"
                )
            },
            label = {
                Text(
                    text = "Provisions",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = if (currentDestination == NavigationDestination.HOME) FontWeight.Bold else FontWeight.Normal
                )
            },
            modifier = Modifier.testTag("nav_provisions")
        )

        // Chapters
        NavigationBarItem(
            selected = currentDestination == NavigationDestination.CHAPTERS,
            onClick = { onNavigate(NavigationDestination.CHAPTERS) },
            icon = {
                Icon(
                    imageVector = if (currentDestination == NavigationDestination.CHAPTERS) Icons.Filled.Folder else Icons.Outlined.Folder,
                    contentDescription = "Chapters"
                )
            },
            label = {
                Text(
                    text = "Chapters",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = if (currentDestination == NavigationDestination.CHAPTERS) FontWeight.Bold else FontWeight.Normal
                )
            },
            modifier = Modifier.testTag("nav_chapters")
        )

        // Bookmarks
        NavigationBarItem(
            selected = currentDestination == NavigationDestination.BOOKMARKS,
            onClick = { onNavigate(NavigationDestination.BOOKMARKS) },
            icon = {
                if (bookmarkedCount > 0) {
                    BadgedBox(
                        badge = {
                            Badge(containerColor = MaterialTheme.colorScheme.primary) {
                                Text("$bookmarkedCount", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (currentDestination == NavigationDestination.BOOKMARKS) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Bookmarks"
                        )
                    }
                } else {
                    Icon(
                        imageVector = if (currentDestination == NavigationDestination.BOOKMARKS) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "Bookmarks"
                    )
                }
            },
            label = {
                Text(
                    text = "Bookmarks",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = if (currentDestination == NavigationDestination.BOOKMARKS) FontWeight.Bold else FontWeight.Normal
                )
            },
            modifier = Modifier.testTag("nav_bookmarks")
        )

        // Penalties (The Schedule)
        NavigationBarItem(
            selected = currentDestination == NavigationDestination.PENALTIES,
            onClick = { onNavigate(NavigationDestination.PENALTIES) },
            icon = {
                Icon(
                    imageVector = if (currentDestination == NavigationDestination.PENALTIES) Icons.Filled.Gavel else Icons.Outlined.Gavel,
                    contentDescription = "Penalties"
                )
            },
            label = {
                Text(
                    text = "Penalties",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = if (currentDestination == NavigationDestination.PENALTIES) FontWeight.Bold else FontWeight.Normal
                )
            },
            modifier = Modifier.testTag("nav_penalties")
        )

        // Glossary
        NavigationBarItem(
            selected = currentDestination == NavigationDestination.GLOSSARY,
            onClick = { onNavigate(NavigationDestination.GLOSSARY) },
            icon = {
                Icon(
                    imageVector = if (currentDestination == NavigationDestination.GLOSSARY) Icons.Filled.Spellcheck else Icons.Outlined.Spellcheck,
                    contentDescription = "Glossary"
                )
            },
            label = {
                Text(
                    text = "Glossary",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = if (currentDestination == NavigationDestination.GLOSSARY) FontWeight.Bold else FontWeight.Normal
                )
            },
            modifier = Modifier.testTag("nav_glossary")
        )
    }
}
