package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.DpdpCategory
import com.example.data.model.DpdpChapter
import com.example.data.model.DpdpSection
import com.example.data.model.DpdpUserData
import com.example.data.model.LegalGlossaryItem
import com.example.data.model.PenaltyEntry
import com.example.data.repository.DpdpRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

enum class FontScaleLevel(val scaleFactor: Float, val label: String) {
    NORMAL(1.0f, "Standard"),
    LARGE(1.15f, "Large"),
    EXTRA_LARGE(1.3f, "XL")
}

enum class NavigationDestination {
    HOME,
    CHAPTERS,
    BOOKMARKS,
    PENALTIES,
    GLOSSARY,
    SECTION_DETAIL
}

enum class DetailViewMode(val title: String) {
    COMPREHENSIVE("All In One"),
    SIMPLIFIED("Simplified & Examples"),
    BARE_ACT("Bare Act Language")
}

data class DpdpUiState(
    val currentDestination: NavigationDestination = NavigationDestination.HOME,
    val selectedSectionNumber: Int? = null,
    val searchQuery: String = "",
    val selectedCategory: DpdpCategory = DpdpCategory.ALL,
    val selectedChapterFilter: Int? = null,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val fontScale: FontScaleLevel = FontScaleLevel.NORMAL,
    val detailViewMode: DetailViewMode = DetailViewMode.COMPREHENSIVE,
    val noteDraft: String = "",
    val isNoteEditing: Boolean = false
)

class DpdpViewModel(
    private val repository: DpdpRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DpdpUiState())
    val uiState: StateFlow<DpdpUiState> = _uiState.asStateFlow()

    val chapters: List<DpdpChapter> = repository.chapters
    val glossaryItems: List<LegalGlossaryItem> = repository.glossaryItems
    val penaltyEntries: List<PenaltyEntry> = repository.penaltyEntries
    val allSections: List<DpdpSection> = repository.allSections

    val bookmarkedSectionNumbers: StateFlow<Set<Int>> = repository.bookmarkedSectionNumbers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val readSectionNumbers: StateFlow<Set<Int>> = repository.readSectionNumbers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val allUserData: StateFlow<List<DpdpUserData>> = repository.allUserData
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Reactive filtered sections
    val filteredSections: StateFlow<List<DpdpSection>> = combine(
        _uiState,
        bookmarkedSectionNumbers
    ) { state, bookmarks ->
        val onlyBookmarked = state.currentDestination == NavigationDestination.BOOKMARKS
        repository.searchSections(
            query = state.searchQuery,
            categoryFilter = state.selectedCategory,
            chapterFilter = state.selectedChapterFilter,
            onlyBookmarked = onlyBookmarked,
            bookmarkedSet = bookmarks
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), repository.allSections)

    fun navigateTo(destination: NavigationDestination, sectionNumber: Int? = null) {
        _uiState.value = _uiState.value.copy(
            currentDestination = destination,
            selectedSectionNumber = sectionNumber ?: _uiState.value.selectedSectionNumber,
            isNoteEditing = false
        )
        if (sectionNumber != null) {
            // Load current note for this section
            viewModelScope.launch {
                val existing = allUserData.value.find { it.sectionNumber == sectionNumber }
                _uiState.value = _uiState.value.copy(
                    noteDraft = existing?.userNote ?: ""
                )
            }
        }
    }

    fun openSection(sectionNumber: Int) {
        val existing = allUserData.value.find { it.sectionNumber == sectionNumber }
        _uiState.value = _uiState.value.copy(
            selectedSectionNumber = sectionNumber,
            currentDestination = NavigationDestination.SECTION_DETAIL,
            noteDraft = existing?.userNote ?: "",
            isNoteEditing = false
        )
    }

    fun selectChapterFromList(chapterId: Int) {
        _uiState.value = _uiState.value.copy(
            selectedChapterFilter = chapterId,
            currentDestination = NavigationDestination.HOME
        )
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun setCategory(category: DpdpCategory) {
        _uiState.value = _uiState.value.copy(selectedCategory = category)
    }

    fun setChapterFilter(chapterId: Int?) {
        _uiState.value = _uiState.value.copy(selectedChapterFilter = chapterId)
    }

    fun clearFilters() {
        _uiState.value = _uiState.value.copy(
            searchQuery = "",
            selectedCategory = DpdpCategory.ALL,
            selectedChapterFilter = null
        )
    }

    fun toggleTheme() {
        val next = when (_uiState.value.themeMode) {
            ThemeMode.SYSTEM -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.DARK
            ThemeMode.DARK -> ThemeMode.SYSTEM
        }
        _uiState.value = _uiState.value.copy(themeMode = next)
    }

    fun cycleFontScale() {
        val next = when (_uiState.value.fontScale) {
            FontScaleLevel.NORMAL -> FontScaleLevel.LARGE
            FontScaleLevel.LARGE -> FontScaleLevel.EXTRA_LARGE
            FontScaleLevel.EXTRA_LARGE -> FontScaleLevel.NORMAL
        }
        _uiState.value = _uiState.value.copy(fontScale = next)
    }

    fun setDetailViewMode(mode: DetailViewMode) {
        _uiState.value = _uiState.value.copy(detailViewMode = mode)
    }

    fun toggleBookmark(sectionNumber: Int) {
        viewModelScope.launch {
            val isBookmarked = bookmarkedSectionNumbers.value.contains(sectionNumber)
            repository.toggleBookmark(sectionNumber, isBookmarked)
        }
    }

    fun toggleReadStatus(sectionNumber: Int) {
        viewModelScope.launch {
            val isRead = readSectionNumbers.value.contains(sectionNumber)
            repository.toggleReadStatus(sectionNumber, isRead)
        }
    }

    fun updateNoteDraft(text: String) {
        _uiState.value = _uiState.value.copy(noteDraft = text)
    }

    fun toggleNoteEditing(editing: Boolean) {
        _uiState.value = _uiState.value.copy(isNoteEditing = editing)
    }

    fun saveCurrentNote(sectionNumber: Int) {
        viewModelScope.launch {
            val isBookmarked = bookmarkedSectionNumbers.value.contains(sectionNumber)
            val isRead = readSectionNumbers.value.contains(sectionNumber)
            repository.saveUserNote(sectionNumber, _uiState.value.noteDraft, isBookmarked, isRead)
            _uiState.value = _uiState.value.copy(isNoteEditing = false)
        }
    }

    fun getSection(number: Int?): DpdpSection? {
        if (number == null) return null
        return repository.getSectionByNumber(number)
    }

    fun getPreviousSection(currentNumber: Int): DpdpSection? {
        return repository.getSectionByNumber(currentNumber - 1)
    }

    fun getNextSection(currentNumber: Int): DpdpSection? {
        return repository.getSectionByNumber(currentNumber + 1)
    }

    class Factory(private val repository: DpdpRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(DpdpViewModel::class.java)) {
                return DpdpViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
