package com.example.data.repository

import com.example.data.local.DpdpUserDao
import com.example.data.model.DpdpCategory
import com.example.data.model.DpdpChapter
import com.example.data.model.DpdpSection
import com.example.data.model.DpdpUserData
import com.example.data.model.LegalGlossaryItem
import com.example.data.model.PenaltyEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class DpdpRepository(
    private val userDao: DpdpUserDao
) {
    // All 45 sections (Sections 1 to 44 + The Schedule)
    val allSections: List<DpdpSection> by lazy {
        DpdpSectionsDataPart1.sections +
        DpdpSectionsDataPart2.sections +
        DpdpSectionsDataPart3.sections +
        DpdpSectionsDataPart4.sections
    }

    val chapters: List<DpdpChapter> = DpdpChaptersData.chapters
    val glossaryItems: List<LegalGlossaryItem> = DpdpGlossaryData.items
    val penaltyEntries: List<PenaltyEntry> = DpdpPenaltiesData.entries

    val allUserData: Flow<List<DpdpUserData>> = userDao.getAllUserData()

    val bookmarkedSectionNumbers: Flow<Set<Int>> = userDao.getAllUserData().map { list ->
        list.filter { it.isBookmarked }.map { it.sectionNumber }.toSet()
    }

    val readSectionNumbers: Flow<Set<Int>> = userDao.getAllUserData().map { list ->
        list.filter { it.isRead }.map { it.sectionNumber }.toSet()
    }

    fun getUserDataForSection(sectionNumber: Int): Flow<DpdpUserData?> {
        return userDao.getUserData(sectionNumber)
    }

    suspend fun toggleBookmark(sectionNumber: Int, currentlyBookmarked: Boolean) {
        val now = System.currentTimeMillis()
        userDao.insertOrUpdate(
            DpdpUserData(
                sectionNumber = sectionNumber,
                isBookmarked = !currentlyBookmarked,
                updatedAt = now
            )
        )
    }

    suspend fun toggleReadStatus(sectionNumber: Int, currentlyRead: Boolean) {
        val now = System.currentTimeMillis()
        userDao.insertOrUpdate(
            DpdpUserData(
                sectionNumber = sectionNumber,
                isRead = !currentlyRead,
                updatedAt = now
            )
        )
    }

    suspend fun saveUserNote(sectionNumber: Int, note: String, isBookmarked: Boolean = false, isRead: Boolean = false) {
        val now = System.currentTimeMillis()
        userDao.insertOrUpdate(
            DpdpUserData(
                sectionNumber = sectionNumber,
                isBookmarked = isBookmarked,
                isRead = isRead,
                userNote = note,
                updatedAt = now
            )
        )
    }

    fun getSectionByNumber(number: Int): DpdpSection? {
        return allSections.find { it.number == number }
    }

    /**
     * Comprehensive Search Engine:
     * Searches across:
     * 1. Section Number (e.g. "6", "Sec 9", "Section 33")
     * 2. Section Title
     * 3. Chapter Title
     * 4. Bare Act Text
     * 5. Simplified Explanation
     * 6. Practical Examples (title, scenario, analysis)
     * 7. Key Takeaways
     */
    fun searchSections(
        query: String,
        categoryFilter: DpdpCategory = DpdpCategory.ALL,
        chapterFilter: Int? = null,
        onlyBookmarked: Boolean = false,
        bookmarkedSet: Set<Int> = emptySet()
    ): List<DpdpSection> {
        val trimmed = query.trim()
        val lower = trimmed.lowercase()

        // Extract potential section number from queries like "sec 6", "s 6", "section 9", "6"
        val secNumRegex = Regex("""(?:sec(?:tion)?\s*|s\s*)?(\d+)""", RegexOption.IGNORE_CASE)
        val extractedSecNum = secNumRegex.matchEntire(trimmed)?.groupValues?.get(1)?.toIntOrNull()

        return allSections.filter { section ->
            // Category filter
            if (categoryFilter != DpdpCategory.ALL && section.category != categoryFilter) {
                return@filter false
            }

            // Chapter filter
            if (chapterFilter != null && section.chapterId != chapterFilter) {
                return@filter false
            }

            // Bookmark filter
            if (onlyBookmarked && !bookmarkedSet.contains(section.number)) {
                return@filter false
            }

            // Text search
            if (trimmed.isEmpty()) {
                return@filter true
            }

            // Direct section number match
            if (extractedSecNum != null && section.number == extractedSecNum) {
                return@filter true
            }

            // Title and label match
            if (section.title.lowercase().contains(lower) ||
                section.sectionLabel.lowercase().contains(lower) ||
                section.chapterName.lowercase().contains(lower)
            ) {
                return@filter true
            }

            // Bare act text match
            if (section.bareActText.lowercase().contains(lower)) {
                return@filter true
            }

            // Simplified explanation match
            if (section.simplifiedExplanation.lowercase().contains(lower)) {
                return@filter true
            }

            // Key takeaways match
            if (section.keyTakeaways.any { it.lowercase().contains(lower) }) {
                return@filter true
            }

            // Practical examples match
            if (section.practicalExamples.any {
                    it.title.lowercase().contains(lower) ||
                    it.industry.lowercase().contains(lower) ||
                    it.scenario.lowercase().contains(lower) ||
                    it.complianceAnalysis.lowercase().contains(lower)
                }
            ) {
                return@filter true
            }

            false
        }
    }
}
