package com.example.data.repository

import com.example.data.model.DpdpCategory
import com.example.data.model.DpdpSection
import com.example.data.model.PracticalExample

object DpdpSectionsDataPart2 {
    val sections: List<DpdpSection> = listOf(
        DpdpSection(
            number = 11,
            sectionLabel = "Section 11",
            title = "Right to access information about personal data",
            chapterId = 3,
            chapterName = "CHAPTER III: RIGHTS AND DUTIES OF DATA PRINCIPAL",
            category = DpdpCategory.RIGHTS_OF_PRINCIPAL,
            bareActText = """
11. (1) The Data Principal shall have the right to obtain from the Data Fiduciary to whom she has previously given consent, or in respect of whom certain legitimate uses have been applied, upon making an application in such manner as may be prescribed,—
(a) a summary of personal data which is being processed by such Data Fiduciary and the processing activities undertaken by that Data Fiduciary with respect to such personal data;
(b) the identities of all other Data Fiduciaries and Data Processors with whom the personal data has been shared by such Data Fiduciary, along with a description of the personal data so shared; and
(c) any other information related to the personal data of such Data Principal and its processing, as may be prescribed.

(2) Nothing contained in clause (b) or clause (c) of sub-section (1) shall apply in respect of the sharing of any personal data by a Data Fiduciary with any other Data Fiduciary authorized by law for prevention or detection or investigation of offenses or cyber incidents, or for prosecution or punishment of offenses.
            """.trimIndent(),
            simplifiedExplanation = """
• Citizen's Right to Know: Any user who consented to data processing has the legal right to ask the company:
  1. What personal data do you hold on me, and what are you doing with it?
  2. Who have you shared my data with? (Names of third parties, advertisers, analytics vendors, and processors).
  3. A concise summary of all processing activities.
• Law Enforcement Exception: If a company shared data with cyber police or intelligence agencies under a legal warrant, they cannot disclose that to the user under Section 11(2).
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "User Requesting Third-Party Sharing Details",
                    industry = "Telecommunications / Apps",
                    scenario = "A user suspects a fitness app sold their health metrics to health insurance brokers.",
                    complianceAnalysis = "Under Section 11(1)(b), the user can formally demand a list of all partners and processors the app shared their data with. The app must furnish this legally."
                )
            ),
            keyTakeaways = listOf(
                "Right to obtain summary of personal data held",
                "Right to know identities of all third-party recipients and processors",
                "Exception for lawful disclosures to police/security agencies"
            )
        ),
        DpdpSection(
            number = 12,
            sectionLabel = "Section 12",
            title = "Right to correction and erasure of personal data",
            chapterId = 3,
            chapterName = "CHAPTER III: RIGHTS AND DUTIES OF DATA PRINCIPAL",
            category = DpdpCategory.RIGHTS_OF_PRINCIPAL,
            bareActText = """
12. (1) A Data Principal shall have the right to correction, completion, updating and erasure of her personal data for the processing of which she has previously given consent, or in respect of which certain legitimate uses have been applied, in accordance with any requirement or procedure under any law for the time being in force, by making an application in such manner as may be prescribed.
(2) A Data Fiduciary shall, upon receiving an application under sub-section (1),—
(a) correct the inaccurate or misleading personal data;
(b) complete the incomplete personal data;
(c) update the personal data; and
(d) erase the personal data that is no longer necessary for the purpose for which it was processed or for compliance with any law.
            """.trimIndent(),
            simplifiedExplanation = """
• Rectification & Updating: If an app has misspelled your name, outdated your address, or logged incorrect credit data, you have the right to have it corrected or updated.
• Right to Erasure ('Right to be Forgotten'): You can demand that a service provider permanently delete your personal data once you close your account or if the data is no longer necessary.
• Legal Retention Overrides: Companies can retain records if required by specific statutory laws (e.g., RBI requiring banks to keep transaction history for 5–10 years).
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Account Deletion on Food Delivery App",
                    industry = "Food Delivery",
                    scenario = "Priya uninstalls a food delivery app and emails their grievance officer requesting complete deletion of her account and saved delivery addresses.",
                    complianceAnalysis = "Under Section 12(2)(d), the food delivery app must erase her personal data from their production databases and backup servers within the prescribed timeframe."
                )
            ),
            keyTakeaways = listOf(
                "Right to correct inaccurate, misleading, or outdated personal data",
                "Right to complete incomplete records",
                "Right to erase personal data no longer necessary for purpose",
                "Retention permissible only where mandated by specific laws"
            )
        ),
        DpdpSection(
            number = 13,
            sectionLabel = "Section 13",
            title = "Right of grievance redressal",
            chapterId = 3,
            chapterName = "CHAPTER III: RIGHTS AND DUTIES OF DATA PRINCIPAL",
            category = DpdpCategory.RIGHTS_OF_PRINCIPAL,
            bareActText = """
13. (1) A Data Principal shall have the right of grievance redressal provided by a Data Fiduciary or Consent Manager in respect of any act or omission of such Data Fiduciary or Consent Manager regarding the performance of its obligations in relation to the personal data of such Data Principal or the exercise of her rights under the provisions of this Act or the rules made thereunder.
(2) The Data Fiduciary or Consent Manager shall respond to any grievances referred to in sub-section (1) within such period as may be prescribed from the date of receipt of the grievance.
(3) The Data Principal shall exhaust the opportunity of redressing her grievance under this section before approaching the Board.
            """.trimIndent(),
            simplifiedExplanation = """
• Accessible Internal Remedy: Every organization or Consent Manager MUST establish an easily accessible grievance redressal mechanism (email, ticket portal, contact officer).
• Mandatory Response Time: The company must respond to grievances within the statutory timeline prescribed in the rules.
• Exhaustion of Remedies: Before filing a complaint with the Data Protection Board of India, the citizen must first attempt to resolve it through the company's internal grievance redressal system.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Escalating from Company to Board",
                    industry = "Online Retail",
                    scenario = "A customer's data deletion request was ignored by an online store for 30 days.",
                    complianceAnalysis = "Having exhausted the company's grievance channel without resolution, the customer can now escalate a formal complaint to the Data Protection Board under Section 13(3)."
                )
            ),
            keyTakeaways = listOf(
                "Right to internal grievance redressal by company or Consent Manager",
                "Company must respond within prescribed timeframe",
                "User must first exhaust company redressal before filing with Board"
            )
        ),
        DpdpSection(
            number = 14,
            sectionLabel = "Section 14",
            title = "Right to nominate",
            chapterId = 3,
            chapterName = "CHAPTER III: RIGHTS AND DUTIES OF DATA PRINCIPAL",
            category = DpdpCategory.RIGHTS_OF_PRINCIPAL,
            bareActText = """
14. (1) A Data Principal shall have the right to nominate, in such manner as may be prescribed, any other individual, who shall, in the event of death or incapacity of the Data Principal, exercise the rights of the Data Principal in accordance with the provisions of this Act and the rules made thereunder.
(2) For the purposes of this section, the expression "incapacity" means inability to exercise the rights under this Act due to unsoundness of mind or body.
            """.trimIndent(),
            simplifiedExplanation = """
• Digital Legacy Planning: A Data Principal can legally nominate a trusted person (spouse, child, sibling, friend) to handle their digital accounts, health records, and privacy rights.
• Triggering Events: The nominee's powers activate in the event of:
  1. Death of the Data Principal; OR
  2. Incapacity (coma, severe medical disability, unsoundness of mind).
• Nominee Rights: The nominee can exercise the right to access, download memories, or order complete account erasure.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Deceased Family Member Social Account",
                    industry = "Social Media / Cloud Storage",
                    scenario = "A deceased user designated her brother as her digital nominee in a photo cloud storage service.",
                    complianceAnalysis = "Under Section 14(1), upon providing proof of death, the brother can step into her shoes as nominee to manage or permanently delete the personal data."
                )
            ),
            keyTakeaways = listOf(
                "Users can designate nominees for their digital footprint",
                "Applies upon death or physical/mental incapacity",
                "Nominee can exercise access, correction, and erasure rights"
            )
        ),
        DpdpSection(
            number = 15,
            sectionLabel = "Section 15",
            title = "Duties of Data Principal",
            chapterId = 3,
            chapterName = "CHAPTER III: RIGHTS AND DUTIES OF DATA PRINCIPAL",
            category = DpdpCategory.DUTIES_OF_PRINCIPAL,
            maxPenalty = "Up to ₹10,000 (Item 7 of Schedule)",
            bareActText = """
15. A Data Principal shall comply with the provisions of all applicable laws for the time being in force while exercising rights under this Act and shall perform the following duties, namely:—
(a) not impersonate another person while providing her personal data for a specified purpose;
(b) not suppress any material information while providing her personal data for any document, unique identifier, proof of identity or proof of address issued by the State or any of its instrumentalities;
(c) not register a false or frivolous grievance or complaint with a Data Fiduciary or the Board; and
(d) furnish only such information as is verifiably authentic, while exercising the right to correction or erasure under the provisions of this Act or the rules made thereunder.
            """.trimIndent(),
            simplifiedExplanation = """
• Citizen Duties: The DPDP Act is one of the few privacy laws globally to balance citizen rights with explicit legal duties.
• Statutory Duties of Users:
  1. NO Impersonation: You cannot register with someone else's name, phone, or Aadhaar.
  2. NO Suppressing Material Facts: In official State identity documents or address proofs.
  3. NO False or Frivolous Claims: You cannot harass companies with bogus complaints to the Board.
  4. Furnish Authentic Information: When seeking data correction, you must provide real, verifiable facts.
• Financial Penalty: Violating these citizen duties can attract a fine of up to ₹10,000 from the Board.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Fake Name & Malicious Complaint",
                    industry = "E-Commerce",
                    scenario = "A competitor signs up on an online portal using forged documents and files a malicious complaint with the Data Protection Board.",
                    complianceAnalysis = "The user is in direct violation of Section 15(a) & 15(c), and is liable to be penalized up to ₹10,000 under the Schedule."
                )
            ),
            keyTakeaways = listOf(
                "Prohibition against impersonating another person",
                "Prohibition against suppressing material facts on government IDs",
                "Prohibition against filing false or frivolous complaints",
                "Penalty of up to ₹10,000 for breach of citizen duties"
            )
        ),
        DpdpSection(
            number = 16,
            sectionLabel = "Section 16",
            title = "Transfer of personal data outside India",
            chapterId = 4,
            chapterName = "CHAPTER IV: SPECIAL PROVISIONS",
            category = DpdpCategory.CROSS_BORDER,
            bareActText = """
16. (1) The Central Government may, by notification, restrict the transfer of personal data by a Data Fiduciary for processing to such country or territory outside India as may be so notified.
(2) Nothing contained in this section shall restrict the applicability of any law for the time being in force in India that provides for a higher degree of protection for or restriction on transfer of personal data by a Data Fiduciary outside India, in relation to any personal data or Data Fiduciary or class of Data Fiduciaries.
            """.trimIndent(),
            simplifiedExplanation = """
• Blacklist Regime: India adopts a business-friendly 'Blacklisting' model for cross-border data flows. Data can generally flow to global cloud servers and foreign partners UNLESS the Central Government explicitly blacklists/restricts a specific country (e.g. adversary states).
• Sectoral Laws Prevail: If another Indian regulator has stricter localization rules (such as the Reserve Bank of India requiring all payments data to be stored exclusively in India under RBI circulars, or IRDAI insurance guidelines), those stricter rules continue to apply!
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "SaaS Cloud Hosting in US vs Payments Localization",
                    industry = "SaaS & Payments",
                    scenario = "A Bangalore startup hosts customer CRM data on AWS servers in Virginia, USA, while also processing UPI payments.",
                    complianceAnalysis = "Under Section 16(1), transferring general CRM data to the US is permitted unless the US is restricted. However, for UPI payment records, Section 16(2) ensures RBI's strict localization mandate takes precedence."
                )
            ),
            keyTakeaways = listOf(
                "Cross-border transfer permitted by default unless country is blacklisted",
                "Central Government can notify restricted jurisdictions",
                "Sectoral laws (e.g. RBI payments localization) remain unaffected"
            )
        ),
        DpdpSection(
            number = 17,
            sectionLabel = "Section 17",
            title = "Exemptions",
            chapterId = 4,
            chapterName = "CHAPTER IV: SPECIAL PROVISIONS",
            category = DpdpCategory.EXEMPTIONS,
            bareActText = """
17. (1) The provisions of Chapter II, Chapter III and section 16 shall not apply in respect of the processing of personal data—
(a) by or on behalf of any court or tribunal or any other authority in India, entrusted by law with the performance of any judicial or quasi-judicial function;
(b) where personal data is processed in the interest of prevention, detection, investigation or prosecution of any offense or contravention of any law;
(c) where personal data is processed by or for an individual for personal or domestic purposes;
(d) where personal data is processed for research, archiving or statistical purposes, subject to such standards as may be prescribed;
(e) of Data Principals not within the territory of India, under any contract entered into with any person outside the territory of India by any person based in India (IT/BPO exports);
(f) necessary for enforcing any legal right or claim;
(g) in connection with any scheme of compromise, arrangement, merger, amalgamation or reconstruction of a company.

(2) The Central Government may, by notification, exempt from the application of this Act:
(a) any instrumentality of the State in the interests of sovereignty and integrity of India, security of the State, friendly relations with foreign States, or maintenance of public order;
(b) processing of personal data for research, archiving or statistical purposes.

(3) The Central Government may, having regard to the volume and nature of personal data processed, notify certain Data Fiduciaries or classes of Data Fiduciaries, including startups, to which certain provisions (e.g., notice under section 5, data accuracy under section 8(3), SDF obligations under section 10) shall not apply.
            """.trimIndent(),
            simplifiedExplanation = """
• Broad Exemptions: Certain entities and activities are exempted from consent, notice, and rights obligations:
  1. Judicial Proceedings: Courts and tribunals are exempt.
  2. Crime & Investigation: Police and investigative agencies investigating crimes.
  3. Indian IT / BPO Export Industry: Crucial for India's $250B tech export sector! Foreign client data processed in Indian BPOs/data centers under foreign contracts is exempt from Indian DPDP restrictions.
  4. Mergers & Acquisitions: Sharing employee/customer data during corporate due diligence.
  5. State Security: Government intelligence/security agencies can be exempted for national security and public order.
  6. Startup Sandboxes: The Central Government can exempt early-stage startups from heavy compliance like DPIAs or complex notices.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "BPO in Pune Processing UK Insurance Claims",
                    industry = "IT / ITES Outsourcing",
                    scenario = "An Indian IT company processes healthcare claims for UK residents under a contract with a London insurer.",
                    complianceAnalysis = "Exempted under Section 17(1)(e). Indian DPDP Act notice and consent rules do not apply to foreign data processed in India for foreign clients, protecting India's BPO sector."
                ),
                PracticalExample(
                    title = "Startup Compliance Relaxation",
                    industry = "Tech Startups",
                    scenario = "A 5-person DPIIT-recognized startup builds a local grocery discovery tool.",
                    complianceAnalysis = "Under Section 17(3), the Government can exempt startups from heavy requirements like Section 5 notices and Section 8(3) data accuracy updates."
                )
            ),
            keyTakeaways = listOf(
                "Protects Indian IT/BPO export sector handling foreign client data",
                "Exemptions for judicial proceedings, law enforcement, and M&A",
                "State security exemptions for national sovereignty and public order",
                "Statutory power to grant compliance relief to startups"
            )
        ),
        DpdpSection(
            number = 18,
            sectionLabel = "Section 18",
            title = "Establishment of Board",
            chapterId = 5,
            chapterName = "CHAPTER V: DATA PROTECTION BOARD OF INDIA",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
18. (1) With effect from such date as the Central Government may, by notification, appoint, there shall be established, for the purposes of this Act, a Board to be called the Data Protection Board of India.
(2) The Board shall be a body corporate by the name aforesaid, having perpetual succession and a common seal, with power, subject to the provisions of this Act, to acquire, hold and dispose of property, both movable and immovable, and to contract and shall, by the said name, sue or be sued.
(3) The head office of the Board shall be at such place as the Central Government may notify.
            """.trimIndent(),
            simplifiedExplanation = """
• Creation of the Regulator: Establishes the Data Protection Board of India (DPBI) as the primary adjudicatory authority under the Act.
• Body Corporate: The Board is a distinct legal entity with perpetual succession, legal seal, ability to own property, enter into contracts, and sue or be sued.
• Headquarters: Located at a place determined and notified by the Central Government.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Filing Legal Action",
                    industry = "Legal / Regulation",
                    scenario = "A company challenges an interim order issued by the Board.",
                    complianceAnalysis = "Under Section 18(2), the Board can be sued in its corporate name 'Data Protection Board of India'."
                )
            ),
            keyTakeaways = listOf(
                "Establishes Data Protection Board of India as the apex adjudicatory body",
                "Body corporate with perpetual succession and common seal",
                "Headquarters determined by Central Government"
            )
        ),
        DpdpSection(
            number = 19,
            sectionLabel = "Section 19",
            title = "Composition and qualifications for appointment of Chairperson and Members",
            chapterId = 5,
            chapterName = "CHAPTER V: DATA PROTECTION BOARD OF INDIA",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
19. (1) The Board shall consist of a Chairperson and such number of other Members as the Central Government may notify.
(2) The Chairperson and other Members shall be appointed by the Central Government in such manner as may be prescribed.
(3) The Chairperson and other Members shall be persons of ability, integrity and standing who have special knowledge or practical experience in the fields of data governance, administration or implementation of laws related to digital economy, law, consumer protection, dispute resolution, information and communication technology, digital economy, or any other related field.
            """.trimIndent(),
            simplifiedExplanation = """
• Board Structure: Consists of a Chairperson and Members appointed by the Central Government.
• Professional Qualifications: Appointees must possess expertise in data governance, digital economy, law, cyber security, ICT, consumer protection, or dispute resolution.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Board Composition",
                    industry = "Governance",
                    scenario = "Selection of technical and legal experts to adjudicate complex cloud security leaks.",
                    complianceAnalysis = "Section 19(3) ensures the Board comprises individuals with hands-on digital economy, tech, and legal dispute resolution experience."
                )
            ),
            keyTakeaways = listOf(
                "Chairperson and Members appointed by Central Government",
                "Specialized qualifications in data governance, digital law, ICT, and dispute resolution"
            )
        ),
        DpdpSection(
            number = 20,
            sectionLabel = "Section 20",
            title = "Salary, allowances and other terms and conditions of service",
            chapterId = 5,
            chapterName = "CHAPTER V: DATA PROTECTION BOARD OF INDIA",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
20. (1) The salary, allowances and other terms and conditions of service of the Chairperson and other Members shall be such as may be prescribed, and shall not be varied to their disadvantage after their appointment.
(2) The Chairperson and other Members shall hold office for a term of two years and shall be eligible for re-appointment.
            """.trimIndent(),
            simplifiedExplanation = """
• Independence Safeguard: Salaries and terms of service cannot be altered to their disadvantage during their term, ensuring adjudicatory independence.
• Tenure: Members serve a term of 2 years and are eligible for re-appointment.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Security of Service",
                    industry = "Judicial Independence",
                    scenario = "A Member adjudicates a high-stakes ₹100 Crore data breach case involving a public sector undertaking.",
                    complianceAnalysis = "Section 20(1) guarantees their salary and benefits cannot be curtailed, safeguarding impartial decision-making."
                )
            ),
            keyTakeaways = listOf(
                "Terms and salary cannot be varied to disadvantage during tenure",
                "Tenure of 2 years with eligibility for re-appointment"
            )
        )
    )
}
