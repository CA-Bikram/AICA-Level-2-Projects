package com.example.data.repository

import com.example.data.model.DpdpChapter

object DpdpChaptersData {
    val chapters: List<DpdpChapter> = listOf(
        DpdpChapter(
            id = 1,
            romanNumeral = "CHAPTER I",
            title = "PRELIMINARY",
            summary = "Title, commencement, territorial scope, definitions of core terms (Data Principal, Data Fiduciary, Processor), and grounds of non-applicability.",
            sectionRange = "Sections 1 – 3"
        ),
        DpdpChapter(
            id = 2,
            romanNumeral = "CHAPTER II",
            title = "OBLIGATIONS OF DATA FIDUCIARY",
            summary = "Grounds for processing, notice requirements, valid consent and withdrawal, legitimate uses, security safeguards, breach reporting, child data protection, and Significant Data Fiduciaries.",
            sectionRange = "Sections 4 – 10"
        ),
        DpdpChapter(
            id = 3,
            romanNumeral = "CHAPTER III",
            title = "RIGHTS AND DUTIES OF DATA PRINCIPAL",
            summary = "Rights of citizens to access, rectify, erase, grievance redressal, and nominate, along with statutory citizen duties not to impersonate or file frivolous claims.",
            sectionRange = "Sections 11 – 15"
        ),
        DpdpChapter(
            id = 4,
            romanNumeral = "CHAPTER IV",
            title = "SPECIAL PROVISIONS",
            summary = "Cross-border transfers of personal data (restriction/blacklisting regime) and exemptions for state security, law enforcement, research, and startups.",
            sectionRange = "Sections 16 – 17"
        ),
        DpdpChapter(
            id = 5,
            romanNumeral = "CHAPTER V",
            title = "DATA PROTECTION BOARD OF INDIA",
            summary = "Establishment of the Board as an independent body corporate, qualifications of Chairperson and Members, tenure, disqualifications, and secretariat.",
            sectionRange = "Sections 18 – 26"
        ),
        DpdpChapter(
            id = 6,
            romanNumeral = "CHAPTER VI",
            title = "POWERS, FUNCTIONS AND PROCEDURE OF BOARD",
            summary = "Powers to investigate breaches, issue urgent interim remediation directions, inquire on complaints, operate as a digital office, and enforce orders.",
            sectionRange = "Sections 27 – 28"
        ),
        DpdpChapter(
            id = 7,
            romanNumeral = "CHAPTER VII",
            title = "APPEAL AND ALTERNATE DISPUTE RESOLUTION",
            summary = "Appeals before the Appellate Tribunal (TDSAT), enforcement of orders as civil court decrees, voluntary undertakings, and referral to mediation.",
            sectionRange = "Sections 29 – 32"
        ),
        DpdpChapter(
            id = 8,
            romanNumeral = "CHAPTER VIII",
            title = "PENALTIES AND ADJUDICATION",
            summary = "Statutory factors guiding penalty determination and crediting realized penalty sums directly to the Consolidated Fund of India.",
            sectionRange = "Sections 33 – 34"
        ),
        DpdpChapter(
            id = 9,
            romanNumeral = "CHAPTER IX",
            title = "MISCELLANEOUS",
            summary = "Government powers to seek info, issue directions, public blocking orders, bar of civil courts, rule-making powers, and amendments to the IT Act and RTI Act.",
            sectionRange = "Sections 35 – 44"
        ),
        DpdpChapter(
            id = 10,
            romanNumeral = "SCHEDULE",
            title = "THE SCHEDULE (PENALTIES)",
            summary = "Prescribed maximum financial penalties for distinct violations: up to ₹250 Cr for security breach, ₹200 Cr for child data violation, ₹150 Cr for rights breach.",
            sectionRange = "Items 1 – 7"
        )
    )
}
