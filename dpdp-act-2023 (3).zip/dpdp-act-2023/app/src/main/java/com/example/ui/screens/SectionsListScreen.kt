package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DpdpSection
import com.example.ui.components.SearchFilterBar
import com.example.ui.components.SectionCard
import com.example.ui.theme.Gold500
import com.example.ui.theme.GreenSuccess
import com.example.ui.viewmodel.DpdpUiState

@Composable
fun SectionsListScreen(
    sections: List<DpdpSection>,
    uiState: DpdpUiState,
    bookmarkedIds: Set<Int>,
    readIds: Set<Int>,
    onQueryChange: (String) -> Unit,
    onCategorySelected: (com.example.data.model.DpdpCategory) -> Unit,
    onClearChapterFilter: () -> Unit,
    onClearAllFilters: () -> Unit,
    onSectionClick: (Int) -> Unit,
    onToggleBookmark: (Int) -> Unit,
    onToggleRead: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalSectionsCount = 45 // 44 sections + Schedule
    val readCount = readIds.size
    val progressFraction = (readCount.toFloat() / totalSectionsCount.toFloat()).coerceIn(0f, 1f)

    Column(modifier = modifier.fillMaxSize()) {
        // Search & Filter Bar
        SearchFilterBar(
            query = uiState.searchQuery,
            onQueryChange = onQueryChange,
            selectedCategory = uiState.selectedCategory,
            onCategorySelected = onCategorySelected,
            selectedChapterFilter = uiState.selectedChapterFilter,
            onClearChapterFilter = onClearChapterFilter,
            totalResultCount = sections.size
        )

        // Reading Progress Header Banner (shown when not searching)
        if (uiState.searchQuery.isBlank() && uiState.selectedChapterFilter == null) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoStories,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Learning Progress",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Text(
                            text = "$readCount / $totalSectionsCount Studied (${(progressFraction * 100).toInt()}%)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { progressFraction },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = GreenSuccess,
                        trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                    )
                }
            }
        }

        // Section Cards List or Empty State
        if (sections.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SearchOff,
                        contentDescription = "No results",
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No provisions found",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Try searching by section number (e.g. 6) or clearing your filters.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onClearAllFilters,
                        modifier = Modifier.testTag("reset_filters_button")
                    ) {
                        Text("Reset Filters")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("sections_lazy_column"),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(
                    items = sections,
                    key = { it.number }
                ) { section ->
                    SectionCard(
                        section = section,
                        searchQuery = uiState.searchQuery,
                        isBookmarked = bookmarkedIds.contains(section.number),
                        isRead = readIds.contains(section.number),
                        onSectionClick = { onSectionClick(section.number) },
                        onToggleBookmark = { onToggleBookmark(section.number) },
                        onToggleRead = { onToggleRead(section.number) }
                    )
                }
            }
        }
    }
}
