package com.example.data.repository

import com.example.data.model.DpdpCategory
import com.example.data.model.DpdpSection
import com.example.data.model.PracticalExample

object DpdpSectionsDataPart3 {
    val sections: List<DpdpSection> = listOf(
        DpdpSection(
            number = 21,
            sectionLabel = "Section 21",
            title = "Disqualifications for appointment and continuation as Chairperson and Members",
            chapterId = 5,
            chapterName = "CHAPTER V: DATA PROTECTION BOARD OF INDIA",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
21. (1) A person shall be disqualified for being appointed and for continuing as the Chairperson or a Member, if she—
(a) has been adjudged as an insolvent;
(b) has been convicted of an offense, which in the opinion of the Central Government, involves moral turpitude;
(c) has become physically or mentally incapable of acting as a Member;
(d) has acquired such financial or other interest as is likely to affect prejudicially her functions as a Member; or
(e) has so abused her position as to render her continuance in office prejudicial to the public interest.
            """.trimIndent(),
            simplifiedExplanation = """
• Integrity Safeguards: Disqualifies individuals who are bankrupt, convicted of crimes involving moral turpitude, physically/mentally unfit, holding conflicting financial interests, or abusing official powers.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Conflict of Interest in Tech Stock",
                    industry = "Ethics & Governance",
                    scenario = "A Board member acquires substantial shares in an e-commerce conglomerate currently facing an active breach inquiry.",
                    complianceAnalysis = "Under Section 21(1)(d), holding financial interest likely to prejudice duties acts as an immediate ground for disqualification."
                )
            ),
            keyTakeaways = listOf(
                "Insolvency, criminal conviction, conflict of interest, and abuse of power disqualify members"
            )
        ),
        DpdpSection(
            number = 22,
            sectionLabel = "Section 22",
            title = "Resignation by Members and filling of vacancy",
            chapterId = 5,
            chapterName = "CHAPTER V: DATA PROTECTION BOARD OF INDIA",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
22. (1) The Chairperson or any other Member may, by notice in writing under her hand addressed to the Central Government, resign from her office.
(2) Where any vacancy occurs in the office of the Chairperson or any other Member by reason of death, resignation, removal or otherwise, it shall be filled by fresh appointment in accordance with the provisions of this Act.
            """.trimIndent(),
            simplifiedExplanation = """
• Voluntary Resignation: A Member or Chairperson can resign by writing directly to the Central Government.
• Vacancies: Filled through new appointments under the Act.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Succession Protocol",
                    industry = "Administration",
                    scenario = "A member steps down due to private research pursuits.",
                    complianceAnalysis = "Under Section 22(1), a written notice to the Central Government completes the resignation, and a replacement is appointed under 22(2)."
                )
            ),
            keyTakeaways = listOf(
                "Written resignation addressed to Central Government",
                "Vacancies filled via fresh appointment"
            )
        ),
        DpdpSection(
            number = 23,
            sectionLabel = "Section 23",
            title = "Removal of Chairperson and Members",
            chapterId = 5,
            chapterName = "CHAPTER V: DATA PROTECTION BOARD OF INDIA",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
23. (1) The Central Government may, by order, remove from office the Chairperson or other Member, if the Chairperson or such other Member has incurred any disqualification referred to in section 21:
Provided that no Chairperson or other Member shall be removed under this section unless she has been given a reasonable opportunity of being heard in the matter.
            """.trimIndent(),
            simplifiedExplanation = """
• Order of Removal: The Central Government can remove a Chairperson or Member who meets the disqualification grounds under Section 21.
• Natural Justice: Mandatory opportunity of being heard must be provided before any removal order is passed.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Right of Hearing",
                    industry = "Administrative Law",
                    scenario = "Allegations of conflict of interest are raised against an adjudicating member.",
                    complianceAnalysis = "Under the proviso to Section 23(1), the member must be given a fair chance to present their defense before any removal order."
                )
            ),
            keyTakeaways = listOf(
                "Removal power vested in Central Government",
                "Mandatory fair hearing / natural justice before removal"
            )
        ),
        DpdpSection(
            number = 24,
            sectionLabel = "Section 24",
            title = "Meetings of Board",
            chapterId = 5,
            chapterName = "CHAPTER V: DATA PROTECTION BOARD OF INDIA",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
24. (1) The Board shall meet at such times and places and shall observe such rules of procedure in regard to the transaction of business at its meetings as may be prescribed.
(2) The Chairperson or, if she is unable to attend a meeting of the Board, the senior-most Member present at the meeting, shall preside at the meeting.
(3) All questions which come up before any meeting of the Board shall be decided by a majority of votes of the Members present and voting, and in the event of an equality of votes, the Chairperson, or in her absence, the person presiding, shall have a second or casting vote.
            """.trimIndent(),
            simplifiedExplanation = """
• Quorum & Decisions: Decisions are taken by majority vote of members present.
• Casting Vote: In case of a tie, the presiding Chairperson possesses a second or casting vote.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Tied Vote on Breach Penalty",
                    industry = "Regulatory Decisions",
                    scenario = "A 4-member bench is split 2-2 on whether to impose a ₹50 Crore fine.",
                    complianceAnalysis = "Under Section 24(3), the Chairperson exercises a casting vote to break the deadlock."
                )
            ),
            keyTakeaways = listOf(
                "Meetings governed by prescribed procedure",
                "Decisions taken by majority vote",
                "Chairperson has casting vote in case of tie"
            )
        ),
        DpdpSection(
            number = 25,
            sectionLabel = "Section 25",
            title = "Vacancies, etc., not to invalidate proceedings of Board",
            chapterId = 5,
            chapterName = "CHAPTER V: DATA PROTECTION BOARD OF INDIA",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
25. No act or proceeding of the Board shall be invalid merely by reason of—
(a) any vacancy in, or any defect in the constitution of, the Board;
(b) any defect in the appointment of a person acting as the Chairperson or other Member of the Board; or
(c) any irregularity in the procedure of the Board not affecting the merits of the case.
            """.trimIndent(),
            simplifiedExplanation = """
• Continuity of Orders: Legal orders, breach investigations, and penalties cannot be struck down merely because a member seat was temporarily vacant or there was a minor procedural defect that didn't affect the merits.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Challenge Based on Bench Vacancy",
                    industry = "Litigation",
                    scenario = "A telecom company attempts to invalidate a penalty order claiming one Member post was vacant during hearings.",
                    complianceAnalysis = "Section 25 explicitly protects the validity of the Board's orders against challenges based on vacancies or minor procedural defects."
                )
            ),
            keyTakeaways = listOf(
                "Vacancies or appointment defects do not invalidate Board proceedings",
                "Procedural irregularities not affecting merits do not void orders"
            )
        ),
        DpdpSection(
            number = 26,
            sectionLabel = "Section 26",
            title = "Officers and employees of Board",
            chapterId = 5,
            chapterName = "CHAPTER V: DATA PROTECTION BOARD OF INDIA",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
26. (1) The Board may, with the approval of the Central Government, appoint such officers and other employees as it considers necessary for the efficient discharge of its functions under this Act.
(2) The salaries, allowances and other terms and conditions of service of the officers and other employees of the Board shall be such as may be prescribed.
            """.trimIndent(),
            simplifiedExplanation = """
• Secretariat & Tech Staff: The Board can hire investigators, cyber forensics experts, data engineers, and administrative staff with Central Government approval.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Technical Forensic Team",
                    industry = "Cyber Forensics",
                    scenario = "The Board hires certified white-hat security auditors to analyze server logs during an investigation.",
                    complianceAnalysis = "Authorized under Section 26(1) to appoint specialized technical staff for effective functioning."
                )
            ),
            keyTakeaways = listOf(
                "Board can appoint specialized officers and staff",
                "Terms and conditions governed by prescribed rules"
            )
        ),
        DpdpSection(
            number = 27,
            sectionLabel = "Section 27",
            title = "Powers and functions of Board",
            chapterId = 6,
            chapterName = "CHAPTER VI: POWERS, FUNCTIONS AND PROCEDURE OF BOARD",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
27. (1) The Board shall exercise and perform the following powers and functions, namely:—
(a) on receipt of an intimation of personal data breach under sub-section (6) of section 8, to direct any urgent remedial or mitigation measures in proportion to the personal data breach and inquire into such personal data breach and impose penalty under this Act;
(b) on a complaint made by a Data Principal in respect of a personal data breach or a breach in observance of its obligations in relation to personal data or the exercise of her rights under the provisions of this Act, to inquire into such breach and impose penalty under this Act;
(c) on a complaint made by a Data Principal in respect of a breach in observance of the duties of a Consent Manager, to inquire into such breach and impose penalty under this Act;
(d) on a reference made to it by the Central Government or a State Government, or in compliance with the directions of any court, to inquire into such breach or failure and impose penalty under this Act;
(e) to determine whether there are sufficient grounds to proceed with an inquiry or close the proceedings; and
(f) to issue such directions as may be necessary for the enforcement of the provisions of this Act.
            """.trimIndent(),
            simplifiedExplanation = """
• Core Mandate of the Board:
  1. Urgent Remediation: Upon receiving breach notice, the Board can order immediate containment steps (e.g. shutting down exposed API keys, isolating compromised servers).
  2. Adjudicate Complaints: Inquire into citizen complaints against companies or Consent Managers.
  3. Inquire on Government / Court References: Investigate systemic breaches referred by Governments or High Courts.
  4. Impose Financial Penalties: Up to ₹250 Crore per violation!
  5. Filter Frivolous Claims: Close cases at threshold if no prima facie grounds exist.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Urgent Mitigation Order",
                    industry = "FinTech Security",
                    scenario = "A payment gateway leaks live credit card transaction tokens.",
                    complianceAnalysis = "Under Section 27(1)(a), the Board immediately directs the gateway to revoke exposed tokens and rotate encryption keys within 2 hours, prior to conducting full penalty inquiries."
                )
            ),
            keyTakeaways = listOf(
                "Power to direct urgent remedial or mitigation measures",
                "Adjudicates complaints from citizens against fiduciaries and consent managers",
                "Investigates references from Central/State Governments and Courts",
                "Authority to impose statutory penalties up to ₹250 Crore"
            )
        ),
        DpdpSection(
            number = 28,
            sectionLabel = "Section 28",
            title = "Procedure to be followed by Board",
            chapterId = 6,
            chapterName = "CHAPTER VI: POWERS, FUNCTIONS AND PROCEDURE OF BOARD",
            category = DpdpCategory.DATA_BOARD,
            bareActText = """
28. (1) The Board shall function as an independent body and shall, as far as possible, function as a digital office, and shall employ such techno-legal measures as may be prescribed.
(2) The Board may, on receipt of a complaint, reference or intimation under section 27, determine whether there are sufficient grounds to proceed with an inquiry.
(3) If the Board determines that there are insufficient grounds, it may, for reasons to be recorded in writing, close the proceedings.
(4) If the Board determines that there are sufficient grounds, it may proceed to inquire into such breach or failure.
(5) The Board shall conduct an inquiry following the principles of natural justice and shall record reasons for its findings.
(6) For the purposes of an inquiry, the Board shall have the same powers as are vested in a civil court under the Code of Civil Procedure, 1908 in respect of:
(a) summoning and enforcing attendance of persons;
(b) requiring discovery and production of books of account or other documents;
(c) receiving evidence on affidavits; and
(d) issuing commissions for examination of witnesses or documents.
(7) The Board may summon and enforce the attendance of any person, and if such person fails to attend or produce documents, the Board may impose such penalty as specified in the Schedule.
(8) The Board may direct any person to provide such information or data as it may consider necessary.
            """.trimIndent(),
            simplifiedExplanation = """
• Digital by Design: The Board operates primarily as a digital office! Filings, notices, submissions, virtual hearings, and evidence happen online through techno-legal platforms.
• Civil Court Powers: The Board has the legal powers of a Civil Court to summon company executives, compel production of server logs, examine witnesses under oath, and issue search commissions.
• Natural Justice: Parties are given a fair right of hearing and written reasoned orders.
• Filter Stage: Board screens and drops frivolous complaints at the preliminary stage.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Virtual Summons of Cloud Architecture Logs",
                    industry = "Cloud Architecture",
                    scenario = "The Board summons an overseas CTO via digital video conference and orders production of encrypted audit trails.",
                    complianceAnalysis = "Under Section 28(1) and 28(6), the Board executes digital hearings and civil court powers to enforce discovery of cloud log files."
                )
            ),
            keyTakeaways = listOf(
                "Digital office: online filings, hearings, and orders",
                "Vested with full Civil Court powers (summons, discovery, evidence)",
                "Adheres strictly to principles of natural justice and reasoned orders"
            )
        ),
        DpdpSection(
            number = 29,
            sectionLabel = "Section 29",
            title = "Appeal to Appellate Tribunal",
            chapterId = 7,
            chapterName = "CHAPTER VII: APPEAL AND ALTERNATE DISPUTE RESOLUTION",
            category = DpdpCategory.APPEALS,
            bareActText = """
29. (1) Any person aggrieved by an order or direction made by the Board under this Act may prefer an appeal before the Appellate Tribunal.
(2) Every appeal under sub-section (1) shall be filed within a period of sixty days from the date of receipt of the order or direction appealed against, in such form, verified in such manner and accompanied by such fee as may be prescribed:
Provided that the Appellate Tribunal may entertain an appeal after the expiry of the period of sixty days, if it is satisfied that there was sufficient cause for not filing it within that period.
(3) On receipt of an appeal under sub-section (1), the Appellate Tribunal may, after giving the parties a reasonable opportunity of being heard, pass such orders thereon as it thinks fit, confirming, modifying or setting aside the order appealed against.
(4) The Appellate Tribunal shall send a copy of every order made by it to the Board and to the parties to the appeal.
(5) The appeal filed before the Appellate Tribunal under sub-section (1) shall be dealt with by it as expeditiously as possible and endeavor shall be made by it to dispose of the appeal finally within six months from the date on which the appeal is presented.
            """.trimIndent(),
            simplifiedExplanation = """
• Appellate Forum: Appeals against orders of the Data Protection Board go to the TDSAT (Telecom Disputes Settlement and Appellate Tribunal).
• 60-Day Window: An appeal must be filed within 60 days from receipt of the Board's order.
• Fast-Track Resolution: The Tribunal must endeavor to dispose of the appeal within 6 months.
• Powers: The Tribunal can uphold, modify, or strike down the Board's penalties or directions.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Challenging a ₹50 Crore Penalty",
                    industry = "FinTech Litigation",
                    scenario = "A bank is penalized ₹50 Crore by the Board for a mobile app data breach.",
                    complianceAnalysis = "Under Section 29(1) & (2), the bank has 60 days to file an appeal before the TDSAT challenging the calculation of the penalty."
                )
            ),
            keyTakeaways = listOf(
                "Appeals lie before TDSAT (Telecom Disputes Settlement and Appellate Tribunal)",
                "Statutory limitation period of 60 days to appeal",
                "Tribunal aims to resolve appeals within 6 months"
            )
        ),
        DpdpSection(
            number = 30,
            sectionLabel = "Section 30",
            title = "Orders passed by Appellate Tribunal to be executable as decree",
            chapterId = 7,
            chapterName = "CHAPTER VII: APPEAL AND ALTERNATE DISPUTE RESOLUTION",
            category = DpdpCategory.APPEALS,
            bareActText = """
30. (1) An order passed by the Appellate Tribunal under this Act shall be executable by the Appellate Tribunal as a decree of a civil court, and for this purpose, the Appellate Tribunal shall have all the powers of a civil court.
(2) Notwithstanding anything contained in sub-section (1), the Appellate Tribunal may transmit any order made by it to a civil court having local jurisdiction and such civil court shall execute the order as if it were a decree made by that court.
            """.trimIndent(),
            simplifiedExplanation = """
• Enforceable as Court Decree: Orders of the TDSAT carry the full force of a civil court decree.
• Execution: The Tribunal can execute the order itself (e.g. attachment of bank accounts) or transmit it to local civil courts across India for recovery.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Attachment for Unpaid Fines",
                    industry = "Legal Enforcement",
                    scenario = "A defaulting company refuses to deposit penalty sums ordered on appeal.",
                    complianceAnalysis = "Under Section 30(1), the order is executed like a court decree, allowing civil court bailiffs to attach assets or freeze company bank accounts."
                )
            ),
            keyTakeaways = listOf(
                "Orders executable as decrees of a civil court",
                "Can be transmitted to local civil courts for rapid asset recovery"
            )
        ),
        DpdpSection(
            number = 31,
            sectionLabel = "Section 31",
            title = "Alternate dispute resolution",
            chapterId = 7,
            chapterName = "CHAPTER VII: APPEAL AND ALTERNATE DISPUTE RESOLUTION",
            category = DpdpCategory.APPEALS,
            bareActText = """
31. If the Board is of the opinion that any complaint may be resolved by mediation or other process of alternate dispute resolution, it may direct the concerned parties to attempt resolution through mediation by such mediator as the parties may agree on, or as may be designated by the Board.
            """.trimIndent(),
            simplifiedExplanation = """
• Mediation First: To avoid heavy legal litigation, the Board can refer disputes between citizens and companies to formal mediation.
• Consensual Settlement: Allows amicable solutions (e.g. account reinstatement, data rectification, apology, or settlement) without triggering massive statutory penalties.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Disputed Address Correction",
                    industry = "Hospitality",
                    scenario = "A customer and travel booking site dispute whether loyalty points data was incorrectly deleted.",
                    complianceAnalysis = "Under Section 31, the Board refers both parties to a certified data mediator to work out account restoration peacefully."
                )
            ),
            keyTakeaways = listOf(
                "Board can direct parties to mediation",
                "Encourages swift, amicable settlement of consumer privacy disputes"
            )
        ),
        DpdpSection(
            number = 32,
            sectionLabel = "Section 32",
            title = "Voluntary undertaking",
            chapterId = 7,
            chapterName = "CHAPTER VII: APPEAL AND ALTERNATE DISPUTE RESOLUTION",
            category = DpdpCategory.APPEALS,
            bareActText = """
32. (1) The Board may accept a voluntary undertaking in respect of any matter related to compliance with the provisions of this Act from any person at any stage of the proceedings.
(2) The voluntary undertaking may include commitments such as—
(a) to take such action within such time as may be determined;
(b) to refrain from taking such action; and
(c) to publicize the voluntary undertaking.
(3) The Board may accept the voluntary undertaking with or without variations.
(4) Acceptance of a voluntary undertaking by the Board shall operate as a bar on any proceeding under this Act as long as the terms of the voluntary undertaking are complied with.
(5) If a person fails to comply with any term of the voluntary undertaking accepted by the Board, such failure shall be deemed to be a breach of the provisions of this Act and the Board may, after giving a reasonable opportunity of being heard, impose penalty as specified in the Schedule.
            """.trimIndent(),
            simplifiedExplanation = """
• Settlement via Commitments: A company facing an inquiry can voluntarily submit a written binding commitment to fix its security flaws, compensate users, or upgrade systems.
• Litigation Bar: Once accepted by the Board, ongoing penalty proceedings are frozen as long as the company fulfills its promises.
• Default Penalty: Failing to follow through on an accepted undertaking constitutes an independent breach and triggers immediate penalties!
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Security Architecture Overhaul Undertaking",
                    industry = "E-Commerce",
                    scenario = "An online platform discovers an API vulnerability and submits a voluntary undertaking to deploy AES-256 encryption across all servers within 60 days.",
                    complianceAnalysis = "Under Section 32, the Board accepts the undertaking, pausing punitive actions unless the company misses its 60-day deadline."
                )
            ),
            keyTakeaways = listOf(
                "Allows fiduciaries to resolve inquiries via voluntary written commitments",
                "Halts formal penalty proceedings while company complies",
                "Breach of undertaking triggers direct statutory penalties"
            )
        ),
        DpdpSection(
            number = 33,
            sectionLabel = "Section 33",
            title = "Penalties",
            chapterId = 8,
            chapterName = "CHAPTER VIII: PENALTIES AND ADJUDICATION",
            category = DpdpCategory.PENALTIES,
            maxPenalty = "Up to ₹250 Crore depending on Schedule",
            bareActText = """
33. (1) If the Board concludes on inquiry that a person has committed a breach of any provision of this Act or the rules made thereunder, it may, after giving a reasonable opportunity of being heard, impose such monetary penalty specified in the Schedule.
(2) While determining the amount of monetary penalty to be imposed under sub-section (1), the Board shall have regard to the following factors, namely:—
(a) the nature, gravity and duration of the breach;
(b) the type and nature of the personal data affected by the breach;
(c) repetitive nature of the breach;
(d) whether the person, as a result of the breach, has realised a gain or avoided any loss;
(e) whether the person took any action to mitigate the effects and consequences of the breach, and the timeliness and effectiveness of such action;
(f) whether the monetary penalty to be imposed is proportionate and effective, having regard to the need to secure observance of and deter breach of the provisions of this Act; and
(g) the likely impact of the imposition of the monetary penalty on the person.
            """.trimIndent(),
            simplifiedExplanation = """
• Statutory Sentencing Factors: Penalties are not arbitrary; the Board must evaluate 7 mandatory criteria:
  1. Gravity & Duration: How serious was the leak and how long did it last?
  2. Sensitivity of Data: Was it passwords/biometrics/health records vs generic email addresses?
  3. Repetitive History: Is the company a repeat offender?
  4. Ill-gotten Gains: Did the company make a financial profit or save costs by cutting security corners?
  5. Mitigation & Speed: Did the company act swiftly to stop the leak and help users?
  6. Deterrence & Proportionality: Is the fine sufficient to deter future reckless behavior without unjustifiably bankrupting small actors?
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Rapid Mitigation vs Negligence Fine",
                    industry = "Banking",
                    scenario = "Bank A and Bank B both suffer similar breaches. Bank A notified users within 4 hours and patched the exploit. Bank B concealed the breach for 3 months.",
                    complianceAnalysis = "Under Section 33(2)(e), Bank A's proactive mitigation substantially reduces its fine, whereas Bank B's concealment and duration trigger maximum exemplary penalties."
                )
            ),
            keyTakeaways = listOf(
                "Penalties imposed based on Schedule maximums",
                "Guided by 7 statutory factors: gravity, duration, data type, repeat offense, mitigation, profit, proportionality"
            )
        ),
        DpdpSection(
            number = 34,
            sectionLabel = "Section 34",
            title = "Crediting sums realised by way of penalties to Consolidated Fund of India",
            chapterId = 8,
            chapterName = "CHAPTER VIII: PENALTIES AND ADJUDICATION",
            category = DpdpCategory.PENALTIES,
            bareActText = """
34. All sums realised by way of penalties imposed by the Board under this Act shall be credited to the Consolidated Fund of India.
            """.trimIndent(),
            simplifiedExplanation = """
• Public Revenue: All penalties collected under the DPDP Act (up to ₹250 Crore fines) go directly to the Consolidated Fund of India (the Government treasury).
• No Self-Funding Incentive: The Board cannot use penalty money as its personal operating budget, eliminating any conflict of interest or incentive to levy arbitrary fines.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Deposit of Fine",
                    industry = "Public Finance",
                    scenario = "A ₹100 Crore penalty paid by a defaulting telecom fiduciary.",
                    complianceAnalysis = "Under Section 34, the entire amount is directly deposited into the Consolidated Fund of India."
                )
            ),
            keyTakeaways = listOf(
                "All penalties go directly to the Consolidated Fund of India",
                "Eliminates revenue conflict of interest for the Board"
            )
        )
    )
}
