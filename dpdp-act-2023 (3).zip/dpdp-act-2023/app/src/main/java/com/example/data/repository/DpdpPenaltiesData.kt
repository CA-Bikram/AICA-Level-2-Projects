package com.example.data.repository

import com.example.data.model.PenaltyEntry
import com.example.data.model.PenaltyRiskLevel

object DpdpPenaltiesData {
    val entries: List<PenaltyEntry> = listOf(
        PenaltyEntry(
            serialNo = 1,
            breachTitle = "Failure to Take Reasonable Security Safeguards",
            statutoryRef = "Section 8(5)",
            maxPenalty = "₹250 Crore",
            riskLevel = PenaltyRiskLevel.CRITICAL,
            bareActDescription = "Breach in observing the obligation of Data Fiduciary to take reasonable security safeguards to prevent personal data breach under sub-section (5) of section 8.",
            plainExplanation = "The highest financial penalty under the entire Act. Applies when a company fails to protect user data with proper technical security measures (such as encryption, role-based access, vulnerability patching, or firewall defense) resulting in a breach.",
            practicalIllustration = "A bank or healthcare provider leaves database ports open to the public internet without encryption, enabling hackers to download sensitive transaction or health records."
        ),
        PenaltyEntry(
            serialNo = 2,
            breachTitle = "Failure to Notify Data Breach to Board & Users",
            statutoryRef = "Section 8(6)",
            maxPenalty = "₹200 Crore",
            riskLevel = PenaltyRiskLevel.CRITICAL,
            bareActDescription = "Breach in observing the obligation to give the Board or affected Data Principal notice of a personal data breach under sub-section (6) of section 8.",
            plainExplanation = "Concealing or delaying notice of a data leak. When a breach happens, the company MUST inform both the Data Protection Board and every affected citizen.",
            practicalIllustration = "An e-commerce portal discovers a customer credentials dump on a hacker forum but keeps it secret for months to protect company stock prices instead of notifying users."
        ),
        PenaltyEntry(
            serialNo = 3,
            breachTitle = "Violation of Obligations Regarding Children's Data",
            statutoryRef = "Section 9",
            maxPenalty = "₹200 Crore",
            riskLevel = PenaltyRiskLevel.CRITICAL,
            bareActDescription = "Breach in observance of additional obligations in relation to children under section 9.",
            plainExplanation = "Processing data of children (under 18) without verifiable parental consent, tracking/profiling minors, running targeted behavioral ads directed at children, or undertaking processing detrimental to their well-being.",
            practicalIllustration = "A video game or social media app builds psychological engagement profiles on 13-year-olds to push microtransactions and behavioral targeted advertisements."
        ),
        PenaltyEntry(
            serialNo = 4,
            breachTitle = "Non-Compliance by Significant Data Fiduciary",
            statutoryRef = "Section 10",
            maxPenalty = "₹150 Crore",
            riskLevel = PenaltyRiskLevel.HIGH,
            bareActDescription = "Breach in observance of additional obligations of Significant Data Fiduciary under section 10.",
            plainExplanation = "Failure by an SDF to appoint an India-resident Data Protection Officer reporting to the Board, failure to hire independent data auditors, or omitting periodic Data Protection Impact Assessments (DPIAs).",
            practicalIllustration = "A multi-million user fintech or social media network designated as an SDF fails to conduct an independent annual data audit or conduct a DPIA before rolling out facial recognition."
        ),
        PenaltyEntry(
            serialNo = 5,
            breachTitle = "Breach of Citizen / Data Principal Duties",
            statutoryRef = "Section 15",
            maxPenalty = "₹10,000",
            riskLevel = PenaltyRiskLevel.STANDARD,
            bareActDescription = "Breach in observance of the duties of Data Principal under section 15.",
            plainExplanation = "Impersonating another person, submitting forged KYC documents, suppressing material facts, or filing false and frivolous complaints against companies with the Board.",
            practicalIllustration = "An individual signs up on an app with a stolen ID card or files malicious, concocted complaints to extort money or settle personal scores with a business."
        ),
        PenaltyEntry(
            serialNo = 6,
            breachTitle = "Breach of Accepted Voluntary Undertaking",
            statutoryRef = "Section 32",
            maxPenalty = "Up to Full Original Penalty (up to ₹250 Cr)",
            riskLevel = PenaltyRiskLevel.HIGH,
            bareActDescription = "Breach of any term of voluntary undertaking accepted by the Board under section 32.",
            plainExplanation = "If a company promises the Board it will fix its servers or compensate victims within 60 days to settle an inquiry, and then fails to fulfill its written promise, the full underlying penalty is immediately triggered.",
            practicalIllustration = "A cloud provider accepted a voluntary undertaking to migrate all customer records to encrypted storage by December 31st, but failed to do so."
        ),
        PenaltyEntry(
            serialNo = 7,
            breachTitle = "General Residual Breach of Any Provision or Rule",
            statutoryRef = "Residual / All Other Sections",
            maxPenalty = "₹50 Crore",
            riskLevel = PenaltyRiskLevel.MODERATE,
            bareActDescription = "Breach of any other provision of this Act or the rules made thereunder for which no specific penalty is provided.",
            plainExplanation = "Catch-all penalty clause. Any violation of notice standards (Section 5), consent rules (Section 6), citizen access/erasure rights (Section 11, 12, 13), cross-border rules, or procedural regulations carries up to ₹50 Crore.",
            practicalIllustration = "A company refuses to let users delete their accounts under Section 12 or fails to provide privacy notices in regional languages under Section 5."
        )
    )
}
