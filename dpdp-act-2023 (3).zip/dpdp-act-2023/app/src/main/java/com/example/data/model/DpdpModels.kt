package com.example.data.model

enum class DpdpCategory(val displayName: String) {
    ALL("All Provisions"),
    PRELIMINARY("Preliminary & Scope"),
    CONSENT_NOTICE("Consent & Notice"),
    FIDUCIARY_DUTIES("Fiduciary Obligations"),
    CHILDREN("Children & Minors"),
    SIGNIFICANT_FIDUCIARY("Significant Fiduciaries"),
    RIGHTS_OF_PRINCIPAL("Rights of Citizens"),
    DUTIES_OF_PRINCIPAL("Duties of Citizens"),
    CROSS_BORDER("Cross-Border Transfer"),
    EXEMPTIONS("Exemptions"),
    DATA_BOARD("Data Protection Board"),
    APPEALS("Appeals & Mediation"),
    PENALTIES("Penalties & Fines"),
    MISCELLANEOUS("Miscellaneous & Rules")
}

data class DpdpChapter(
    val id: Int,
    val romanNumeral: String,
    val title: String,
    val summary: String,
    val sectionRange: String
)

data class PracticalExample(
    val title: String,
    val industry: String,
    val scenario: String,
    val complianceAnalysis: String
)

data class DpdpSection(
    val number: Int,
    val sectionLabel: String,
    val title: String,
    val chapterId: Int,
    val chapterName: String,
    val category: DpdpCategory,
    val bareActText: String,
    val simplifiedExplanation: String,
    val practicalExamples: List<PracticalExample>,
    val keyTakeaways: List<String>,
    val maxPenalty: String? = null,
    val crossReferences: List<String> = emptyList()
)

data class LegalGlossaryItem(
    val term: String,
    val sectionReference: String,
    val legalDefinition: String,
    val simplifiedMeaning: String,
    val practicalExample: String
)

enum class PenaltyRiskLevel {
    CRITICAL,
    HIGH,
    MODERATE,
    STANDARD
}

data class PenaltyEntry(
    val serialNo: Int,
    val breachTitle: String,
    val statutoryRef: String,
    val maxPenalty: String,
    val riskLevel: PenaltyRiskLevel,
    val bareActDescription: String,
    val plainExplanation: String,
    val practicalIllustration: String
)
