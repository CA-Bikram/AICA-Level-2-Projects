package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dpdp_user_data")
data class DpdpUserData(
    @PrimaryKey val sectionNumber: Int,
    val isBookmarked: Boolean = false,
    val isRead: Boolean = false,
    val userNote: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
