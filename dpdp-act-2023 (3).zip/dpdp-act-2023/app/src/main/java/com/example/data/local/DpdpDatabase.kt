package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.DpdpUserData

@Database(entities = [DpdpUserData::class], version = 1, exportSchema = false)
abstract class DpdpDatabase : RoomDatabase() {
    abstract fun dpdpUserDao(): DpdpUserDao

    companion object {
        @Volatile
        private var INSTANCE: DpdpDatabase? = null

        fun getDatabase(context: Context): DpdpDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DpdpDatabase::class.java,
                    "dpdp_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
