package com.example.data.repository

import com.example.data.model.DpdpCategory
import com.example.data.model.DpdpSection
import com.example.data.model.PracticalExample

object DpdpSectionsDataPart4 {
    val sections: List<DpdpSection> = listOf(
        DpdpSection(
            number = 35,
            sectionLabel = "Section 35",
            title = "Power of Central Government to call for information",
            chapterId = 9,
            chapterName = "CHAPTER IX: MISCELLANEOUS",
            category = DpdpCategory.MISCELLANEOUS,
            bareActText = """
35. The Central Government may, for the purposes of this Act, require the Board and any Data Fiduciary or intermediary to furnish such information as it may call for.
            """.trimIndent(),
            simplifiedExplanation = """
• Government Oversight: The Central Government can call upon the Data Protection Board, any Data Fiduciary, or internet intermediary to furnish reports, audit logs, or information needed for enforcement of the Act.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "National Data Flow Audit",
                    industry = "Government Oversight",
                    scenario = "The Ministry requests an aggregated security audit report from major telecom carriers.",
                    complianceAnalysis = "Authorized under Section 35, compelling compliance by fiduciaries and intermediaries."
                )
            ),
            keyTakeaways = listOf(
                "Central Government can call for information from Board, Fiduciaries, and Intermediaries"
            )
        ),
        DpdpSection(
            number = 36,
            sectionLabel = "Section 36",
            title = "Power of Central Government to issue directions",
            chapterId = 9,
            chapterName = "CHAPTER IX: MISCELLANEOUS",
            category = DpdpCategory.MISCELLANEOUS,
            bareActText = """
36. The Central Government or any of its officers specially authorised by it in this behalf may, from time to time, issue to the Board such directions on questions of policy as the Central Government may think fit and the Board shall, in the exercise of its powers and performance of its functions, be bound by such directions.
            """.trimIndent(),
            simplifiedExplanation = """
• Policy Binding Directives: The Central Government can issue binding policy directives to the Data Protection Board on macro-level digital economy and national security policy.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Macro Privacy Guidelines",
                    industry = "Public Policy",
                    scenario = "Central Government issues policy directions on cross-border cloud standards.",
                    complianceAnalysis = "Under Section 36, the Board must align its regulatory procedures with policy directions from the Central Government."
                )
            ),
            keyTakeaways = listOf(
                "Central Government can issue policy directions to the Board",
                "Board is statutorily bound by policy directions"
            )
        ),
        DpdpSection(
            number = 37,
            sectionLabel = "Section 37",
            title = "Power of Central Government to block access to information in public interest",
            chapterId = 9,
            chapterName = "CHAPTER IX: MISCELLANEOUS",
            category = DpdpCategory.MISCELLANEOUS,
            bareActText = """
37. (1) Whether on receipt of a reference from the Board or otherwise, if the Central Government is satisfied that it is necessary or expedient so to do, in the interests of sovereignty and integrity of India, security of the State, friendly relations with foreign States or for prevention of incitement to the commission of any cognizable offense relating to the aforesaid, it may, by order, direct any agency of the Central Government or an intermediary to block for access by the public or cause to be blocked for access by the public, any information generated, transmitted, received, stored or hosted in any computer resource.
(2) Every order under sub-section (1) shall be in writing and shall record the reasons for such direction.
(3) The Central Government may also, on the recommendation of the Board, direct blocking of access to an entire app or platform of a Data Fiduciary if such Data Fiduciary has repeatedly violated provisions and been penalized on two or more occasions.
            """.trimIndent(),
            simplifiedExplanation = """
• Digital 'Death Penalty' / App Blocking:
  1. National Security Blocking: Government can order intermediaries/ISPs to block websites or platforms threatening state security or sovereignty.
  2. Repeat Offender Platform Ban: If a company repeatedly violates the DPDP Act and has been penalized on two or more occasions, the Board can recommend, and Government can order, a total nationwide block of the app or platform!
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Rogue Loan App Banned Across India",
                    industry = "FinTech / App Stores",
                    scenario = "A predatory instant loan app leaks intimate photos of borrowers and ignores multiple ₹100 Crore penalties by the Board.",
                    complianceAnalysis = "Under Section 37(3), having been penalized on two or more occasions, the Central Government orders telecom operators and app stores to completely block the app across India."
                )
            ),
            keyTakeaways = listOf(
                "Power to block information in interest of state security and sovereignty",
                "Total platform/app blocking for repeat offenders penalized on 2+ occasions",
                "Must be in writing with recorded reasons"
            )
        ),
        DpdpSection(
            number = 38,
            sectionLabel = "Section 38",
            title = "Consistency with other laws and bar of jurisdiction of civil courts",
            chapterId = 9,
            chapterName = "CHAPTER IX: MISCELLANEOUS",
            category = DpdpCategory.MISCELLANEOUS,
            bareActText = """
38. (1) The provisions of this Act shall be in addition to and not in derogation of any other law for the time being in force:
Provided that in the event of any conflict between a provision of this Act and a provision of any other law for the time being in force, the provisions of this Act shall prevail to the extent of such conflict.
(2) No civil court shall have jurisdiction to entertain any suit or proceeding in respect of any matter which the Board or the Appellate Tribunal is empowered by or under this Act to determine and no injunction shall be granted by any court or other authority in respect of any action taken or to be taken in pursuance of any power conferred by or under this Act.
            """.trimIndent(),
            simplifiedExplanation = """
• Supreme Overriding Effect: In case of any conflict between the DPDP Act and another law regarding personal data, the DPDP Act prevails.
• Bar of Civil Courts: Civil Courts CANNOT entertain lawsuits or grant stay injunctions over matters within the jurisdiction of the Data Protection Board or TDSAT. All data disputes must go through the DPBI-TDSAT route.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Civil Court Injunction Blocked",
                    industry = "Judicial Procedure",
                    scenario = "A company rushes to a local city civil court seeking an interim stay against a Board breach investigation.",
                    complianceAnalysis = "Under Section 38(2), the civil court's jurisdiction is barred. The company can only seek relief before the Board or on appeal before TDSAT."
                )
            ),
            keyTakeaways = listOf(
                "DPDP Act provisions prevail over conflicting laws",
                "Civil courts barred from entertaining suits or granting injunctions",
                "Sole jurisdiction vested in Board and Appellate Tribunal"
            )
        ),
        DpdpSection(
            number = 39,
            sectionLabel = "Section 39",
            title = "Protection of action taken in good faith",
            chapterId = 9,
            chapterName = "CHAPTER IX: MISCELLANEOUS",
            category = DpdpCategory.MISCELLANEOUS,
            bareActText = """
39. No suit, prosecution or other legal proceeding shall lie against the Central Government, the Board, its Chairperson, any Member or any officer or other employee of the Board for anything which is in good faith done or intended to be done under this Act or the rules made thereunder.
            """.trimIndent(),
            simplifiedExplanation = """
• Good Faith Immunity: Protects the Central Government, Board members, and regulatory staff from personal lawsuits or criminal prosecution for performing their statutory duties in good faith.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Immunity for Investigators",
                    industry = "Regulatory Immunity",
                    scenario = "A company threatens to sue individual Board forensic auditors for conducting a server audit.",
                    complianceAnalysis = "Section 39 confers full statutory immunity for bona fide actions taken in discharge of official functions."
                )
            ),
            keyTakeaways = listOf(
                "Immunity for Government, Board members, and officers acting in good faith"
            )
        ),
        DpdpSection(
            number = 40,
            sectionLabel = "Section 40",
            title = "Power to make rules",
            chapterId = 9,
            chapterName = "CHAPTER IX: MISCELLANEOUS",
            category = DpdpCategory.MISCELLANEOUS,
            bareActText = """
40. (1) The Central Government may, by notification, make rules to carry out the provisions of this Act.
(2) In particular, and without prejudice to the generality of the foregoing power, such rules may provide for all or any of the following matters, namely:—
(a) the manner of giving notice under sub-section (1) of section 5;
(b) the registration, functions and interoperability standards of Consent Managers under section 6;
(c) the form and manner of intimation of personal data breach under sub-section (6) of section 8;
(d) the period within which dormant personal data shall be erased under section 8(10);
(e) the manner of obtaining verifiable parental consent for children under section 9(1);
(f) standards for Data Protection Impact Assessment (DPIA) under section 10(2);
(g) procedure for inquiry, hearings and digital office functioning of the Board under section 28;
(h) any other matter which is to be or may be prescribed.
            """.trimIndent(),
            simplifiedExplanation = """
• Delegated Legislation: Central Government (MeitY) has broad rule-making powers to define crucial operational details:
  - Exact timelines for reporting breaches (e.g. 6 hours / 72 hours).
  - Parental consent verification mechanisms (tokens, DigiLocker, Aadhaar OTP).
  - Consent Manager architecture and open APIs.
  - Periods for dormant account deletion.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Parental Consent Rules",
                    industry = "Rule-Making",
                    scenario = "Industry awaits technical specifications for parental age verification.",
                    complianceAnalysis = "Section 40(2)(e) empowers MeitY to prescribe verifiable digital verification methods."
                )
            ),
            keyTakeaways = listOf(
                "Central Government empowered to make operational rules",
                "Covers breach timelines, parental verification, consent managers, and DPIA"
            )
        ),
        DpdpSection(
            number = 41,
            sectionLabel = "Section 41",
            title = "Laying of rules before Parliament",
            chapterId = 9,
            chapterName = "CHAPTER IX: MISCELLANEOUS",
            category = DpdpCategory.MISCELLANEOUS,
            bareActText = """
41. Every rule made under this Act shall be laid, as soon as may be after it is made, before each House of Parliament, while it is in session, for a total period of thirty days which may be comprised in one session or in two or more successive sessions.
            """.trimIndent(),
            simplifiedExplanation = """
• Parliamentary Scrutiny: Every single rule framed by MeitY must be presented before both Lok Sabha and Rajya Sabha for 30 days, ensuring legislative oversight and democratic accountability.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Parliamentary Approval of Rules",
                    industry = "Parliamentary Law",
                    scenario = "New breach notification rules are tabled during the monsoon session of Parliament.",
                    complianceAnalysis = "Fulfills Section 41 mandate requiring mandatory 30-day scrutiny by MPs."
                )
            ),
            keyTakeaways = listOf(
                "Rules must be laid before both Houses of Parliament for 30 days"
            )
        ),
        DpdpSection(
            number = 42,
            sectionLabel = "Section 42",
            title = "Power to remove difficulties",
            chapterId = 9,
            chapterName = "CHAPTER IX: MISCELLANEOUS",
            category = DpdpCategory.MISCELLANEOUS,
            bareActText = """
42. (1) If any difficulty arises in giving effect to the provisions of this Act, the Central Government may, by order, published in the Official Gazette, make such provisions not inconsistent with the provisions of this Act as may appear to it to be necessary or expedient for removing the difficulty:
Provided that no such order shall be made under this section after the expiry of three years from the commencement of this Act.
(2) Every order made under this section shall be laid, as soon as may be after it is made, before each House of Parliament.
            """.trimIndent(),
            simplifiedExplanation = """
• Transition Clause: If unexpected roadblocks arise in early implementation, Government can issue orders to remove difficulties.
• Sunset Clause: This power can only be used within the first 3 years of the Act.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Clarifying Hospital Consent Protocols",
                    industry = "Transition Law",
                    scenario = "Hospitals face confusion regarding physical vs digital OPD record conversions.",
                    complianceAnalysis = "Under Section 42, Government can issue a transitional difficulty removal order during the first 3 years."
                )
            ),
            keyTakeaways = listOf(
                "Power to remove unforeseen implementation difficulties",
                "Restricted to first 3 years from commencement"
            )
        ),
        DpdpSection(
            number = 43,
            sectionLabel = "Section 43",
            title = "Amendments to certain Acts",
            chapterId = 9,
            chapterName = "CHAPTER IX: MISCELLANEOUS",
            category = DpdpCategory.MISCELLANEOUS,
            bareActText = """
43. The Information Technology Act, 2000 and the Right to Information Act, 2005 shall be amended in the manner specified in the Schedule to this Act (or relevant amendment provisions):
(1) In the Information Technology Act, 2000:
    (a) Section 43A shall be omitted (superseded by DPDP Act Section 8 and Schedule penalties);
(2) In the Right to Information Act, 2005:
    (a) in section 8, in sub-section (1), for clause (j), the following clause shall be substituted, namely:—
    "(j) information which relates to personal information;".
            """.trimIndent(),
            simplifiedExplanation = """
• Major Legal Amendments:
  1. Section 43A of IT Act Omitted: Old 2011 IT SPDI (Sensitive Personal Data) Rules and Section 43A compensation mechanisms are scrapped, replaced by the modern DPDP Act.
  2. RTI Act Section 8(1)(j) Substituted: Personal information of individuals held by public authorities is now given total privacy protection under RTI exemption clause 8(1)(j), preventing disclosure of personal details under RTI requests unless public interest outweighs privacy.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "RTI Request Seeking Officer's Personal Health Records",
                    industry = "Right to Information",
                    scenario = "An activist files an RTI demanding medical leave history and personal address of a government official.",
                    complianceAnalysis = "Under amended Section 8(1)(j) of the RTI Act via Section 43 of DPDP Act, personal information is strictly protected from disclosure."
                )
            ),
            keyTakeaways = listOf(
                "Omission of outdated Section 43A of Information Technology Act",
                "Harmonization of Section 8(1)(j) of Right to Information Act to protect personal privacy"
            )
        ),
        DpdpSection(
            number = 44,
            sectionLabel = "Section 44",
            title = "Repeal and savings",
            chapterId = 9,
            chapterName = "CHAPTER IX: MISCELLANEOUS",
            category = DpdpCategory.MISCELLANEOUS,
            bareActText = """
44. Any notification, order, scheme, or direction issued or rule made under the provisions of the Information Technology Act, 2000 relating to sensitive personal data (Section 43A rules) shall cease to apply to the extent they are inconsistent with the provisions of this Act.
            """.trimIndent(),
            simplifiedExplanation = """
• Clean Transition: Clarifies the repeal of conflicting legacy privacy rules and ensures smooth savings of pending legal liabilities created under prior frameworks.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Switching from SPDI Rules 2011 to DPDP Act 2023",
                    industry = "Compliance Transition",
                    scenario = "A legal counsel replaces old 2011 IT Act SPDI clauses in company terms of service with DPDP 2023 compliance.",
                    complianceAnalysis = "Under Section 44, the DPDP Act 2023 fully supersedes the old 2011 framework."
                )
            ),
            keyTakeaways = listOf(
                "Repeal and savings of legacy IT SPDI provisions",
                "Full formal transition to DPDP Act 2023 framework"
            )
        ),
        DpdpSection(
            number = 45,
            sectionLabel = "The Schedule",
            title = "THE SCHEDULE: Statutory Penalties Matrix",
            chapterId = 10,
            chapterName = "THE SCHEDULE",
            category = DpdpCategory.PENALTIES,
            maxPenalty = "Up to ₹250 Crore",
            bareActText = """
THE SCHEDULE
[See section 33(1)]

Sl. No. | Breach of provisions of this Act or rules made thereunder | Penalty
--------|-----------------------------------------------------------|--------
1.      | Breach in observing the obligation of Data Fiduciary to take reasonable security safeguards to prevent personal data breach under sub-section (5) of section 8. | May extend to two hundred and fifty crore rupees (₹250 Crore).
2.      | Breach in observing the obligation to give the Board or affected Data Principal notice of a personal data breach under sub-section (6) of section 8. | May extend to two hundred crore rupees (₹200 Crore).
3.      | Breach in observance of additional obligations in relation to children under section 9. | May extend to two hundred crore rupees (₹200 Crore).
4.      | Breach in observance of additional obligations of Significant Data Fiduciary under section 10. | May extend to one hundred and fifty crore rupees (₹150 Crore).
5.      | Breach in observance of the duties of Data Principal under section 15. | May extend to ten thousand rupees (₹10,000).
6.      | Breach of any term of voluntary undertaking accepted by the Board under section 32. | Up to the extent of the penalty for the breach in respect of which the voluntary undertaking was accepted.
7.      | Breach of any other provision of this Act or the rules made thereunder. | May extend to fifty crore rupees (₹50 Crore).
            """.trimIndent(),
            simplifiedExplanation = """
• The Statutory Financial Penalties:
  1. Failure to take reasonable security safeguards (Section 8(5)) -> UP TO ₹250 CRORE ($30M+).
  2. Failure to notify breach to Board or affected users (Section 8(6)) -> UP TO ₹200 CRORE.
  3. Violating children's data obligations (Section 9) -> UP TO ₹200 CRORE.
  4. Non-compliance by Significant Data Fiduciaries (Section 10) -> UP TO ₹150 CRORE.
  5. Breach of citizen duties (Section 15) -> UP TO ₹10,000.
  6. Breach of accepted voluntary undertaking (Section 32) -> Up to original breach limit (up to ₹250 Crore).
  7. Residual penalty for any other violation -> UP TO ₹50 CRORE.
• Note: These fines are per breach incident, meaning systemic repeated failures can compound significantly!
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Maximum Fine Scenarios",
                    industry = "Enterprise Risk Management",
                    scenario = "A health app suffers a ransomware attack, fails to notify affected patients, and is discovered to have tracked 10-year old children without parental consent.",
                    complianceAnalysis = "Exposed to multiple severe penalties: up to ₹250 Crore under Item 1 for security failure, up to ₹200 Crore under Item 2 for concealing breach, and up to ₹200 Crore under Item 3 for child data violations."
                )
            ),
            keyTakeaways = listOf(
                "Item 1: Security Safeguards failure: Up to ₹250 Crore",
                "Item 2: Breach Notification failure: Up to ₹200 Crore",
                "Item 3: Child data violations: Up to ₹200 Crore",
                "Item 4: Significant Data Fiduciary failure: Up to ₹150 Crore",
                "Item 5: Citizen duty breach: Up to ₹10,000",
                "Item 6: Voluntary undertaking default: Up to full original penalty",
                "Item 7: General residual breach: Up to ₹50 Crore"
            )
        )
    )
}
