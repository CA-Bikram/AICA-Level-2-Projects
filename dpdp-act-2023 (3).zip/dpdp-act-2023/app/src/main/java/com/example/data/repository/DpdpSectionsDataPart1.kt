package com.example.data.repository

import com.example.data.model.DpdpCategory
import com.example.data.model.DpdpSection
import com.example.data.model.PracticalExample

object DpdpSectionsDataPart1 {
    val sections: List<DpdpSection> = listOf(
        DpdpSection(
            number = 1,
            sectionLabel = "Section 1",
            title = "Short title and commencement",
            chapterId = 1,
            chapterName = "CHAPTER I: PRELIMINARY",
            category = DpdpCategory.PRELIMINARY,
            bareActText = """
1. (1) This Act may be called the Digital Personal Data Protection Act, 2023.
(2) It shall come into force on such date as the Central Government may, by notification in the Official Gazette, appoint and different dates may be appointed for different provisions of this Act and any reference in any such provision to the commencement of this Act shall be construed as a reference to the coming into force of that provision.
            """.trimIndent(),
            simplifiedExplanation = """
• Official Name: The law is formally called the Digital Personal Data Protection Act, 2023 (Act No. 22 of 2023).
• Phased Enforcement: Unlike laws that take effect on a single day, the Central Government has the legal power to notify different sections at different times.
• Why Phased?: This gives enterprises, startups, and institutions time to build consent architectures, appoint Data Protection Officers (DPOs), and train personnel before penalty provisions are triggered.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Staggered Implementation Strategy",
                    industry = "Compliance / Tech",
                    scenario = "A software enterprise wonders if penalties apply immediately upon the President's assent in August 2023.",
                    complianceAnalysis = "Under Section 1(2), the Act activates only upon specific gazette notifications by the Central Government. The Ministry of Electronics and Information Technology (MeitY) will notify rules and provisions systematically."
                )
            ),
            keyTakeaways = listOf(
                "Short title: Digital Personal Data Protection Act, 2023",
                "Central Government can notify different sections on different dates",
                "Applies to digital personal data across India"
            )
        ),
        DpdpSection(
            number = 2,
            sectionLabel = "Section 2",
            title = "Definitions",
            chapterId = 1,
            chapterName = "CHAPTER I: PRELIMINARY",
            category = DpdpCategory.PRELIMINARY,
            bareActText = """
2. In this Act, unless the context otherwise requires,—
(a) "Appellate Tribunal" means the Telecom Disputes Settlement and Appellate Tribunal established under section 14 of the Telecom Regulatory Authority of India Act, 1997;
(b) "automated" means any digital process capable of operating automatically in response to instructions given or otherwise for processing data;
(c) "Board" means the Data Protection Board of India established by the Central Government under section 18;
(d) "certain legitimate uses" means the uses referred to in section 7;
(e) "Chairperson" means the Chairperson of the Board;
(f) "child" means an individual who has not completed the age of eighteen years;
(g) "Consent Manager" means a person registered with the Board, who acts as a single point of contact to enable a Data Principal to give, manage, review and withdraw her consent through an accessible, transparent and interoperable platform;
(h) "data" means a representation of information, facts, concepts, opinions or instructions in a manner suitable for communication, interpretation or processing by human beings or by automated means;
(i) "Data Fiduciary" means any person who alone or in conjunction with other persons determines the purpose and means of processing of personal data;
(j) "Data Principal" means the individual to whom the personal data relates and where such individual is—
    (i) a child, includes the parents or lawful guardian of such a child;
    (ii) a person with disability, includes her lawful guardian, acting on her behalf;
(k) "Data Processor" means any person who processes personal data on behalf of a Data Fiduciary;
(l) "gain" means a rise in property or other benefits, including any economic, personal or other advantage;
(m) "harm", in relation to a Data Principal, means—
    (i) bodily harm; (ii) distortion or theft of identity; (iii) harassment; or (iv) prevention of lawful employment or discriminatory deprivation of any service or facility;
(n) "loss" means a deprivation of any property, service, benefit or other economic or personal advantage;
(o) "Member" means a Member of the Board and includes the Chairperson;
(p) "notice" means the notice referred to in section 5;
(q) "person" includes an individual, HUF, company, firm, association of persons or body of individuals, the State;
(r) "personal data" means any data about an individual who is identifiable by or in relation to such data;
(s) "personal data breach" means any unauthorised processing of personal data or accidental disclosure, acquisition, sharing, use, alteration, destruction of or loss of access to personal data, that compromises the confidentiality, integrity or availability of personal data;
(t) "prescribed" means prescribed by rules made under this Act;
(u) "processing", in relation to personal data, means a wholly or partly automated operation or set of operations performed on digital personal data, and includes operations such as collecting, recording, organising, structuring, storing, adapting, retrieving, using, aligning or combining, indexing, sharing, disclosing by transmission, disseminating or otherwise making available, restriction, erasure or destruction;
(v) "she" is used for an individual and shall include a reference to an individual of the male and other genders;
(w) "Significant Data Fiduciary" means any Data Fiduciary or class of Data Fiduciaries as may be notified by the Central Government under section 10.
            """.trimIndent(),
            simplifiedExplanation = """
• Data Principal = The citizen/individual whose data it is (You!). For children under 18, it includes parents/guardians.
• Data Fiduciary = The company, bank, hospital, app, or government department that decides WHY and HOW your data is processed.
• Data Processor = A third party (e.g. AWS, cloud hosting, payroll vendor) that handles data strictly on behalf of the Fiduciary.
• Personal Data = Any data that directly or indirectly identifies a living human (Name + Phone, Aadhaar, IP address, device ID, email).
• Personal Data Breach = Any leak, ransomware attack, accidental exposure, or unauthorized access compromising confidentiality, integrity, or availability.
• Consent Manager = An RBI Account Aggregator-like entity registered with the Board allowing citizens to view and revoke consents in one place.
• Progressive Drafting: The Act famously uses 'she/her' to refer to any individual of any gender.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "E-Commerce App & Payment Gateway",
                    industry = "FinTech / Retail",
                    scenario = "Rohan buys shoes on ZapCart. ZapCart uses Razorpay for checkout and AWS to store customer databases.",
                    complianceAnalysis = "• Rohan is the Data Principal.\n• ZapCart is the Data Fiduciary (determines purpose/means).\n• Razorpay & AWS act as Data Processors executing tasks on ZapCart's behalf."
                ),
                PracticalExample(
                    title = "What Constitutes a Breach?",
                    industry = "Cybersecurity",
                    scenario = "A hospital's patient database is hit by ransomware, locking doctors out for 48 hours, even though no records were downloaded by hackers.",
                    complianceAnalysis = "Under Section 2(s), loss of access or compromise of availability of personal data is legally a 'Personal Data Breach', requiring mandatory reporting."
                )
            ),
            keyTakeaways = listOf(
                "Data Principal = The individual; Data Fiduciary = The controller",
                "Child is strictly defined as anyone under the age of 18 years",
                "Personal data breach covers confidentiality, integrity, and availability",
                "The Act uses 'she' as a gender-neutral pronoun"
            )
        ),
        DpdpSection(
            number = 3,
            sectionLabel = "Section 3",
            title = "Application of the Act",
            chapterId = 1,
            chapterName = "CHAPTER I: PRELIMINARY",
            category = DpdpCategory.PRELIMINARY,
            bareActText = """
3. Subject to the provisions of this Act, it shall apply to the processing of digital personal data within the territory of India where the personal data is collected—
(a) in digital form; or
(b) in non-digital form and digitized subsequently.

(2) It shall also apply to processing of digital personal data outside the territory of India, if such processing is in connection with any activity related to offering of goods or services to Data Principals within the territory of India.

(3) This Act shall not apply to—
(a) personal data processed by an individual for any personal or domestic purpose; and
(b) personal data that is made or caused to be made publicly available by—
    (i) the Data Principal to whom such personal data relates; or
    (ii) any other person who is under an obligation under any law for the time being in force in India to make such personal data publicly available.
            """.trimIndent(),
            simplifiedExplanation = """
• Digital Scope: Applies to data collected digitally (websites, apps) OR collected offline on paper and subsequently digitized (e.g. paper KYC scanned into PDF).
• Extra-Territorial Jurisdiction: Foreign companies (e.g., US or Singapore e-commerce sites, streaming apps, SaaS) targeting Indian consumers MUST comply with this Act.
• Non-Applicability (Exemptions):
  1. Personal / Domestic Use: Your private phone contacts, personal photo albums, family address books are exempt.
  2. Publicly Available Data: If you publicly post your photo/vlog on Instagram/YouTube, or if data is published under legal requirement (e.g. land registry, election affidavits), scraping that public data is not a violation of Section 3.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Foreign Travel Booking Website",
                    industry = "Global Hospitality",
                    scenario = "A French boutique hotel runs a website hosted in Paris with pricing in Indian Rupees catering to tourists from Mumbai.",
                    complianceAnalysis = "Even though the servers and company are in France, Section 3(2) applies because they offer goods/services to Data Principals in India."
                ),
                PracticalExample(
                    title = "Blogging & Social Media Scraping",
                    industry = "Media & AI Training",
                    scenario = "A researcher aggregates public tweets and LinkedIn profile descriptions made public by users themselves.",
                    complianceAnalysis = "Under Section 3(3)(b)(i), data voluntarily made publicly available by the Data Principal is excluded from the scope of the Act."
                )
            ),
            keyTakeaways = listOf(
                "Applies to digital data & non-digital data digitized later",
                "Extra-territorial reach for foreign firms serving Indian users",
                "Excludes purely personal/domestic processing",
                "Excludes data voluntarily made publicly available by the user"
            )
        ),
        DpdpSection(
            number = 4,
            sectionLabel = "Section 4",
            title = "Grounds for processing personal data",
            chapterId = 2,
            chapterName = "CHAPTER II: OBLIGATIONS OF DATA FIDUCIARY",
            category = DpdpCategory.CONSENT_NOTICE,
            bareActText = """
4. (1) A person may process the personal data of an individual only in accordance with the provisions of this Act and for a lawful purpose,—
(a) for which the Data Principal has given her consent; or
(b) for certain legitimate uses referred to in section 7.

(2) For the purposes of this section, the expression "lawful purpose" means any purpose which is not expressly forbidden by law.
            """.trimIndent(),
            simplifiedExplanation = """
• The Two Legal Gateways: In India, you CANNOT process personal data unless you have either:
  1. Valid Consent (under Section 6); OR
  2. A Recognized Legitimate Use (under Section 7, such as medical emergencies, employment, government subsidies).
• Lawful Purpose Rule: You can only process data for activities that are legally permissible in India (e.g., you cannot collect data to facilitate banned gambling or unlawful surveillance).
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Ride Hailing App GPS Tracking",
                    industry = "Mobility / Cab Aggregators",
                    scenario = "A cab app collects live GPS during an active trip.",
                    complianceAnalysis = "Processing is lawful under Section 4(1)(a) provided clear consent was taken, as the ride cannot be provided without vehicle-passenger routing."
                )
            ),
            keyTakeaways = listOf(
                "Only two processing grounds: Consent OR Certain Legitimate Uses",
                "Processing must be for a lawful purpose not forbidden by law",
                "No 'legitimate interest' loophole unlike GDPR"
            )
        ),
        DpdpSection(
            number = 5,
            sectionLabel = "Section 5",
            title = "Notice",
            chapterId = 2,
            chapterName = "CHAPTER II: OBLIGATIONS OF DATA FIDUCIARY",
            category = DpdpCategory.CONSENT_NOTICE,
            bareActText = """
5. (1) Every request made to a Data Principal under section 6 for consent shall be accompanied or preceded by a notice given by the Data Fiduciary to the Data Principal, informing her,—
(i) the personal data sought to be collected and the purpose for which such personal data will be processed;
(ii) the manner in which she may exercise her rights under section 11, section 12, section 13 and section 14; and
(iii) the manner in which she may make a complaint to the Board, in such manner and as may be prescribed.

(2) Where a Data Principal has given consent before the date of commencement of this Act, the Data Fiduciary shall, as soon as practicable, give to the Data Principal a notice containing the details specified in sub-section (1).
(3) The Data Fiduciary shall give the Data Principal the option to access the contents of the notice in English or any language specified in the Eighth Schedule to the Constitution.
            """.trimIndent(),
            simplifiedExplanation = """
• Itemized & Transparent: Before asking for consent, the app/company MUST show a clear notice stating:
  1. Exactly what data is collected and WHY.
  2. How the user can view, correct, or delete their data.
  3. How the user can complain to the company and the Data Protection Board.
• Multilingual Mandate: The notice MUST be available in English OR any of the 22 recognized languages in the Eighth Schedule to the Indian Constitution (Hindi, Tamil, Bengali, Marathi, etc.).
• Legacy Data: Even for users who signed up before the Act, fiduciaries must send an updated notice as soon as practicable.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Banking App in Regional Languages",
                    industry = "Banking",
                    scenario = "A rural microfinance bank app operates in rural Karnataka.",
                    complianceAnalysis = "Under Section 5(3), the bank must provide the privacy notice in Kannada (an 8th Schedule language) or English so the rural borrower understands what data is collected."
                )
            ),
            keyTakeaways = listOf(
                "Notice must precede or accompany consent request",
                "Must state data collected, exact purpose, rights & grievance channels",
                "Mandatory language support: English + 22 languages of 8th Schedule",
                "Pre-existing users must also be given notice"
            )
        ),
        DpdpSection(
            number = 6,
            sectionLabel = "Section 6",
            title = "Consent",
            chapterId = 2,
            chapterName = "CHAPTER II: OBLIGATIONS OF DATA FIDUCIARY",
            category = DpdpCategory.CONSENT_NOTICE,
            bareActText = """
6. (1) The consent given by the Data Principal shall be free, specific, informed, unconditional and unambiguous with a clear affirmative action, and shall signify an agreement to the processing of her personal data for the specified purpose and be limited to such personal data as is necessary for such specified purpose.
(2) For the purpose of sub-section (1), any part of consent referred to in sub-section (1) which infringes the provisions of this Act or the rules made thereunder shall be invalid.
(3) Every request for consent shall be presented to the Data Principal in a manner that is clear, in plain language and with reasonable option to access such request in English or any language specified in the Eighth Schedule to the Constitution.
(4) The Data Principal shall have the right to withdraw her consent at any time, with the ease of doing so being comparable to the ease with which such consent was given.
(5) The withdrawal of consent shall not affect the legality of processing of the personal data based on consent before its withdrawal.
(6) If a Data Principal withdraws consent, the Data Fiduciary shall cease and cause its Data Processors to cease processing the personal data.
(7) The Data Principal may give, manage, review or withdraw her consent through a Consent Manager.
(8) In any proceeding, the burden of proving that consent was given in accordance with this Act shall lie on the Data Fiduciary.
(9) Where a Data Principal withdraws consent under sub-section (4), the consequences of such withdrawal shall be borne by such Data Principal.
            """.trimIndent(),
            simplifiedExplanation = """
• Standards of Valid Consent: Consent must be FREE, SPECIFIC, INFORMED, UNCONDITIONAL, and UNAMBIGUOUS with CLEAR AFFIRMATIVE ACTION (No pre-ticked checkboxes or forced bundled consents!).
• Purpose Limitation & Data Minimization: You can only collect the data strictly necessary for that specific service.
• Ease of Withdrawal: Withdrawing consent must be just as easy as giving it (e.g. if it took 1 tap to grant, it must take 1 tap to revoke).
• Cease Processing: Upon withdrawal, the fiduciary and all cloud processors must immediately stop processing and erase the data unless required by law.
• Reverse Burden of Proof: In legal disputes, the company must prove that valid consent was obtained.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Flashlight App Demanding Location & Contacts",
                    industry = "Mobile Apps",
                    scenario = "A flashlight utility app refuses to turn on the LED unless the user grants access to their entire phone contacts list and GPS.",
                    complianceAnalysis = "Violation of Section 6(1). The consent is conditional and violates purpose limitation because contacts are not necessary for a flashlight function."
                ),
                PracticalExample(
                    title = "Withdrawing Marketing Consent",
                    industry = "OTT Streaming",
                    scenario = "An OTT platform allows 1-click subscription signup but hides consent withdrawal behind 15 complicated submenus and email requests.",
                    complianceAnalysis = "Violation of Section 6(4). The ease of withdrawal must be comparable to the ease of giving consent."
                )
            ),
            keyTakeaways = listOf(
                "No pre-checked boxes; must be affirmative and unambiguous",
                "Bundled/coerced consent is void under Section 6(2)",
                "Withdrawing consent must be as easy as giving it",
                "Burden of proof is on the Data Fiduciary"
            )
        ),
        DpdpSection(
            number = 7,
            sectionLabel = "Section 7",
            title = "Certain legitimate uses",
            chapterId = 2,
            chapterName = "CHAPTER II: OBLIGATIONS OF DATA FIDUCIARY",
            category = DpdpCategory.CONSENT_NOTICE,
            bareActText = """
7. A Data Fiduciary may process personal data of a Data Principal for any of the following uses, namely:—
(a) for the specified purpose for which the Data Principal has voluntarily provided her personal data to the Data Fiduciary, and in respect of which she has not indicated to the Data Fiduciary that she does not consent to the use of her personal data;
(b) for the State and any of its instrumentalities to provide or issue to the Data Principal any subsidy, benefit, service, certificate, licence or permit;
(c) for the performance by the State or any of its instrumentalities of any function under any law for the time being in force in India or in the interest of sovereignty and integrity of India or security of the State;
(d) for compliance with any judgment or decree or order issued under any law;
(e) for responding to a medical emergency involving a threat to the life or immediate threat to the health of the Data Principal or any other individual;
(f) for taking measures to provide medical treatment or health services to any individual during an epidemic, outbreak of disease, or any other threat to public health;
(g) for taking measures to ensure safety of, or provide assistance or services to any individual during any disaster, or any breakdown of public order;
(h) for the purposes of employment or those related to safeguarding the employer from loss or liability, such as prevention of corporate espionage, maintenance of confidentiality of trade secrets, intellectual property, classified information or provision of any service or benefit sought by a Data Principal who is an employee.
            """.trimIndent(),
            simplifiedExplanation = """
• Non-Consent Processing: In specific situations, a company or the State can process data WITHOUT asking for explicit consent:
  1. Voluntary Provision: If you walk into a restaurant and give your phone number for bill generation or reservation.
  2. Government Welfare & Subsidies: For Aadhaar-linked rations, welfare schemes, licenses, or passports.
  3. Medical Emergencies: If an unconscious accident victim is brought to an emergency room, doctors can access medical records immediately.
  4. Disasters & Epidemics: Quarantine tracking during virus outbreaks or disaster rescue operations.
  5. Employment & Workplace: Employers can process employee data for payroll, biometric attendance, safeguarding trade secrets, and corporate asset security.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Hospital Emergency Room",
                    industry = "Healthcare",
                    scenario = "A patient arrives unconscious at an ICU following a highway crash. The hospital runs blood group tests and accesses prior hospital records without consent.",
                    complianceAnalysis = "Permissible under Section 7(e) as a legitimate use to respond to an immediate life threat."
                ),
                PracticalExample(
                    title = "Employee Laptop Monitoring & Attendance",
                    industry = "Corporate HR / IT",
                    scenario = "An IT firm logs office entry biometrics and monitors corporate laptops to prevent theft of proprietary source code.",
                    complianceAnalysis = "Permitted under Section 7(h) for employment and safeguarding the employer from espionage and intellectual property loss."
                )
            ),
            keyTakeaways = listOf(
                "Covers situations where asking for consent is impractical or impossible",
                "Voluntary provision for a specific purpose",
                "Medical emergencies & public health epidemics",
                "Disaster management & public order breakdown",
                "Employment-related processing and IP safeguarding"
            )
        ),
        DpdpSection(
            number = 8,
            sectionLabel = "Section 8",
            title = "General obligations of Data Fiduciary",
            chapterId = 2,
            chapterName = "CHAPTER II: OBLIGATIONS OF DATA FIDUCIARY",
            category = DpdpCategory.FIDUCIARY_DUTIES,
            maxPenalty = "Up to ₹250 Crore (Item 1 of Schedule)",
            bareActText = """
8. (1) A Data Fiduciary shall be responsible for complying with the provisions of this Act and the rules made thereunder in respect of any processing undertaken by it or on its behalf by a Data Processor.
(2) A Data Fiduciary may engage, appoint, use or otherwise involve a Data Processor to process personal data on its behalf for any activity related to offering of goods or services to Data Principals only under a valid contract.
(3) Where personal data processed by a Data Fiduciary is likely to be—
(a) used to make a decision that affects the Data Principal; or
(b) disclosed to another Data Fiduciary,
the Data Fiduciary processing such personal data shall ensure its completeness, accuracy and consistency.
(4) A Data Fiduciary shall implement appropriate technical and organisational measures to ensure effective adherence to the provisions of this Act.
(5) A Data Fiduciary shall protect personal data in its possession or under its control, including in respect of any processing undertaken by it or on its behalf by a Data Processor, by taking reasonable security safeguards to prevent personal data breach.
(6) In the event of a personal data breach, the Data Fiduciary shall give the Board and each affected Data Principal intimation of such breach in such form and manner as may be prescribed.
(7) A Data Fiduciary shall, unless retention is necessary for compliance with any law,—
(a) erase personal data upon the Data Principal withdrawing her consent or as soon as it is reasonable to assume that the specified purpose is no longer being served;
(b) cause its Data Processor to erase personal data that was provided to such Data Processor.
(8) The Data Fiduciary shall publish in such manner as may be prescribed, the business contact information of a Data Protection Officer or a person who is able to answer on behalf of the Data Fiduciary, the questions, if any, raised by the Data Principal about the processing of her personal data.
(9) A Data Fiduciary shall establish an effective mechanism to redress the grievances of Data Principals.
(10) For the purposes of sub-section (7), the specified purpose will be deemed to no longer be served if the Data Principal does not approach the Data Fiduciary for the performance of the specified purpose and has not initiated any contact with the Data Fiduciary for such period as may be prescribed.
            """.trimIndent(),
            simplifiedExplanation = """
• Overall Accountability: The Data Fiduciary is 100% accountable, even if the leak occurred on a third-party vendor's cloud server!
• Valid Contracts: Can only engage Data Processors under a written, legally binding contract.
• Security Safeguards: Must deploy technical encryption, firewalls, and access controls. Failure to do so attracts penalties up to ₹250 CRORE.
• Mandatory Breach Notification: If a breach occurs, the company MUST notify BOTH:
  1. The Data Protection Board of India; AND
  2. Each affected citizen (Data Principal).
• Storage Limitation & Erasure: Data must be permanently deleted once the user withdraws consent or the account becomes dormant/purpose ends.
• Grievance Redressal: Must publish contact details of a Data Protection Officer / grievance officer.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Database Leak via Cloud Vendor",
                    industry = "FinTech",
                    scenario = "A loan app hires an outsourced analytics vendor. The vendor misconfigures an AWS S3 bucket, exposing 500,000 Aadhaar records publicly.",
                    complianceAnalysis = "Under Section 8(1) & 8(5), the loan app is legally responsible. It must immediately inform the Board and affected users, facing up to ₹250 Crore penalty if reasonable safeguards were omitted."
                ),
                PracticalExample(
                    title = "Auto-Deletion of Dormant Accounts",
                    industry = "Online Classifieds",
                    scenario = "A user hasn't logged into an online classifieds portal for 3 years after selling their bike.",
                    complianceAnalysis = "Under Section 8(7) & 8(10), the fiduciary must erase the user's personal data as the purpose has expired."
                )
            ),
            keyTakeaways = listOf(
                "Fiduciary remains liable for processors' actions",
                "Failure to protect data attracts up to ₹250 Crore fine",
                "Mandatory breach intimation to Board AND affected users",
                "Data erasure required when purpose ends or consent withdrawn",
                "Must provide effective grievance redressal mechanism"
            )
        ),
        DpdpSection(
            number = 9,
            sectionLabel = "Section 9",
            title = "Processing of personal data of children",
            chapterId = 2,
            chapterName = "CHAPTER II: OBLIGATIONS OF DATA FIDUCIARY",
            category = DpdpCategory.CHILDREN,
            maxPenalty = "Up to ₹200 Crore (Item 2 of Schedule)",
            bareActText = """
9. (1) The Data Fiduciary shall, before processing any personal data of a child or a person with disability who has a lawful guardian, obtain verifiable consent of the parent of such child or the lawful guardian, as the case may be, in such manner as may be prescribed.
(2) A Data Fiduciary shall not undertake such processing of personal data that is likely to cause any detrimental effect on the well-being of a child.
(3) A Data Fiduciary shall not undertake tracking or behavioural monitoring of children or targeted advertising directed at children.
(4) The provisions of sub-sections (1) and (3) shall not apply to tracking or behavioural monitoring of children or targeted advertising directed at children by such class of Data Fiduciaries or for such purposes as may be prescribed by the Central Government.
(5) The Central Government may, if satisfied that a Data Fiduciary has ensured that its processing of personal data of children is done in a manner that is verifiably safe, by notification for such processing, exempt such Data Fiduciary or class of Data Fiduciaries from the application of sub-sections (1) and (3), or both, subject to such conditions as may be specified.
            """.trimIndent(),
            simplifiedExplanation = """
• Age Threshold: A child is strictly anyone under 18 years of age.
• Verifiable Parental Consent: Apps and platforms MUST obtain verified consent from parents/guardians before onboarding a child.
• Absolute Bans on Children's Data:
  1. NO Tracking or Behavioural Profiling of minors.
  2. NO Targeted Advertising directed at children.
  3. NO processing likely to cause detrimental effect to a child's physical or mental well-being.
• Heavy Penalty: Violating children's data obligations carries penalties up to ₹200 CRORE!
• Government Exemption: Central Government may grant relaxations to verifiably safe educational institutions or health platforms.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Gaming App Serving Targeted Ads to 14-Year Old",
                    industry = "Mobile Gaming",
                    scenario = "A popular multiplayer mobile game tracks in-game behavior of 12–15 year olds to serve targeted cosmetic skin purchases.",
                    complianceAnalysis = "Strictly prohibited under Section 9(3). Behavioral monitoring and targeted ads for minors are illegal, risking fines up to ₹200 Crore."
                ),
                PracticalExample(
                    title = "EdTech School Platform",
                    industry = "Education",
                    scenario = "A school homework portal collects student project submissions.",
                    complianceAnalysis = "Must obtain verifiable parental consent under Section 9(1) or operate under safe processing exemptions notified under Section 9(5)."
                )
            ),
            keyTakeaways = listOf(
                "Child = Individual under 18 years",
                "Mandatory verifiable parental/guardian consent",
                "Total ban on behavioral tracking and targeted advertising for children",
                "Zero tolerance for detrimental processing on child well-being",
                "Non-compliance attracts up to ₹200 Crore penalty"
            )
        ),
        DpdpSection(
            number = 10,
            sectionLabel = "Section 10",
            title = "Additional obligations of Significant Data Fiduciary",
            chapterId = 2,
            chapterName = "CHAPTER II: OBLIGATIONS OF DATA FIDUCIARY",
            category = DpdpCategory.SIGNIFICANT_FIDUCIARY,
            maxPenalty = "Up to ₹150 Crore (Item 3 of Schedule)",
            bareActText = """
10. (1) The Central Government may notify any Data Fiduciary or class of Data Fiduciaries as Significant Data Fiduciary, on the basis of an assessment of such relevant factors, including—
(a) the volume and sensitivity of personal data processed;
(b) risk to the rights of Data Principals;
(c) potential impact on the sovereignty and integrity of India;
(d) risk to electoral democracy;
(e) security of the State; and
(f) public order.

(2) The Significant Data Fiduciary shall—
(a) appoint an individual as Data Protection Officer, who shall—
    (i) represent the Significant Data Fiduciary under this Act;
    (ii) be based in India;
    (iii) be an individual responsible to the Board of Directors or similar governing body of the Significant Data Fiduciary; and
    (iv) be the point of contact for the grievance redressal mechanism under this Act;
(b) appoint an independent data auditor to carry out data audit, who shall evaluate the compliance of the Significant Data Fiduciary in accordance with the provisions of this Act;
(c) undertake the following other measures, namely:—
    (i) periodic Data Protection Impact Assessment, which shall be a process comprising a description of the rights of Data Principals and the purpose of processing of their personal data, assessment and management of the risk to the rights of the Data Principals, and such other matters regarding such process as may be prescribed;
    (ii) periodic audit; and
    (iii) such other measures, consistent with the provisions of this Act, as may be prescribed.
            """.trimIndent(),
            simplifiedExplanation = """
• Who is an SDF?: Large entities processing massive volumes of sensitive data, social media giants, large telecom providers, big banks, or companies impacting electoral democracy and national security.
• Extra Compliance Duties:
  1. Resident DPO: Must appoint a Data Protection Officer who MUST be physically based in India and report directly to the Board of Directors.
  2. Independent Data Auditor: Must hire external certified auditors to evaluate DPDP compliance.
  3. DPIA (Data Protection Impact Assessment): Must conduct periodic formal impact assessments before launching new algorithms or data processing tools.
  4. Periodic Audits: Continuous independent algorithmic and data governance reviews.
            """.trimIndent(),
            practicalExamples = listOf(
                PracticalExample(
                    title = "Social Media Giant with 100M Indian Users",
                    industry = "Big Tech / Social Media",
                    scenario = "A global social network operating in India is designated as an SDF by MeitY.",
                    complianceAnalysis = "Under Section 10(2), the company cannot rely solely on its Silicon Valley or Dublin privacy team; it must appoint an India-resident DPO reporting to the Board, and conduct annual external DPIAs."
                )
            ),
            keyTakeaways = listOf(
                "Government designates SDFs based on volume, sensitivity, and systemic risk",
                "Mandatory India-resident Data Protection Officer reporting to Board",
                "Appointment of independent external data auditor",
                "Periodic Data Protection Impact Assessments (DPIA) required"
            )
        )
    )
}
