package com.example.ui.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import com.example.ui.theme.Gold500

@Composable
fun HighlightText(
    text: String,
    highlight: String,
    modifier: Modifier = Modifier,
    style: TextStyle = MaterialTheme.typography.bodyMedium,
    color: Color = MaterialTheme.colorScheme.onSurface,
    maxLines: Int = Int.MAX_VALUE
) {
    if (highlight.isBlank()) {
        Text(
            text = text,
            modifier = modifier,
            style = style,
            color = color,
            maxLines = maxLines
        )
        return
    }

    val annotatedString = buildAnnotatedString {
        var currentIndex = 0
        val lowerText = text.lowercase()
        val lowerHighlight = highlight.trim().lowercase()

        while (currentIndex < text.length) {
            val startIndex = lowerText.indexOf(lowerHighlight, currentIndex)
            if (startIndex == -1) {
                append(text.substring(currentIndex))
                break
            }

            // Append unhighlighted preceding text
            if (startIndex > currentIndex) {
                append(text.substring(currentIndex, startIndex))
            }

            // Append highlighted text
            val endIndex = (startIndex + lowerHighlight.length).coerceAtMost(text.length)
            withStyle(
                style = SpanStyle(
                    background = Gold500.copy(alpha = 0.35f),
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            ) {
                append(text.substring(startIndex, endIndex))
            }

            currentIndex = endIndex
        }
    }

    Text(
        text = annotatedString,
        modifier = modifier,
        style = style,
        color = color,
        maxLines = maxLines
    )
}
