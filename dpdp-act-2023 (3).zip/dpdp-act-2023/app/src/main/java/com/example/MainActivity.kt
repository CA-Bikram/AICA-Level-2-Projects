package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.DpdpDatabase
import com.example.data.repository.DpdpRepository
import com.example.ui.components.AppBottomBar
import com.example.ui.components.AppTopBar
import com.example.ui.screens.BookmarksScreen
import com.example.ui.screens.ChaptersScreen
import com.example.ui.screens.GlossaryScreen
import com.example.ui.screens.PenaltiesScreen
import com.example.ui.screens.SectionDetailScreen
import com.example.ui.screens.SectionsListScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.DpdpViewModel
import com.example.ui.viewmodel.NavigationDestination
import com.example.ui.viewmodel.ThemeMode

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = DpdpDatabase.getDatabase(applicationContext)
        val repository = DpdpRepository(database.dpdpUserDao())
        val viewModelFactory = DpdpViewModel.Factory(repository)

        setContent {
            val viewModel: DpdpViewModel = viewModel(factory = viewModelFactory)
            val uiState by viewModel.uiState.collectAsState()
            val bookmarkedIds by viewModel.bookmarkedSectionNumbers.collectAsState()
            val readIds by viewModel.readSectionNumbers.collectAsState()
            val filteredSections by viewModel.filteredSections.collectAsState()

            val isDark = when (uiState.themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            MyApplicationTheme(darkTheme = isDark) {
                // Back press handling
                BackHandler(enabled = uiState.currentDestination == NavigationDestination.SECTION_DETAIL || uiState.searchQuery.isNotEmpty()) {
                    if (uiState.currentDestination == NavigationDestination.SECTION_DETAIL) {
                        viewModel.navigateTo(NavigationDestination.HOME)
                    } else if (uiState.searchQuery.isNotEmpty()) {
                        viewModel.setSearchQuery("")
                    }
                }

                Scaffold(
                    topBar = {
                        if (uiState.currentDestination != NavigationDestination.SECTION_DETAIL) {
                            AppTopBar(
                                title = when (uiState.currentDestination) {
                                    NavigationDestination.HOME -> "DPDP Act, 2023"
                                    NavigationDestination.CHAPTERS -> "Chapters of the Act"
                                    NavigationDestination.BOOKMARKS -> "Bookmarked Provisions"
                                    NavigationDestination.PENALTIES -> "The Schedule (Penalties)"
                                    NavigationDestination.GLOSSARY -> "Legal Glossary"
                                    else -> "DPDP Act, 2023"
                                },
                                subtitle = when (uiState.currentDestination) {
                                    NavigationDestination.HOME -> "Bare Act • Plain English • Real Examples"
                                    NavigationDestination.CHAPTERS -> "9 Chapters • 44 Sections + Schedule"
                                    NavigationDestination.BOOKMARKS -> "${bookmarkedIds.size} saved provisions"
                                    NavigationDestination.PENALTIES -> "Penalties up to ₹250 Crore"
                                    NavigationDestination.GLOSSARY -> "Section 2 Statutory Terms"
                                    else -> null
                                },
                                themeMode = uiState.themeMode,
                                fontScale = uiState.fontScale,
                                onToggleTheme = { viewModel.toggleTheme() },
                                onCycleFontScale = { viewModel.cycleFontScale() }
                            )
                        }
                    },
                    bottomBar = {
                        if (uiState.currentDestination != NavigationDestination.SECTION_DETAIL) {
                            AppBottomBar(
                                currentDestination = uiState.currentDestination,
                                bookmarkedCount = bookmarkedIds.size,
                                onNavigate = { destination ->
                                    viewModel.navigateTo(destination)
                                }
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Crossfade(
                        targetState = uiState.currentDestination,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding),
                        label = "screen_transition"
                    ) { destination ->
                        when (destination) {
                            NavigationDestination.HOME -> {
                                SectionsListScreen(
                                    sections = filteredSections,
                                    uiState = uiState,
                                    bookmarkedIds = bookmarkedIds,
                                    readIds = readIds,
                                    onQueryChange = { viewModel.setSearchQuery(it) },
                                    onCategorySelected = { viewModel.setCategory(it) },
                                    onClearChapterFilter = { viewModel.setChapterFilter(null) },
                                    onClearAllFilters = { viewModel.clearFilters() },
                                    onSectionClick = { viewModel.openSection(it) },
                                    onToggleBookmark = { viewModel.toggleBookmark(it) },
                                    onToggleRead = { viewModel.toggleReadStatus(it) }
                                )
                            }
                            NavigationDestination.CHAPTERS -> {
                                ChaptersScreen(
                                    chapters = viewModel.chapters,
                                    onChapterClick = { chapterId ->
                                        viewModel.selectChapterFromList(chapterId)
                                    }
                                )
                            }
                            NavigationDestination.BOOKMARKS -> {
                                val bookmarkedList = viewModel.allSections.filter { bookmarkedIds.contains(it.number) }
                                BookmarksScreen(
                                    bookmarkedSections = bookmarkedList,
                                    bookmarkedIds = bookmarkedIds,
                                    readIds = readIds,
                                    onSectionClick = { viewModel.openSection(it) },
                                    onToggleBookmark = { viewModel.toggleBookmark(it) },
                                    onToggleRead = { viewModel.toggleReadStatus(it) },
                                    onExploreProvisions = { viewModel.navigateTo(NavigationDestination.HOME) }
                                )
                            }
                            NavigationDestination.PENALTIES -> {
                                PenaltiesScreen(
                                    penalties = viewModel.penaltyEntries,
                                    onNavigateToSection = { sectionNumber ->
                                        viewModel.openSection(sectionNumber)
                                    }
                                )
                            }
                            NavigationDestination.GLOSSARY -> {
                                GlossaryScreen(
                                    items = viewModel.glossaryItems
                                )
                            }
                            NavigationDestination.SECTION_DETAIL -> {
                                val currentSection = viewModel.getSection(uiState.selectedSectionNumber)
                                if (currentSection != null) {
                                    val prevSec = viewModel.getPreviousSection(currentSection.number)
                                    val nextSec = viewModel.getNextSection(currentSection.number)

                                    SectionDetailScreen(
                                        section = currentSection,
                                        isBookmarked = bookmarkedIds.contains(currentSection.number),
                                        isRead = readIds.contains(currentSection.number),
                                        fontScale = uiState.fontScale,
                                        viewMode = uiState.detailViewMode,
                                        noteDraft = uiState.noteDraft,
                                        isNoteEditing = uiState.isNoteEditing,
                                        onBackClick = { viewModel.navigateTo(NavigationDestination.HOME) },
                                        onToggleBookmark = { viewModel.toggleBookmark(currentSection.number) },
                                        onToggleRead = { viewModel.toggleReadStatus(currentSection.number) },
                                        onSetViewMode = { viewModel.setDetailViewMode(it) },
                                        onNoteDraftChange = { viewModel.updateNoteDraft(it) },
                                        onToggleNoteEditing = { viewModel.toggleNoteEditing(it) },
                                        onSaveNote = { viewModel.saveCurrentNote(currentSection.number) },
                                        onNavigatePrevious = prevSec?.let { { viewModel.openSection(it.number) } },
                                        onNavigateNext = nextSec?.let { { viewModel.openSection(it.number) } }
                                    )
                                } else {
                                    viewModel.navigateTo(NavigationDestination.HOME)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

