package com.example.data.repository

import com.example.data.model.LegalGlossaryItem

object DpdpGlossaryData {
    val items: List<LegalGlossaryItem> = listOf(
        LegalGlossaryItem(
            term = "Data Principal",
            sectionReference = "Section 2(j)",
            legalDefinition = "The individual to whom the personal data relates and where such individual is a child, includes the parents or lawful guardian; and where such individual is a person with disability, includes her lawful guardian.",
            simplifiedMeaning = "The human being whose personal details are being collected. In simple terms: You, the citizen, consumer, patient, or employee.",
            practicalExample = "When you sign up for WhatsApp, order food on Swiggy, or consult a doctor on Practo, you are the Data Principal."
        ),
        LegalGlossaryItem(
            term = "Data Fiduciary",
            sectionReference = "Section 2(i)",
            legalDefinition = "Any person who alone or in conjunction with other persons determines the purpose and means of processing of personal data.",
            simplifiedMeaning = "The company, bank, mobile app, hospital, university, or government entity that decides WHY and HOW your data is collected and processed.",
            practicalExample = "HDFC Bank collecting your KYC, Uber deciding driver matching algorithms, or Flipkart holding your purchase history."
        ),
        LegalGlossaryItem(
            term = "Data Processor",
            sectionReference = "Section 2(k)",
            legalDefinition = "Any person who processes personal data on behalf of a Data Fiduciary.",
            simplifiedMeaning = "A third-party vendor hired by the company to perform technical tasks (e.g. cloud hosting, payroll, SMS gateways, analytics) without deciding the underlying purpose.",
            practicalExample = "Amazon Web Services (AWS) hosting an app's database, or Twilio sending OTP SMS messages on behalf of a food delivery company."
        ),
        LegalGlossaryItem(
            term = "Significant Data Fiduciary (SDF)",
            sectionReference = "Section 2(w) & Section 10",
            legalDefinition = "Any Data Fiduciary or class of Data Fiduciaries as may be notified by the Central Government on factors such as volume and sensitivity of data, risk to rights, sovereignty, security of State, and electoral democracy.",
            simplifiedMeaning = "High-impact organizations (like mega social media platforms, major banks, national telecom operators) subjected to stricter obligations like an India-based DPO, independent data audits, and regular DPIAs.",
            practicalExample = "A social media platform with over 100 million Indian active users or a national credit rating bureau."
        ),
        LegalGlossaryItem(
            term = "Consent Manager",
            sectionReference = "Section 2(g) & Section 6(7)",
            legalDefinition = "A person registered with the Board, who acts as a single point of contact to enable a Data Principal to give, manage, review and withdraw her consent through an accessible, transparent and interoperable platform.",
            simplifiedMeaning = "A regulated digital dashboard where you can see all the companies you've given consent to, and revoke or modify your permissions in one click (similar to UPI or RBI Account Aggregators).",
            practicalExample = "A unified privacy app on your phone allowing you to see and cancel 10 different app marketing permissions simultaneously."
        ),
        LegalGlossaryItem(
            term = "Personal Data",
            sectionReference = "Section 2(r)",
            legalDefinition = "Any data about an individual who is identifiable by or in relation to such data.",
            simplifiedMeaning = "Any piece of information that can identify a living person directly (name, phone, Aadhaar) or indirectly (email, GPS coordinates, device advertising ID, IP address).",
            practicalExample = "Your home address, biometric fingerprint, browsing cookies linked to your profile, or blood test report."
        ),
        LegalGlossaryItem(
            term = "Personal Data Breach",
            sectionReference = "Section 2(s)",
            legalDefinition = "Any unauthorised processing of personal data or accidental disclosure, acquisition, sharing, use, alteration, destruction of or loss of access to personal data, that compromises the confidentiality, integrity or availability of personal data.",
            simplifiedMeaning = "Any incident where data is leaked, hacked, mistakenly posted online, altered by an attacker, or encrypted by ransomware causing loss of access.",
            practicalExample = "A cloud database left unsecured without a password, or a hacker selling customer phone numbers on the dark web."
        ),
        LegalGlossaryItem(
            term = "Child",
            sectionReference = "Section 2(f)",
            legalDefinition = "An individual who has not completed the age of eighteen years.",
            simplifiedMeaning = "Strict cutoff: Anyone below 18 years old. Requires verifiable parental consent before processing, with zero tracking or targeted advertising permitted.",
            practicalExample = "A 16-year-old high school student registering on a gaming or learning app."
        ),
        LegalGlossaryItem(
            term = "Verifiable Parental Consent",
            sectionReference = "Section 9(1)",
            legalDefinition = "Obtaining verifiable consent of the parent or lawful guardian before processing any personal data of a child or person with disability.",
            simplifiedMeaning = "Methods to ensure a parent actually approved the child's account (e.g. through Aadhaar OTP, credit card micro-charge, DigiLocker verification, or school authorization).",
            practicalExample = "A parent receiving an SMS OTP and approving their 12-year-old child's online chess coaching account."
        ),
        LegalGlossaryItem(
            term = "Data Protection Officer (DPO)",
            sectionReference = "Section 10(2)(a)",
            legalDefinition = "An individual based in India, responsible to the Board of Directors of a Significant Data Fiduciary, who serves as the representative under the Act and the point of contact for grievance redressal.",
            simplifiedMeaning = "The executive in charge of enterprise privacy compliance, who must reside physically in India and answer directly to the company's Board of Directors.",
            practicalExample = "The senior privacy officer at an Indian unicorn who liaises with the Data Protection Board and handles user data appeals."
        ),
        LegalGlossaryItem(
            term = "Data Protection Impact Assessment (DPIA)",
            sectionReference = "Section 10(2)(c)(i)",
            legalDefinition = "A process comprising a description of the rights of Data Principals and the purpose of processing, assessment and management of the risk to the rights of Data Principals.",
            simplifiedMeaning = "A risk assessment checklist conducted before rolling out risky technologies (e.g. facial recognition, AI algorithms, biometric attendance) to prevent privacy harms.",
            practicalExample = "An airline testing facial recognition boarding gates must carry out a DPIA to ensure biometric templates are encrypted and automatically deleted after flight departure."
        ),
        LegalGlossaryItem(
            term = "Appellate Tribunal (TDSAT)",
            sectionReference = "Section 2(a) & Section 29",
            legalDefinition = "The Telecom Disputes Settlement and Appellate Tribunal established under Section 14 of the TRAI Act, 1997.",
            simplifiedMeaning = "The judicial appellate body that hears appeals against penalty orders and directions issued by the Data Protection Board of India.",
            practicalExample = "If a company is fined ₹100 Crore by the Board, it files an appeal within 60 days before TDSAT in New Delhi."
        )
    )
}
