package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Legal Palette (Navy & Deep Indigo)
val Navy900 = Color(0xFF0A192F)
val Navy800 = Color(0xFF102A43)
val Navy700 = Color(0xFF1E3A5F)
val Navy600 = Color(0xFF243B53)
val Navy100 = Color(0xFFDCEEFB)
val Navy50 = Color(0xFFF0F4F8)

// Secondary Accent (Warm Gold / Bronze)
val Gold600 = Color(0xFFB45309)
val Gold500 = Color(0xFFD97706)
val Gold400 = Color(0xFFF59E0B)
val Gold100 = Color(0xFFFEF3C7)
val Gold50 = Color(0xFFFFFBEB)

// Severity / Penalty Colors
val RedError = Color(0xFFDC2626)
val RedLight = Color(0xFFFEE2E2)
val GreenSuccess = Color(0xFF059669)
val GreenLight = Color(0xFFD1FAE5)
val BlueInfo = Color(0xFF2563EB)
val BlueLight = Color(0xFFDBEAFE)

// Light Theme Neutrals
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightOutline = Color(0xFFCBD5E1)

// Dark Theme Neutrals
val DarkBackground = Color(0xFF0B1320)
val DarkSurface = Color(0xFF131F33)
val DarkSurfaceVariant = Color(0xFF1E2D47)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkOutline = Color(0xFF334155)

