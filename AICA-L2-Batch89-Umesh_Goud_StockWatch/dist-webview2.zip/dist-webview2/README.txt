STOCK WATCH - SINGLE-FILE WINDOWS EDITION

Double-click Stock Watch.exe. You may copy and run this EXE by itself.
No Python installation, project source or _internal folder is required.

Requirements: Windows 10/11 x64 with Microsoft Edge WebView2 Runtime
and .NET Framework 4.6.2 or newer (normally present on current Windows).
WebView2 Runtime: https://developer.microsoft.com/microsoft-edge/webview2/
Internet access is required to retrieve new market data.

The EXE is 58,915,482 bytes (58.92 MB; 56.19 MiB), below 100 MB.
It extracts its bundled Python/application files to Windows temporary storage
when launched. The WebView2 browser engine is supplied by Windows separately.
This is not an offline installer for the WebView2 Runtime.

User data and exports remain in %LOCALAPPDATA%\Stock Watch\.
The existing Qt edition is preserved in the original dist\Stock Watch folder.
The executable is unsigned; Windows may show an unknown-publisher prompt.

Packaging preserves the existing backend calculations and HTML interface.
Only the desktop host/bridge was changed to avoid bundling Qt's browser engine.
