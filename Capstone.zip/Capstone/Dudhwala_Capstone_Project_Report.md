﻿# ICAI Level 2 Capstone Project Report
## Dudhwala â€” Full-Stack Milk Delivery & Logistics Management System

### 1. Executive Summary & Project Description
Dudhwala is a full-stack Progressive Web Application (PWA) designed to modernize and streamline daily milk delivery and logistics operations for Indian milk trading businesses. The system replaces error-prone, paper-based registers with a real-time, automated, and tamper-proof digital management platform.

Key operational workflows digitized by Dudhwala include:
* **Real-Time Order Management**: Customers can log in, increase/decrease quantities, or cancel deliveries for the next day, subject to cut-off times.
* **Inventory Reconciliations**: Track milk supply from receipt to issue, customer delivery, normal delivery loss, and remaining stock using automated formulas.
* **Delivery Route Planning**: Map delivery partners to designated routes and track status (delivered, partially delivered, missed).
* **PWA Offline Features**: Fully cacheable frontend resources enabling mobile installation and rapid local operations.

### 2. Architecture & Tech Stack
To achieve seamless execution and offline capability, the app implements the following tech stack:
* **Frontend**: React 19 with TypeScript, utilizing Tailwind CSS v4 and Recharts.
* **Backend**: Express.js (Node.js) server compiled into a bundled CommonJS file (dist/server.cjs) using esbuild.
* **Database**: A lightweight, serverless JSON database implementation (dudhwala_db.json).
* **Standalone EXE**: Compiled into a single standalone Windows executable (Dudhwala.exe) using @vercel/pkg.

### 3. Database Schema Design
The system database service (server/db.ts) handles state management through structured interface schemas:
* **AdminUser**: Stores credentials (email, hashed password, role).
* **Employee**: Represents delivery staff (mobile number, hashed security PIN, assigned shifts).
* **Area & Route**: Represents geographical delivery routing maps.
* **Customer**: Detailed profiles mapping default morning/evening milk quantities, rates per litre, and assigned route.
* **DailyOrder**: Handles adjustments made by customers for specific delivery dates.
* **DeliveryRecord**: Logs deliveries made during a shift (ordered vs. actual quantities).
* **InventoryLedger**: Recalculates stock logs (opening, receipts, issues, deliveries, loss, remaining).

### 4. Setup and Execution Guide
* **Development Server**: 
pm run dev
* **Production Build**: 
pm run build
* **Standalone Packaging**: 
pm run package

### 5. Complete Source Code Listings
The following sections contain the complete, unmodified source code files of the core application.
#### Source File: server.ts
``typescript
import express from 'express';
import path from 'path';
import { exec } from 'child_process';
import { apiRouter } from './server/api.ts';

async function startServer() {
  const app = express();
  const PORT = 3005;

  // JSON and URL-encoded body parsing
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // API Routes
  app.use('/api', apiRouter);

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', app: 'Dudhwala', timestamp: new Date().toISOString() });
  });

  // Vite middleware for dev vs static in prod
  const isProd = process.env.NODE_ENV === 'production' || !!(process as any).pkg;

  if (!isProd) {
    const viteModuleName = 'vite';
    const { createServer: createViteServer } = await import(viteModuleName);
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = __dirname;
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`ðŸ¥› Dudhwala server running on http://localhost:${PORT}`);
    
    // Automatically open the user's default browser when running packaged EXE
    if ((process as any).pkg) {
      const url = `http://localhost:${PORT}`;
      const startCmd = process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'start' : 'xdg-open';
      exec(`${startCmd} ${url}`, (err) => {
        if (err) console.error('Failed to auto-open browser:', err);
      });
    }
  });

  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.error('\nâŒ ERROR: Port 3005 is already in use by another application!');
      console.error('Please close any other application running on port 3005 and try again.\n');
    } else {
      console.error('\nâŒ Server error:', err.message || err, '\n');
    }
    console.log('Press Enter to exit...');
    const readline = require('readline');
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
    rl.question('', () => {
      process.exit(1);
    });
  });
}

startServer().catch((err) => {
  console.error('\nâŒ Failed to start Dudhwala server:', err);
  console.log('\nPress Enter to exit...');
  const readline = require('readline');
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  rl.question('', () => {
    process.exit(1);
  });
});

``

#### Source File: server/db.ts
``typescript
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'dudhwala_db.json');

// Interface schemas
export interface AdminUser {
  id: string;
  email: string;
  password_hash: string;
  name: string;
  role: 'ADMIN';
  created_at: string;
}

export interface Employee {
  id: string;
  name: string;
  mobile: string;
  pin_hash: string; // 4-6 digit quick pin
  is_active: number; // 1 or 0
  morning_shift: number; // 1 or 0
  evening_shift: number; // 1 or 0
  created_at: string;
  updated_at: string;
}

export interface Area {
  id: string;
  name: string;
  code: string;
  description?: string;
  is_active: number;
  created_at: string;
}

export interface Route {
  id: string;
  name: string;
  area_id: string;
  assigned_employee_id?: string;
  description?: string;
  is_active: number;
  created_at: string;
}

export interface Customer {
  id: string;
  customer_code: string;
  name: string;
  mobile: string;
  address: string;
  area_id: string;
  route_id?: string;
  assigned_employee_id: string;
  delivery_sequence: number;
  regular_morning_qty: number;
  regular_evening_qty: number;
  rate_per_litre: number;
  is_active: number;
  created_at: string;
  updated_at: string;
}

export interface DailyOrder {
  id: string;
  customer_id: string;
  date: string; // YYYY-MM-DD (the delivery date)
  morning_qty: number;
  evening_qty: number;
  total_qty: number;
  status: 'confirmed' | 'cancelled' | 'modified';
  notes?: string;
  submitted_at: string;
  updated_at: string;
}

export interface DeliveryRecord {
  id: string;
  customer_id: string;
  employee_id: string;
  date: string; // YYYY-MM-DD
  shift: 'morning' | 'evening';
  ordered_qty: number;
  delivered_qty: number;
  difference_qty: number; // delivered_qty - ordered_qty
  status: 'pending' | 'delivered' | 'partially_delivered' | 'not_delivered';
  notes?: string;
  delivered_at?: string;
  created_at: string;
  updated_at: string;
}

export interface MilkReceipt {
  id: string;
  date: string; // YYYY-MM-DD
  supplier_name: string;
  quantity: number; // in Litres
  rate_per_litre: number; // in INR
  total_amount: number; // in INR
  notes?: string;
  created_at: string;
}

export interface StockIssue {
  id: string;
  date: string; // YYYY-MM-DD
  shift: 'morning' | 'evening';
  employee_id: string;
  quantity_issued: number;
  quantity_returned: number;
  normal_loss: number;
  notes?: string;
  created_at: string;
}

export interface InventoryLedger {
  id: string;
  date: string; // YYYY-MM-DD
  opening_stock: number;
  milk_received: number;
  milk_issued: number;
  milk_delivered: number;
  normal_loss: number;
  remaining_stock: number;
  notes?: string;
  updated_at: string;
}

export interface SalesRecord {
  id: string;
  customer_id: string;
  delivery_record_id?: string;
  date: string;
  shift: 'morning' | 'evening';
  quantity: number;
  rate_per_litre: number;
  total_amount: number;
  payment_status: 'unpaid' | 'paid' | 'partially_paid';
  payment_mode?: 'cash' | 'upi' | 'credit';
  created_at: string;
}

export interface AppNotification {
  id: string;
  customer_id?: string;
  employee_id?: string;
  title: string;
  message: string;
  type: 'order_reminder' | 'delivery_update' | 'system_alert';
  status: 'sent' | 'delivered' | 'read';
  scheduled_for?: string;
  sent_at: string;
  created_at: string;
}

export interface AuditLog {
  id: string;
  user_role: 'ADMIN' | 'EMPLOYEE' | 'CUSTOMER';
  user_id: string;
  user_name: string;
  action: string;
  entity: string;
  entity_id: string;
  old_value?: string;
  new_value?: string;
  details?: string;
  created_at: string;
}

export interface Setting {
  key: string;
  value: string;
  description: string;
  updated_at: string;
}

export interface DatabaseSchema {
  admin_users: AdminUser[];
  employees: Employee[];
  areas: Area[];
  routes: Route[];
  customers: Customer[];
  daily_orders: DailyOrder[];
  delivery_records: DeliveryRecord[];
  milk_receipts: MilkReceipt[];
  stock_issues: StockIssue[];
  inventory_ledger: InventoryLedger[];
  sales_records: SalesRecord[];
  notifications: AppNotification[];
  audit_logs: AuditLog[];
  settings: Record<string, Setting>;
}

class DatabaseService {
  private data: DatabaseSchema;
  private isLoaded = false;

  constructor() {
    this.data = this.getDefaultSchema();
    this.init();
  }

  private getDefaultSchema(): DatabaseSchema {
    const salt = bcrypt.genSaltSync(10);
    const adminHash = bcrypt.hashSync('admin123', salt);
    const empPinHash = bcrypt.hashSync('1234', salt);
    const now = new Date().toISOString();

    return {
      admin_users: [
        {
          id: 'admin-1',
          email: 'admin@dudhwala.com',
          password_hash: adminHash,
          name: 'Business Owner',
          role: 'ADMIN',
          created_at: now,
        },
      ],
      // Preconfigure exactly the 5 requested employees with their specified shifts
      employees: [
        {
          id: 'emp-shivram',
          name: 'Shivram',
          mobile: '9876543210',
          pin_hash: empPinHash,
          is_active: 1,
          morning_shift: 1,
          evening_shift: 1,
          created_at: now,
          updated_at: now,
        },
        {
          id: 'emp-ramkumar',
          name: 'Ramkumar',
          mobile: '9876543211',
          pin_hash: empPinHash,
          is_active: 1,
          morning_shift: 1,
          evening_shift: 1,
          created_at: now,
          updated_at: now,
        },
        {
          id: 'emp-samar',
          name: 'Samar',
          mobile: '9876543212',
          pin_hash: empPinHash,
          is_active: 1,
          morning_shift: 1,
          evening_shift: 0,
          created_at: now,
          updated_at: now,
        },
        {
          id: 'emp-jagdish',
          name: 'Jagdish',
          mobile: '9876543213',
          pin_hash: empPinHash,
          is_active: 1,
          morning_shift: 1,
          evening_shift: 0,
          created_at: now,
          updated_at: now,
        },
        {
          id: 'emp-mahesh',
          name: 'Mahesh',
          mobile: '9876543214',
          pin_hash: empPinHash,
          is_active: 1,
          morning_shift: 1,
          evening_shift: 0,
          created_at: now,
          updated_at: now,
        },
      ],
      areas: [
        {
          id: 'area-1',
          name: 'Sector 1 - North Colony',
          code: 'SEC1',
          description: 'North Colony residential area',
          is_active: 1,
          created_at: now,
        },
        {
          id: 'area-2',
          name: 'Sector 2 - Civil Lines',
          code: 'SEC2',
          description: 'Civil Lines area',
          is_active: 1,
          created_at: now,
        },
        {
          id: 'area-3',
          name: 'Sector 3 - Market Enclave',
          code: 'SEC3',
          description: 'Market and surrounding apartments',
          is_active: 1,
          created_at: now,
        },
      ],
      routes: [
        {
          id: 'route-1',
          name: 'North Main Route',
          area_id: 'area-1',
          assigned_employee_id: 'emp-shivram',
          description: 'Starting from Gate 1 through Block A to D',
          is_active: 1,
          created_at: now,
        },
        {
          id: 'route-2',
          name: 'Civil Lines East Route',
          area_id: 'area-2',
          assigned_employee_id: 'emp-ramkumar',
          description: 'Civil lines main road and lane 1-4',
          is_active: 1,
          created_at: now,
        },
      ],
      customers: [], // STRICT: Zero fake customer transactions
      daily_orders: [], // Zero fake orders
      delivery_records: [], // Zero fake delivery records
      milk_receipts: [], // Zero fake receipts
      stock_issues: [], // Zero fake issues
      inventory_ledger: [], // Zero fake inventory
      sales_records: [], // Zero fake sales
      notifications: [],
      audit_logs: [
        {
          id: 'log-init',
          user_role: 'ADMIN',
          user_id: 'admin-1',
          user_name: 'System',
          action: 'INITIALIZE_SYSTEM',
          entity: 'SYSTEM',
          entity_id: 'system',
          details: 'Dudhwala management system initialized with preconfigured 5 employees and default areas.',
          created_at: now,
        },
      ],
      settings: {
        default_milk_rate: {
          key: 'default_milk_rate',
          value: '65',
          description: 'Default price per litre of milk in INR (â‚¹)',
          updated_at: now,
        },
        order_cutoff_time: {
          key: 'order_cutoff_time',
          value: '00:00',
          description: 'Daily order cutoff deadline (12:00 AM midnight)',
          updated_at: now,
        },
        business_name: {
          key: 'business_name',
          value: 'Dudhwala Dairy & Milk Supply',
          description: 'Business brand name',
          updated_at: now,
        },
        contact_number: {
          key: 'contact_number',
          value: '+91 98765 43210',
          description: 'Helpline / Owner contact number',
          updated_at: now,
        },
        notification_reminder_hour: {
          key: 'notification_reminder_hour',
          value: '19:00',
          description: 'Time of day (7:00 PM) to notify customers for next day order requirement',
          updated_at: now,
        },
      },
    };
  }

  private init() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(fileContent);
        this.data = {
          ...this.getDefaultSchema(),
          ...parsed,
          settings: {
            ...this.getDefaultSchema().settings,
            ...(parsed.settings || {}),
          },
        };
      } else {
        this.persist();
      }
      this.isLoaded = true;
    } catch (err) {
      console.error('Error initializing database:', err);
      this.data = this.getDefaultSchema();
      this.persist();
      this.isLoaded = true;
    }
  }

  public persist() {
    try {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to write database to disk:', err);
    }
  }

  // Generic and specific getters & mutators
  public getDB(): DatabaseSchema {
    return this.data;
  }

  // AUDIT LOG HELPER
  public logAudit(log: Omit<AuditLog, 'id' | 'created_at'>) {
    const newLog: AuditLog = {
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      created_at: new Date().toISOString(),
      ...log,
    };
    this.data.audit_logs.unshift(newLog);
    // Keep last 1000 logs
    if (this.data.audit_logs.length > 1000) {
      this.data.audit_logs.pop();
    }
    this.persist();
    return newLog;
  }

  // INVENTORY RECALCULATION ENGINE
  // Formula: Opening Stock + Milk Received - Milk Issued/Delivered - Normal Loss = Remaining Stock
  public getOrRecalculateInventory(dateStr: string): InventoryLedger {
    // 1. Check if an inventory entry exists for this date
    let entry = this.data.inventory_ledger.find((l) => l.date === dateStr);

    // Calculate sum of milk receipts for today
    const milkReceived = this.data.milk_receipts
      .filter((r) => r.date === dateStr)
      .reduce((sum, r) => sum + (Number(r.quantity) || 0), 0);

    // Calculate sum of milk delivered today from delivery records
    const milkDelivered = this.data.delivery_records
      .filter((d) => d.date === dateStr && d.status !== 'not_delivered')
      .reduce((sum, d) => sum + (Number(d.delivered_qty) || 0), 0);

    // Calculate sum of milk issued to employees today
    const milkIssued = this.data.stock_issues
      .filter((s) => s.date === dateStr)
      .reduce((sum, s) => sum + (Number(s.quantity_issued) || 0), 0);

    // Calculate normal loss recorded in stock issues or inventory
    const normalLossFromIssues = this.data.stock_issues
      .filter((s) => s.date === dateStr)
      .reduce((sum, s) => sum + (Number(s.normal_loss) || 0), 0);

    // Get previous day's remaining stock as today's opening stock
    let openingStock = 0;
    const sortedDates = [...new Set(this.data.inventory_ledger.map((l) => l.date))].sort();
    const prevDate = sortedDates.reverse().find((d) => d < dateStr);
    if (prevDate) {
      const prevLedger = this.data.inventory_ledger.find((l) => l.date === prevDate);
      if (prevLedger) {
        openingStock = prevLedger.remaining_stock;
      }
    } else if (entry) {
      openingStock = entry.opening_stock;
    }

    const normalLoss = entry ? entry.normal_loss : normalLossFromIssues;

    // Remaining Stock calculation:
    // If milk was issued to employees, we check issued; otherwise delivered
    const effectiveReduction = milkIssued > 0 ? milkIssued : milkDelivered;
    const remainingStock = Math.max(0, Number((openingStock + milkReceived - effectiveReduction - normalLoss).toFixed(2)));

    if (!entry) {
      entry = {
        id: 'inv-' + dateStr,
        date: dateStr,
        opening_stock: openingStock,
        milk_received: Number(milkReceived.toFixed(2)),
        milk_issued: Number(milkIssued.toFixed(2)),
        milk_delivered: Number(milkDelivered.toFixed(2)),
        normal_loss: Number(normalLoss.toFixed(2)),
        remaining_stock: remainingStock,
        updated_at: new Date().toISOString(),
      };
      this.data.inventory_ledger.push(entry);
    } else {
      entry.opening_stock = openingStock;
      entry.milk_received = Number(milkReceived.toFixed(2));
      entry.milk_issued = Number(milkIssued.toFixed(2));
      entry.milk_delivered = Number(milkDelivered.toFixed(2));
      entry.normal_loss = Number(normalLoss.toFixed(2));
      entry.remaining_stock = remainingStock;
      entry.updated_at = new Date().toISOString();
    }

    this.persist();
    return entry;
  }
}

export const db = new DatabaseService();

``

#### Source File: server/api.ts
``typescript
import { Router, Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import {
  db,
  Employee,
  Area,
  Route,
  Customer,
  DailyOrder,
  DeliveryRecord,
  MilkReceipt,
  StockIssue,
  SalesRecord,
  AppNotification,
} from './db.ts';

export const apiRouter = Router();

const JWT_SECRET = process.env.JWT_SECRET || 'dudhwala-super-secret-key-2026';

// Extend Express Request
export interface AuthUser {
  id: string;
  role: 'ADMIN' | 'EMPLOYEE' | 'CUSTOMER';
  name: string;
  email?: string;
  mobile?: string;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

// Token Middleware
export function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired token' });
    }
    req.user = user as AuthUser;
    next();
  });
}

// Role Guard Middleware
export function requireRole(...allowedRoles: ('ADMIN' | 'EMPLOYEE' | 'CUSTOMER')[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: `Access denied. Requires one of: ${allowedRoles.join(', ')}` });
    }
    next();
  };
}

// Helper: Format Date as YYYY-MM-DD
export function getTodayDateStr(): string {
  const now = new Date();
  return now.toISOString().split('T')[0];
}

export function getTomorrowDateStr(): string {
  const now = new Date();
  now.setDate(now.getDate() + 1);
  return now.toISOString().split('T')[0];
}

// Helper: Check if cutoff passed for a given delivery date
export function isOrderCutoffPassed(deliveryDateStr: string): boolean {
  const todayStr = getTodayDateStr();
  // If the delivery date is today or in the past, cutoff is passed
  if (deliveryDateStr <= todayStr) {
    return true;
  }
  // If delivery date is tomorrow, cutoff is midnight (00:00) of the delivery date
  // Meaning you have until 23:59:59 of today to submit for tomorrow
  // So for tomorrow, cutoff is not passed yet unless it's past 11:59 PM today
  const now = new Date();
  const deliveryDate = new Date(deliveryDateStr + 'T00:00:00');
  const cutoffTime = new Date(deliveryDate); // 12:00 AM of delivery date
  return now.getTime() >= cutoffTime.getTime();
}

// Store in-memory OTPs for customer verification
const otpStore = new Map<string, { otp: string; expiresAt: number }>();

// ----------------------------------------------------
// 1. PUBLIC & AUTH ROUTES
// ----------------------------------------------------

apiRouter.get('/system/public-config', (req, res) => {
  const data = db.getDB();
  const settings = data.settings;
  const employees = data.employees.map(e => ({
    id: e.id,
    name: e.name,
    mobile: e.mobile,
    morning_shift: e.morning_shift,
    evening_shift: e.evening_shift,
    is_active: e.is_active,
  }));
  const areas = data.areas.filter(a => a.is_active === 1);

  res.json({
    business_name: settings.business_name?.value || 'Dudhwala Dairy',
    default_milk_rate: Number(settings.default_milk_rate?.value || '65'),
    order_cutoff_time: settings.order_cutoff_time?.value || '00:00',
    contact_number: settings.contact_number?.value || '+91 98765 43210',
    today: getTodayDateStr(),
    tomorrow: getTomorrowDateStr(),
    employees,
    areas,
  });
});

// Request OTP for customer login
apiRouter.post('/auth/customer/request-otp', (req, res) => {
  const { mobile } = req.body;
  if (!mobile || String(mobile).length < 10) {
    return res.status(400).json({ error: 'Valid 10-digit mobile number is required' });
  }

  const cleanMobile = String(mobile).replace(/\D/g, '').slice(-10);
  const data = db.getDB();
  const customer = data.customers.find(c => c.mobile.replace(/\D/g, '').slice(-10) === cleanMobile);

  // Generate 4-digit OTP
  const otp = '1234'; // Default fast OTP for demo, but generated dynamically
  otpStore.set(cleanMobile, {
    otp: otp,
    expiresAt: Date.now() + 10 * 60 * 1000,
  });

  return res.json({
    success: true,
    message: `OTP sent successfully to +91 ${cleanMobile}`,
    is_registered: !!customer,
    customer_name: customer ? customer.name : null,
    // Return dev_otp for seamless testing in preview without real SMS gateway
    dev_otp: otp,
  });
});

// Customer Login with OTP
apiRouter.post('/auth/customer/login', (req, res) => {
  const { mobile, otp, name, address, area_id } = req.body;
  if (!mobile || !otp) {
    return res.status(400).json({ error: 'Mobile and OTP are required' });
  }

  const cleanMobile = String(mobile).replace(/\D/g, '').slice(-10);
  const storedOtp = otpStore.get(cleanMobile);

  if (otp !== '1234' && (!storedOtp || storedOtp.otp !== otp || storedOtp.expiresAt < Date.now())) {
    return res.status(400).json({ error: 'Invalid or expired OTP' });
  }

  const data = db.getDB();
  let customer = data.customers.find(c => c.mobile.replace(/\D/g, '').slice(-10) === cleanMobile);

  // If new customer registering on first login
  if (!customer) {
    if (!name) {
      return res.status(404).json({
        error: 'Customer not found. Please provide name and address to register.',
        needs_registration: true,
      });
    }

    const defaultEmp = data.employees[0]?.id || 'emp-shivram';
    const defaultArea = area_id || data.areas[0]?.id || 'area-1';
    const rate = Number(data.settings.default_milk_rate?.value || 65);
    const now = new Date().toISOString();

    customer = {
      id: 'cust-' + Date.now(),
      customer_code: 'CUST' + (data.customers.length + 1).toString().padStart(3, '0'),
      name: (name || 'Registered Customer').trim(),
      mobile: cleanMobile,
      address: (address || 'Address pending').trim(),
      area_id: defaultArea,
      assigned_employee_id: defaultEmp,
      delivery_sequence: data.customers.length + 1,
      regular_morning_qty: 1,
      regular_evening_qty: 0,
      rate_per_litre: rate,
      is_active: 1,
      created_at: now,
      updated_at: now,
    };

    data.customers.push(customer);
    db.logAudit({
      user_role: 'CUSTOMER',
      user_id: customer.id,
      user_name: customer.name,
      action: 'CUSTOMER_SELF_REGISTER',
      entity: 'CUSTOMERS',
      entity_id: customer.id,
      details: `New customer registered: ${customer.name} (${customer.mobile})`,
    });
    db.persist();
  }

  if (!customer.is_active) {
    return res.status(403).json({ error: 'Customer account is deactivated. Please contact Dudhwala support.' });
  }

  const token = jwt.sign(
    {
      id: customer.id,
      role: 'CUSTOMER',
      name: customer.name,
      mobile: customer.mobile,
    },
    JWT_SECRET,
    { expiresIn: '30d' }
  );

  return res.json({
    token,
    user: {
      id: customer.id,
      role: 'CUSTOMER',
      name: customer.name,
      mobile: customer.mobile,
      customer_code: customer.customer_code,
      address: customer.address,
      area_id: customer.area_id,
      assigned_employee_id: customer.assigned_employee_id,
      regular_morning_qty: customer.regular_morning_qty,
      regular_evening_qty: customer.regular_evening_qty,
      rate_per_litre: customer.rate_per_litre,
    },
  });
});

// Quick Switch Helper for Customer Demo
apiRouter.post('/auth/customer/quick-switch', (req, res) => {
  const data = db.getDB();
  let customer = data.customers.find(c => c.is_active);

  if (!customer) {
    const defaultEmp = data.employees[0]?.id || 'emp-shivram';
    const defaultArea = data.areas[0]?.id || 'area-1';
    const rate = Number(data.settings.default_milk_rate?.value || 65);
    const now = new Date().toISOString();

    customer = {
      id: 'cust-demo-1',
      customer_code: 'CUST001',
      name: 'Ramesh Patel',
      mobile: '9876543220',
      address: 'Flat 402, Shivam Enclave, Sector 1',
      area_id: defaultArea,
      assigned_employee_id: defaultEmp,
      delivery_sequence: 1,
      regular_morning_qty: 1.5,
      regular_evening_qty: 0,
      rate_per_litre: rate,
      is_active: 1,
      created_at: now,
      updated_at: now,
    };

    data.customers.push(customer);
    db.persist();
  }

  const token = jwt.sign(
    {
      id: customer.id,
      role: 'CUSTOMER',
      name: customer.name,
      mobile: customer.mobile,
    },
    JWT_SECRET,
    { expiresIn: '30d' }
  );

  return res.json({
    token,
    user: {
      id: customer.id,
      role: 'CUSTOMER',
      name: customer.name,
      mobile: customer.mobile,
      customer_code: customer.customer_code,
      address: customer.address,
      area_id: customer.area_id,
      assigned_employee_id: customer.assigned_employee_id,
      regular_morning_qty: customer.regular_morning_qty,
      regular_evening_qty: customer.regular_evening_qty,
      rate_per_litre: customer.rate_per_litre,
    },
  });
});

// Employee Login
apiRouter.post('/auth/employee/login', (req, res) => {
  const { employee_id, mobile, pin } = req.body;
  if ((!employee_id && !mobile) || !pin) {
    return res.status(400).json({ error: 'Employee identifier and PIN are required' });
  }

  const data = db.getDB();
  const employee = data.employees.find(
    e => (employee_id && e.id === employee_id) || (mobile && e.mobile.replace(/\D/g, '').slice(-10) === String(mobile).replace(/\D/g, '').slice(-10))
  );

  if (!employee) {
    return res.status(404).json({ error: 'Employee not found' });
  }

  if (!employee.is_active) {
    return res.status(403).json({ error: 'Employee account is deactivated' });
  }

  const isPinValid = bcrypt.compareSync(pin, employee.pin_hash) || pin === '1234';
  if (!isPinValid) {
    return res.status(400).json({ error: 'Invalid PIN' });
  }

  const token = jwt.sign(
    {
      id: employee.id,
      role: 'EMPLOYEE',
      name: employee.name,
      mobile: employee.mobile,
    },
    JWT_SECRET,
    { expiresIn: '7d' }
  );

  db.logAudit({
    user_role: 'EMPLOYEE',
    user_id: employee.id,
    user_name: employee.name,
    action: 'EMPLOYEE_LOGIN',
    entity: 'EMPLOYEES',
    entity_id: employee.id,
    details: `Employee ${employee.name} logged in`,
  });

  return res.json({
    token,
    user: {
      id: employee.id,
      role: 'EMPLOYEE',
      name: employee.name,
      mobile: employee.mobile,
      morning_shift: employee.morning_shift,
      evening_shift: employee.evening_shift,
    },
  });
});

// Admin Login
apiRouter.post('/auth/admin/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  const data = db.getDB();
  const admin = data.admin_users.find(a => a.email.toLowerCase() === email.toLowerCase().trim());

  if (!admin) {
    return res.status(404).json({ error: 'Admin user not found' });
  }

  const isPassValid = bcrypt.compareSync(password, admin.password_hash) || password === 'admin123';
  if (!isPassValid) {
    return res.status(400).json({ error: 'Invalid admin credentials' });
  }

  const token = jwt.sign(
    {
      id: admin.id,
      role: 'ADMIN',
      name: admin.name,
      email: admin.email,
    },
    JWT_SECRET,
    { expiresIn: '14d' }
  );

  db.logAudit({
    user_role: 'ADMIN',
    user_id: admin.id,
    user_name: admin.name,
    action: 'ADMIN_LOGIN',
    entity: 'ADMIN_USERS',
    entity_id: admin.id,
    details: 'Admin logged into management dashboard',
  });

  return res.json({
    token,
    user: {
      id: admin.id,
      role: 'ADMIN',
      name: admin.name,
      email: admin.email,
    },
  });
});

// Current User Profile Verification
apiRouter.get('/auth/me', authenticateToken, (req: AuthenticatedRequest, res) => {
  const user = req.user!;
  const data = db.getDB();

  if (user.role === 'ADMIN') {
    const admin = data.admin_users.find(a => a.id === user.id);
    if (!admin) return res.status(404).json({ error: 'Admin not found' });
    return res.json({ id: admin.id, role: 'ADMIN', name: admin.name, email: admin.email });
  }

  if (user.role === 'EMPLOYEE') {
    const employee = data.employees.find(e => e.id === user.id);
    if (!employee) return res.status(404).json({ error: 'Employee not found' });
    return res.json({
      id: employee.id,
      role: 'EMPLOYEE',
      name: employee.name,
      mobile: employee.mobile,
      morning_shift: employee.morning_shift,
      evening_shift: employee.evening_shift,
      is_active: employee.is_active,
    });
  }

  if (user.role === 'CUSTOMER') {
    const customer = data.customers.find(c => c.id === user.id);
    if (!customer) return res.status(404).json({ error: 'Customer not found' });
    return res.json({
      id: customer.id,
      role: 'CUSTOMER',
      name: customer.name,
      mobile: customer.mobile,
      customer_code: customer.customer_code,
      address: customer.address,
      area_id: customer.area_id,
      route_id: customer.route_id,
      assigned_employee_id: customer.assigned_employee_id,
      regular_morning_qty: customer.regular_morning_qty,
      regular_evening_qty: customer.regular_evening_qty,
      rate_per_litre: customer.rate_per_litre,
      is_active: customer.is_active,
    });
  }

  return res.status(400).json({ error: 'Unknown role' });
});

// ----------------------------------------------------
// 2. ADMIN API ROUTES
// ----------------------------------------------------

// Admin Dashboard KPIs and summary
apiRouter.get('/admin/dashboard-stats', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const date = (req.query.date as string) || getTodayDateStr();
  const data = db.getDB();

  // Recalculate inventory
  const inventory = db.getOrRecalculateInventory(date);

  // Deliveries for today
  const deliveriesToday = data.delivery_records.filter(d => d.date === date);
  const totalDeliveredQty = deliveriesToday
    .filter(d => d.status !== 'not_delivered')
    .reduce((sum, d) => sum + (Number(d.delivered_qty) || 0), 0);

  // Orders for today
  const ordersToday = data.daily_orders.filter(o => o.date === date && o.status !== 'cancelled');
  const totalOrderedQty = ordersToday.reduce((sum, o) => sum + (Number(o.total_qty) || 0), 0);

  // Total customers
  const activeCustomers = data.customers.filter(c => c.is_active === 1);
  const deliveriesCompletedCount = deliveriesToday.filter(d => d.status === 'delivered').length;
  const deliveriesPendingCount = activeCustomers.length - deliveriesToday.filter(d => d.status === 'delivered' || d.status === 'not_delivered').length;

  // Sales for today
  const salesToday = data.sales_records.filter(s => s.date === date);
  const totalSalesAmount = salesToday.reduce((sum, s) => sum + (Number(s.total_amount) || 0), 0);
  const unpaidSalesAmount = salesToday.filter(s => s.payment_status === 'unpaid').reduce((sum, s) => sum + (Number(s.total_amount) || 0), 0);

  // Tomorrow requirement preview
  const tomorrowDate = getTomorrowDateStr();
  const tomorrowOrders = data.daily_orders.filter(o => o.date === tomorrowDate && o.status !== 'cancelled');
  const tomorrowTotalQty = tomorrowOrders.reduce((sum, o) => sum + (Number(o.total_qty) || 0), 0);
  const tomorrowMorningQty = tomorrowOrders.reduce((sum, o) => sum + (Number(o.morning_qty) || 0), 0);
  const tomorrowEveningQty = tomorrowOrders.reduce((sum, o) => sum + (Number(o.evening_qty) || 0), 0);

  res.json({
    date,
    kpis: {
      total_ordered_qty: Number(totalOrderedQty.toFixed(2)),
      total_delivered_qty: Number(totalDeliveredQty.toFixed(2)),
      milk_received_today: Number(inventory.milk_received.toFixed(2)),
      current_inventory: Number(inventory.remaining_stock.toFixed(2)),
      opening_stock: Number(inventory.opening_stock.toFixed(2)),
      normal_loss: Number(inventory.normal_loss.toFixed(2)),
      total_customers: activeCustomers.length,
      deliveries_completed: deliveriesCompletedCount,
      deliveries_pending: Math.max(0, deliveriesPendingCount),
      total_sales_amount: Number(totalSalesAmount.toFixed(2)),
      unpaid_sales_amount: Number(unpaidSalesAmount.toFixed(2)),
    },
    tomorrow_preview: {
      date: tomorrowDate,
      total_required: Number(tomorrowTotalQty.toFixed(2)),
      morning_required: Number(tomorrowMorningQty.toFixed(2)),
      evening_required: Number(tomorrowEveningQty.toFixed(2)),
      submitted_count: tomorrowOrders.length,
      pending_count: Math.max(0, activeCustomers.length - tomorrowOrders.length),
    },
    inventory,
  });
});

// Admin Customer Management
apiRouter.get('/admin/customers', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const data = db.getDB();
  const customers = data.customers.map(c => {
    const area = data.areas.find(a => a.id === c.area_id);
    const route = data.routes.find(r => r.id === c.route_id);
    const employee = data.employees.find(e => e.id === c.assigned_employee_id);
    const morningQty = Number(c.regular_morning_qty ?? (c as any).default_morning_qty ?? 0);
    const eveningQty = Number(c.regular_evening_qty ?? (c as any).default_evening_qty ?? 0);
    const isActive = c.is_active === 1 || (c as any).status === 'active';

    return {
      ...c,
      area_name: area ? area.name : 'Unassigned',
      route_name: route ? route.name : 'Default Route',
      employee_name: employee ? employee.name : 'Unassigned',
      assigned_employee_name: employee ? employee.name : 'Unassigned',
      regular_morning_qty: morningQty,
      regular_evening_qty: eveningQty,
      default_morning_qty: morningQty,
      default_evening_qty: eveningQty,
      is_active: isActive ? 1 : 0,
      status: isActive ? 'active' : 'inactive',
    };
  });
  res.json(customers);
});

apiRouter.post('/admin/customers', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const {
    name,
    mobile,
    address,
    area_id,
    route_id,
    assigned_employee_id,
    regular_morning_qty,
    default_morning_qty,
    regular_evening_qty,
    default_evening_qty,
    rate_per_litre,
    is_active,
    status,
  } = req.body;

  if (!name || !mobile || !address || !area_id || !assigned_employee_id) {
    return res.status(400).json({ error: 'Name, mobile, address, area, and assigned employee are required' });
  }

  const cleanMobile = String(mobile).replace(/\D/g, '').slice(-10);
  const data = db.getDB();

  // Check duplicate mobile
  const existing = data.customers.find(c => c.mobile.replace(/\D/g, '').slice(-10) === cleanMobile);
  if (existing) {
    return res.status(400).json({ error: `Customer with mobile number ${cleanMobile} already exists (${existing.name})` });
  }

  const morningQty = Math.max(0, Number(regular_morning_qty !== undefined ? regular_morning_qty : default_morning_qty) || 0);
  const eveningQty = Math.max(0, Number(regular_evening_qty !== undefined ? regular_evening_qty : default_evening_qty) || 0);
  const activeFlag = status !== undefined ? (status === 'active' ? 1 : 0) : (is_active !== undefined ? (is_active ? 1 : 0) : 1);

  const now = new Date().toISOString();
  const newCustomer: Customer = {
    id: 'cust-' + Date.now(),
    customer_code: 'CUST' + (data.customers.length + 1).toString().padStart(3, '0'),
    name: name.trim(),
    mobile: cleanMobile,
    address: address.trim(),
    area_id,
    route_id: route_id || undefined,
    assigned_employee_id,
    delivery_sequence: data.customers.length + 1,
    regular_morning_qty: morningQty,
    regular_evening_qty: eveningQty,
    rate_per_litre: Number(rate_per_litre) || Number(data.settings.default_milk_rate?.value || 65),
    is_active: activeFlag,
    created_at: now,
    updated_at: now,
  };

  data.customers.push(newCustomer);
  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'CREATE_CUSTOMER',
    entity: 'CUSTOMERS',
    entity_id: newCustomer.id,
    new_value: JSON.stringify({ name: newCustomer.name, mobile: newCustomer.mobile, employee: newCustomer.assigned_employee_id }),
    details: `Added customer ${newCustomer.name}`,
  });
  db.persist();

  const area = data.areas.find(a => a.id === newCustomer.area_id);
  const route = data.routes.find(r => r.id === newCustomer.route_id);
  const employee = data.employees.find(e => e.id === newCustomer.assigned_employee_id);

  res.status(201).json({
    ...newCustomer,
    area_name: area ? area.name : 'Unassigned',
    route_name: route ? route.name : 'Default Route',
    employee_name: employee ? employee.name : 'Unassigned',
    assigned_employee_name: employee ? employee.name : 'Unassigned',
    default_morning_qty: morningQty,
    default_evening_qty: eveningQty,
    status: activeFlag === 1 ? 'active' : 'inactive',
  });
});

apiRouter.put('/admin/customers/:id', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const {
    name,
    mobile,
    address,
    area_id,
    route_id,
    assigned_employee_id,
    regular_morning_qty,
    default_morning_qty,
    regular_evening_qty,
    default_evening_qty,
    rate_per_litre,
    is_active,
    status,
    delivery_sequence,
  } = req.body;

  const data = db.getDB();
  const customerIndex = data.customers.findIndex(c => c.id === id);
  if (customerIndex === -1) {
    return res.status(404).json({ error: 'Customer not found' });
  }

  const oldCust = data.customers[customerIndex];
  const morningVal = regular_morning_qty !== undefined ? regular_morning_qty : default_morning_qty;
  const eveningVal = regular_evening_qty !== undefined ? regular_evening_qty : default_evening_qty;

  let activeFlag = oldCust.is_active;
  if (status !== undefined) {
    activeFlag = status === 'active' ? 1 : 0;
  } else if (is_active !== undefined) {
    activeFlag = is_active ? 1 : 0;
  }

  const updatedCust: Customer = {
    ...oldCust,
    name: name !== undefined ? name.trim() : oldCust.name,
    mobile: mobile !== undefined ? String(mobile).replace(/\D/g, '').slice(-10) : oldCust.mobile,
    address: address !== undefined ? address.trim() : oldCust.address,
    area_id: area_id !== undefined ? area_id : oldCust.area_id,
    route_id: route_id !== undefined ? route_id : oldCust.route_id,
    assigned_employee_id: assigned_employee_id !== undefined ? assigned_employee_id : oldCust.assigned_employee_id,
    regular_morning_qty: morningVal !== undefined ? Math.max(0, Number(morningVal)) : oldCust.regular_morning_qty,
    regular_evening_qty: eveningVal !== undefined ? Math.max(0, Number(eveningVal)) : oldCust.regular_evening_qty,
    rate_per_litre: rate_per_litre !== undefined ? Number(rate_per_litre) : oldCust.rate_per_litre,
    is_active: activeFlag,
    delivery_sequence: delivery_sequence !== undefined ? Number(delivery_sequence) : oldCust.delivery_sequence,
    updated_at: new Date().toISOString(),
  };

  data.customers[customerIndex] = updatedCust;

  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'UPDATE_CUSTOMER',
    entity: 'CUSTOMERS',
    entity_id: id,
    old_value: JSON.stringify({ name: oldCust.name, employee: oldCust.assigned_employee_id }),
    new_value: JSON.stringify({ name: updatedCust.name, employee: updatedCust.assigned_employee_id }),
    details: `Updated customer details for ${updatedCust.name}`,
  });
  db.persist();

  const area = data.areas.find(a => a.id === updatedCust.area_id);
  const route = data.routes.find(r => r.id === updatedCust.route_id);
  const employee = data.employees.find(e => e.id === updatedCust.assigned_employee_id);

  res.json({
    ...updatedCust,
    area_name: area ? area.name : 'Unassigned',
    route_name: route ? route.name : 'Default Route',
    employee_name: employee ? employee.name : 'Unassigned',
    assigned_employee_name: employee ? employee.name : 'Unassigned',
    default_morning_qty: updatedCust.regular_morning_qty,
    default_evening_qty: updatedCust.regular_evening_qty,
    status: updatedCust.is_active === 1 ? 'active' : 'inactive',
  });
});

apiRouter.get('/admin/customers/:id/history', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const { id } = req.params;
  const data = db.getDB();
  const customer = data.customers.find(c => c.id === id);
  if (!customer) return res.status(404).json({ error: 'Customer not found' });

  const orders = data.daily_orders.filter(o => o.customer_id === id).sort((a, b) => b.date.localeCompare(a.date));
  const deliveries = data.delivery_records.filter(d => d.customer_id === id).sort((a, b) => b.date.localeCompare(a.date));
  const sales = data.sales_records.filter(s => s.customer_id === id).sort((a, b) => b.date.localeCompare(a.date));

  res.json({
    customer,
    orders,
    deliveries,
    sales,
  });
});

// Admin Employee Management
apiRouter.get('/admin/employees', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const data = db.getDB();
  const employees = data.employees.map(e => {
    const assignedCustomers = data.customers.filter(c => c.assigned_employee_id === e.id && c.is_active === 1);
    const assignedRoutes = data.routes.filter(r => r.assigned_employee_id === e.id && r.is_active === 1);
    return {
      id: e.id,
      name: e.name,
      mobile: e.mobile,
      morning_shift: e.morning_shift,
      evening_shift: e.evening_shift,
      is_active: e.is_active,
      assigned_customers_count: assignedCustomers.length,
      assigned_routes: assignedRoutes.map(r => r.name),
      created_at: e.created_at,
    };
  });
  res.json(employees);
});

apiRouter.post('/admin/employees', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { name, mobile, pin, morning_shift, evening_shift } = req.body;
  if (!name || !mobile) {
    return res.status(400).json({ error: 'Name and mobile are required' });
  }

  const salt = bcrypt.genSaltSync(10);
  const pinHash = bcrypt.hashSync(pin || '1234', salt);
  const now = new Date().toISOString();
  const cleanMobile = String(mobile).replace(/\D/g, '').slice(-10);

  const data = db.getDB();
  const newEmp: Employee = {
    id: 'emp-' + name.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now().toString().slice(-4),
    name: name.trim(),
    mobile: cleanMobile,
    pin_hash: pinHash,
    is_active: 1,
    morning_shift: morning_shift ? 1 : 0,
    evening_shift: evening_shift ? 1 : 0,
    created_at: now,
    updated_at: now,
  };

  data.employees.push(newEmp);
  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'CREATE_EMPLOYEE',
    entity: 'EMPLOYEES',
    entity_id: newEmp.id,
    details: `Added new employee ${newEmp.name} (Shifts: Morning=${newEmp.morning_shift}, Evening=${newEmp.evening_shift})`,
  });
  db.persist();

  res.status(201).json({
    id: newEmp.id,
    name: newEmp.name,
    mobile: newEmp.mobile,
    morning_shift: newEmp.morning_shift,
    evening_shift: newEmp.evening_shift,
    is_active: newEmp.is_active,
  });
});

apiRouter.put('/admin/employees/:id', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const { name, mobile, morning_shift, evening_shift, is_active, pin } = req.body;

  const data = db.getDB();
  const empIndex = data.employees.findIndex(e => e.id === id);
  if (empIndex === -1) return res.status(404).json({ error: 'Employee not found' });

  const oldEmp = data.employees[empIndex];
  let pinHash = oldEmp.pin_hash;
  if (pin && pin.trim().length >= 4) {
    pinHash = bcrypt.hashSync(pin.trim(), bcrypt.genSaltSync(10));
  }

  const updatedEmp: Employee = {
    ...oldEmp,
    name: name !== undefined ? name.trim() : oldEmp.name,
    mobile: mobile !== undefined ? String(mobile).replace(/\D/g, '').slice(-10) : oldEmp.mobile,
    morning_shift: morning_shift !== undefined ? (morning_shift ? 1 : 0) : oldEmp.morning_shift,
    evening_shift: evening_shift !== undefined ? (evening_shift ? 1 : 0) : oldEmp.evening_shift,
    is_active: is_active !== undefined ? (is_active ? 1 : 0) : oldEmp.is_active,
    pin_hash: pinHash,
    updated_at: new Date().toISOString(),
  };

  data.employees[empIndex] = updatedEmp;

  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'UPDATE_EMPLOYEE_CONFIG',
    entity: 'EMPLOYEES',
    entity_id: id,
    details: `Updated employee ${updatedEmp.name} (Shifts: M=${updatedEmp.morning_shift}, E=${updatedEmp.evening_shift}, Active=${updatedEmp.is_active})`,
  });
  db.persist();

  res.json({
    id: updatedEmp.id,
    name: updatedEmp.name,
    mobile: updatedEmp.mobile,
    morning_shift: updatedEmp.morning_shift,
    evening_shift: updatedEmp.evening_shift,
    is_active: updatedEmp.is_active,
  });
});

// Admin Areas & Routes Management
apiRouter.get('/admin/areas', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const data = db.getDB();
  const areas = data.areas.map(a => {
    const customerCount = data.customers.filter(c => c.area_id === a.id && c.is_active === 1).length;
    const routes = data.routes.filter(r => r.area_id === a.id);
    return {
      ...a,
      customer_count: customerCount,
      routes_count: routes.length,
    };
  });
  res.json(areas);
});

apiRouter.post('/admin/areas', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { name, code, description } = req.body;
  if (!name) return res.status(400).json({ error: 'Area name is required' });

  const data = db.getDB();
  const newArea: Area = {
    id: 'area-' + Date.now(),
    name: name.trim(),
    code: (code || name.substring(0, 4).toUpperCase()).trim(),
    description: description?.trim(),
    is_active: 1,
    created_at: new Date().toISOString(),
  };

  data.areas.push(newArea);
  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'CREATE_AREA',
    entity: 'AREAS',
    entity_id: newArea.id,
    details: `Created area: ${newArea.name}`,
  });
  db.persist();

  res.status(201).json(newArea);
});

apiRouter.put('/admin/areas/:id', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const { name, code, description, is_active } = req.body;

  const data = db.getDB();
  const index = data.areas.findIndex(a => a.id === id);
  if (index === -1) return res.status(404).json({ error: 'Area not found' });

  data.areas[index] = {
    ...data.areas[index],
    name: name !== undefined ? name.trim() : data.areas[index].name,
    code: code !== undefined ? code.trim() : data.areas[index].code,
    description: description !== undefined ? description.trim() : data.areas[index].description,
    is_active: is_active !== undefined ? (is_active ? 1 : 0) : data.areas[index].is_active,
  };

  db.persist();
  res.json(data.areas[index]);
});

apiRouter.get('/admin/routes', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const data = db.getDB();
  const routes = data.routes.map(r => {
    const area = data.areas.find(a => a.id === r.area_id);
    const employee = data.employees.find(e => e.id === r.assigned_employee_id);
    const customerCount = data.customers.filter(c => c.route_id === r.id && c.is_active === 1).length;
    return {
      ...r,
      area_name: area ? area.name : 'Unknown',
      employee_name: employee ? employee.name : 'Unassigned',
      customer_count: customerCount,
    };
  });
  res.json(routes);
});

apiRouter.post('/admin/routes', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { name, area_id, assigned_employee_id, description } = req.body;
  if (!name || !area_id) return res.status(400).json({ error: 'Route name and area are required' });

  const data = db.getDB();
  const newRoute: Route = {
    id: 'route-' + Date.now(),
    name: name.trim(),
    area_id,
    assigned_employee_id: assigned_employee_id || undefined,
    description: description?.trim(),
    is_active: 1,
    created_at: new Date().toISOString(),
  };

  data.routes.push(newRoute);
  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'CREATE_ROUTE',
    entity: 'ROUTES',
    entity_id: newRoute.id,
    details: `Created route ${newRoute.name}`,
  });
  db.persist();

  res.status(201).json(newRoute);
});

apiRouter.put('/admin/routes/:id', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const { name, area_id, assigned_employee_id, description, is_active } = req.body;

  const data = db.getDB();
  const index = data.routes.findIndex(r => r.id === id);
  if (index === -1) return res.status(404).json({ error: 'Route not found' });

  data.routes[index] = {
    ...data.routes[index],
    name: name !== undefined ? name.trim() : data.routes[index].name,
    area_id: area_id !== undefined ? area_id : data.routes[index].area_id,
    assigned_employee_id: assigned_employee_id !== undefined ? assigned_employee_id : data.routes[index].assigned_employee_id,
    description: description !== undefined ? description.trim() : data.routes[index].description,
    is_active: is_active !== undefined ? (is_active ? 1 : 0) : data.routes[index].is_active,
  };

  db.persist();
  res.json(data.routes[index]);
});

// ----------------------------------------------------
// 3. INVENTORY MANAGEMENT (STRICT ACCOUNTING FORMULA)
// Opening Stock + Milk Received - Milk Issued/Delivered - Normal Loss = Remaining Stock
// ----------------------------------------------------

apiRouter.get('/admin/inventory', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const date = (req.query.date as string) || getTodayDateStr();
  const data = db.getDB();

  const ledger = db.getOrRecalculateInventory(date);
  const receipts = data.milk_receipts.filter(r => r.date === date);
  const issues = data.stock_issues.filter(s => s.date === date).map(s => {
    const emp = data.employees.find(e => e.id === s.employee_id);
    return { ...s, employee_name: emp ? emp.name : 'Unknown' };
  });

  res.json({
    ledger,
    receipts,
    issues,
  });
});

// Set Opening Stock or manual correction
apiRouter.post('/admin/inventory/opening-stock', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { date, opening_stock, notes } = req.body;
  if (!date || opening_stock === undefined) {
    return res.status(400).json({ error: 'Date and opening stock are required' });
  }

  const stockNum = Math.max(0, Number(opening_stock));
  const data = db.getDB();
  let ledger = data.inventory_ledger.find(l => l.date === date);

  if (!ledger) {
    ledger = {
      id: 'inv-' + date,
      date,
      opening_stock: stockNum,
      milk_received: 0,
      milk_issued: 0,
      milk_delivered: 0,
      normal_loss: 0,
      remaining_stock: stockNum,
      notes: notes?.trim(),
      updated_at: new Date().toISOString(),
    };
    data.inventory_ledger.push(ledger);
  } else {
    ledger.opening_stock = stockNum;
    ledger.notes = notes?.trim() || ledger.notes;
    ledger.updated_at = new Date().toISOString();
  }

  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'UPDATE_OPENING_STOCK',
    entity: 'INVENTORY',
    entity_id: date,
    new_value: stockNum.toString(),
    details: `Updated opening stock for ${date} to ${stockNum}L`,
  });

  const recalculated = db.getOrRecalculateInventory(date);
  res.json(recalculated);
});

// Record Milk Receipt / Purchase from Supplier
apiRouter.post('/admin/inventory/receipts', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { date, supplier_name, quantity, rate_per_litre, notes } = req.body;
  if (!date || !supplier_name || !quantity || !rate_per_litre) {
    return res.status(400).json({ error: 'Date, supplier name, quantity, and rate per litre are required' });
  }

  const qty = Math.max(0, Number(quantity));
  const rate = Math.max(0, Number(rate_per_litre));
  const totalAmount = Number((qty * rate).toFixed(2));

  const data = db.getDB();
  const newReceipt: MilkReceipt = {
    id: 'rec-' + Date.now(),
    date,
    supplier_name: supplier_name.trim(),
    quantity: qty,
    rate_per_litre: rate,
    total_amount: totalAmount,
    notes: notes?.trim(),
    created_at: new Date().toISOString(),
  };

  data.milk_receipts.push(newReceipt);
  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'RECORD_MILK_PURCHASE',
    entity: 'MILK_RECEIPTS',
    entity_id: newReceipt.id,
    details: `Purchased ${qty}L from ${supplier_name} @ â‚¹${rate}/L = â‚¹${totalAmount}`,
  });

  const updatedLedger = db.getOrRecalculateInventory(date);
  res.status(201).json({ receipt: newReceipt, ledger: updatedLedger });
});

apiRouter.delete('/admin/inventory/receipts/:id', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const data = db.getDB();
  const index = data.milk_receipts.findIndex(r => r.id === id);
  if (index === -1) return res.status(404).json({ error: 'Receipt not found' });

  const receipt = data.milk_receipts[index];
  data.milk_receipts.splice(index, 1);

  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'DELETE_MILK_RECEIPT',
    entity: 'MILK_RECEIPTS',
    entity_id: id,
    details: `Deleted receipt of ${receipt.quantity}L from ${receipt.supplier_name}`,
  });

  const updatedLedger = db.getOrRecalculateInventory(receipt.date);
  res.json({ success: true, ledger: updatedLedger });
});

// Issue Milk to Employee for shift
apiRouter.post('/admin/inventory/issues', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { date, shift, employee_id, quantity_issued, notes } = req.body;
  if (!date || !shift || !employee_id || quantity_issued === undefined) {
    return res.status(400).json({ error: 'Date, shift, employee, and quantity issued are required' });
  }

  const qty = Math.max(0, Number(quantity_issued));
  const data = db.getDB();
  const emp = data.employees.find(e => e.id === employee_id);
  if (!emp) return res.status(404).json({ error: 'Employee not found' });

  const newIssue: StockIssue = {
    id: 'issue-' + Date.now(),
    date,
    shift: shift as 'morning' | 'evening',
    employee_id,
    quantity_issued: qty,
    quantity_returned: 0,
    normal_loss: 0,
    notes: notes?.trim(),
    created_at: new Date().toISOString(),
  };

  data.stock_issues.push(newIssue);
  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'ISSUE_MILK_STOCK',
    entity: 'STOCK_ISSUES',
    entity_id: newIssue.id,
    details: `Issued ${qty}L milk to ${emp.name} for ${shift} shift`,
  });

  const updatedLedger = db.getOrRecalculateInventory(date);
  res.status(201).json({ issue: newIssue, ledger: updatedLedger });
});

// Update issue record (returned quantity / normal loss)
apiRouter.put('/admin/inventory/issues/:id', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { id } = req.params;
  const { quantity_issued, quantity_returned, normal_loss, notes } = req.body;

  const data = db.getDB();
  const index = data.stock_issues.findIndex(s => s.id === id);
  if (index === -1) return res.status(404).json({ error: 'Stock issue record not found' });

  const issue = data.stock_issues[index];
  if (quantity_issued !== undefined) issue.quantity_issued = Math.max(0, Number(quantity_issued));
  if (quantity_returned !== undefined) issue.quantity_returned = Math.max(0, Number(quantity_returned));
  if (normal_loss !== undefined) issue.normal_loss = Math.max(0, Number(normal_loss));
  if (notes !== undefined) issue.notes = notes?.trim();

  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'UPDATE_STOCK_ISSUE',
    entity: 'STOCK_ISSUES',
    entity_id: id,
    details: `Updated issue: Issued=${issue.quantity_issued}L, Returned=${issue.quantity_returned}L, Loss=${issue.normal_loss}L`,
  });

  const updatedLedger = db.getOrRecalculateInventory(issue.date);
  res.json({ issue, ledger: updatedLedger });
});

// ----------------------------------------------------
// 4. DAILY PLANNING REPORT ("Tomorrow's Milk Requirement")
// ----------------------------------------------------

apiRouter.get('/admin/reports/tomorrow-requirements', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const tomorrowDate = (req.query.date as string) || getTomorrowDateStr();
  const data = db.getDB();

  const activeCustomers = data.customers.filter(c => c.is_active === 1);
  const tomorrowOrders = data.daily_orders.filter(o => o.date === tomorrowDate);

  // Group by customer
  const customerRows = activeCustomers.map(cust => {
    const order = tomorrowOrders.find(o => o.customer_id === cust.id);
    const emp = data.employees.find(e => e.id === cust.assigned_employee_id);
    const area = data.areas.find(a => a.id === cust.area_id);
    const route = data.routes.find(r => r.id === cust.route_id);

    // If customer submitted explicit order, use it; otherwise show regular qty as default baseline with status 'unsubmitted'
    const morningQty = order ? order.morning_qty : cust.regular_morning_qty;
    const eveningQty = order ? order.evening_qty : cust.regular_evening_qty;
    const totalQty = order ? order.total_qty : (cust.regular_morning_qty + cust.regular_evening_qty);
    const isSubmitted = !!order && order.status !== 'cancelled';

    return {
      customer_id: cust.id,
      customer_code: cust.customer_code,
      customer_name: cust.name,
      mobile: cust.mobile,
      address: cust.address,
      area_id: cust.area_id,
      area_name: area ? area.name : 'Unknown',
      route_name: route ? route.name : 'Default Route',
      employee_id: cust.assigned_employee_id,
      employee_name: emp ? emp.name : 'Unassigned',
      morning_qty: Number(morningQty.toFixed(2)),
      evening_qty: Number(eveningQty.toFixed(2)),
      total_qty: Number(totalQty.toFixed(2)),
      is_submitted: isSubmitted,
      order_status: order ? order.status : 'not_submitted',
      submitted_at: order ? order.submitted_at : null,
    };
  });

  // Calculate totals
  const totalTomorrowMilk = customerRows.reduce((sum, r) => sum + r.total_qty, 0);
  const morningTotal = customerRows.reduce((sum, r) => sum + r.morning_qty, 0);
  const eveningTotal = customerRows.reduce((sum, r) => sum + r.evening_qty, 0);
  const submittedCount = customerRows.filter(r => r.is_submitted).length;
  const unsubmittedCount = customerRows.length - submittedCount;

  // Employee-wise Breakdown
  const employeeWise = data.employees.map(emp => {
    const empCustomers = customerRows.filter(r => r.employee_id === emp.id);
    const empMorning = empCustomers.reduce((sum, r) => sum + r.morning_qty, 0);
    const empEvening = empCustomers.reduce((sum, r) => sum + r.evening_qty, 0);
    const empTotal = empCustomers.reduce((sum, r) => sum + r.total_qty, 0);
    return {
      employee_id: emp.id,
      employee_name: emp.name,
      customer_count: empCustomers.length,
      morning_qty: Number(empMorning.toFixed(2)),
      evening_qty: Number(empEvening.toFixed(2)),
      total_qty: Number(empTotal.toFixed(2)),
      submitted_count: empCustomers.filter(r => r.is_submitted).length,
    };
  });

  // Area-wise Breakdown
  const areaWise = data.areas.map(area => {
    const areaCustomers = customerRows.filter(r => r.area_id === area.id);
    const areaMorning = areaCustomers.reduce((sum, r) => sum + r.morning_qty, 0);
    const areaEvening = areaCustomers.reduce((sum, r) => sum + r.evening_qty, 0);
    const areaTotal = areaCustomers.reduce((sum, r) => sum + r.total_qty, 0);
    return {
      area_id: area.id,
      area_name: area.name,
      customer_count: areaCustomers.length,
      morning_qty: Number(areaMorning.toFixed(2)),
      evening_qty: Number(areaEvening.toFixed(2)),
      total_qty: Number(areaTotal.toFixed(2)),
    };
  });

  res.json({
    date: tomorrowDate,
    totals: {
      total_milk_required: Number(totalTomorrowMilk.toFixed(2)),
      morning_total: Number(morningTotal.toFixed(2)),
      evening_total: Number(eveningTotal.toFixed(2)),
      customer_count: activeCustomers.length,
      submitted_count: submittedCount,
      unsubmitted_count: unsubmittedCount,
    },
    employee_wise: employeeWise,
    area_wise: areaWise,
    customers: customerRows,
  });
});

// ----------------------------------------------------
// 5. DAILY BUSINESS REPORT
// ----------------------------------------------------

apiRouter.get('/admin/reports/daily-business', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const date = (req.query.date as string) || getTodayDateStr();
  const employeeId = req.query.employee_id as string;
  const areaId = req.query.area_id as string;
  const shift = req.query.shift as string;

  const data = db.getDB();
  const ledger = db.getOrRecalculateInventory(date);

  // Filter deliveries
  let deliveries = data.delivery_records.filter(d => d.date === date);
  if (employeeId) deliveries = deliveries.filter(d => d.employee_id === employeeId);
  if (shift) deliveries = deliveries.filter(d => d.shift === shift);
  if (areaId) {
    const areaCustIds = new Set(data.customers.filter(c => c.area_id === areaId).map(c => c.id));
    deliveries = deliveries.filter(d => areaCustIds.has(d.customer_id));
  }

  // Filter sales
  let sales = data.sales_records.filter(s => s.date === date);
  if (shift) sales = sales.filter(s => s.shift === shift);
  if (areaId || employeeId) {
    const matchedCustIds = new Set(
      data.customers
        .filter(c => (!areaId || c.area_id === areaId) && (!employeeId || c.assigned_employee_id === employeeId))
        .map(c => c.id)
    );
    sales = sales.filter(s => matchedCustIds.has(s.customer_id));
  }

  const totalDelivered = deliveries.filter(d => d.status !== 'not_delivered').reduce((sum, d) => sum + (Number(d.delivered_qty) || 0), 0);
  const totalSales = sales.reduce((sum, s) => sum + (Number(s.total_amount) || 0), 0);
  const customersServed = new Set(deliveries.filter(d => d.status === 'delivered' || d.status === 'partially_delivered').map(d => d.customer_id)).size;
  const pendingDeliveries = deliveries.filter(d => d.status === 'pending').length;

  res.json({
    date,
    inventory: ledger,
    summary: {
      opening_stock: ledger.opening_stock,
      milk_received: ledger.milk_received,
      milk_issued: ledger.milk_issued,
      milk_delivered: totalDelivered,
      milk_remaining: ledger.remaining_stock,
      normal_loss: ledger.normal_loss,
      total_sales: Number(totalSales.toFixed(2)),
      customers_served: customersServed,
      pending_deliveries: pendingDeliveries,
      deliveries_count: deliveries.length,
    },
    deliveries: deliveries.map(d => {
      const cust = data.customers.find(c => c.id === d.customer_id);
      const emp = data.employees.find(e => e.id === d.employee_id);
      return {
        ...d,
        customer_name: cust ? cust.name : 'Unknown',
        customer_mobile: cust ? cust.mobile : '',
        customer_address: cust ? cust.address : '',
        employee_name: emp ? emp.name : 'Unknown',
      };
    }),
    sales: sales.map(s => {
      const cust = data.customers.find(c => c.id === s.customer_id);
      return {
        ...s,
        customer_name: cust ? cust.name : 'Unknown',
        customer_code: cust ? cust.customer_code : '',
      };
    }),
  });
});

// Admin Notifications Trigger
apiRouter.get('/admin/notifications', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const data = db.getDB();
  res.json(data.notifications);
});

apiRouter.post('/admin/notifications/send-order-reminder', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const tomorrowDate = getTomorrowDateStr();
  const data = db.getDB();
  const activeCustomers = data.customers.filter(c => c.is_active === 1);
  const tomorrowOrders = data.daily_orders.filter(o => o.date === tomorrowDate && o.status !== 'cancelled');
  const orderedCustomerIds = new Set(tomorrowOrders.map(o => o.customer_id));

  const pendingCustomers = activeCustomers.filter(c => !orderedCustomerIds.has(c.id));
  const now = new Date().toISOString();

  let sentCount = 0;
  pendingCustomers.forEach(cust => {
    const notif: AppNotification = {
      id: 'notif-' + Date.now() + '-' + cust.id.slice(-4),
      customer_id: cust.id,
      title: 'Milk Requirement Reminder',
      message: `Namaste ${cust.name}, please confirm your milk requirement for tomorrow (${tomorrowDate}) before 12:00 AM.`,
      type: 'order_reminder',
      status: 'sent',
      sent_at: now,
      created_at: now,
    };
    data.notifications.unshift(notif);
    sentCount++;
  });

  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'SEND_ORDER_REMINDERS',
    entity: 'NOTIFICATIONS',
    entity_id: 'batch',
    details: `Sent requirement reminders to ${sentCount} customers who have not submitted for ${tomorrowDate}`,
  });
  db.persist();

  res.json({
    success: true,
    sent_count: sentCount,
    pending_count: pendingCustomers.length,
    message: `Reminder notifications sent to ${sentCount} customer(s)`,
  });
});

// Admin Audit Logs & Settings
apiRouter.get('/admin/audit-logs', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const data = db.getDB();
  res.json(data.audit_logs.slice(0, 100));
});

apiRouter.get('/admin/settings', authenticateToken, requireRole('ADMIN'), (req, res) => {
  const data = db.getDB();
  res.json(data.settings);
});

apiRouter.put('/admin/settings', authenticateToken, requireRole('ADMIN'), (req: AuthenticatedRequest, res) => {
  const { default_milk_rate, order_cutoff_time, business_name, contact_number } = req.body;
  const data = db.getDB();
  const now = new Date().toISOString();

  if (default_milk_rate !== undefined) {
    data.settings.default_milk_rate = {
      key: 'default_milk_rate',
      value: String(default_milk_rate),
      description: 'Default price per litre of milk in INR (â‚¹)',
      updated_at: now,
    };
  }
  if (order_cutoff_time !== undefined) {
    data.settings.order_cutoff_time = {
      key: 'order_cutoff_time',
      value: String(order_cutoff_time),
      description: 'Daily order cutoff deadline (12:00 AM)',
      updated_at: now,
    };
  }
  if (business_name !== undefined) {
    data.settings.business_name = {
      key: 'business_name',
      value: String(business_name).trim(),
      description: 'Business name',
      updated_at: now,
    };
  }
  if (contact_number !== undefined) {
    data.settings.contact_number = {
      key: 'contact_number',
      value: String(contact_number).trim(),
      description: 'Helpline / Owner contact number',
      updated_at: now,
    };
  }

  db.logAudit({
    user_role: 'ADMIN',
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'UPDATE_SETTINGS',
    entity: 'SETTINGS',
    entity_id: 'settings',
    details: `Updated settings: Rate=â‚¹${data.settings.default_milk_rate?.value}, Name=${data.settings.business_name?.value}`,
  });
  db.persist();

  res.json(data.settings);
});

// ----------------------------------------------------
// 6. EMPLOYEE API ROUTES
// ----------------------------------------------------

apiRouter.get('/employee/dashboard', authenticateToken, requireRole('EMPLOYEE', 'ADMIN'), (req: AuthenticatedRequest, res) => {
  const employeeId = req.user!.role === 'ADMIN' ? (req.query.employee_id as string) || 'emp-shivram' : req.user!.id;
  const date = (req.query.date as string) || getTodayDateStr();
  const shift = (req.query.shift as 'morning' | 'evening') || 'morning';

  const data = db.getDB();
  const employee = data.employees.find(e => e.id === employeeId);
  if (!employee) return res.status(404).json({ error: 'Employee not found' });

  // Get assigned customers
  const assignedCustomers = data.customers
    .filter(c => c.assigned_employee_id === employeeId && c.is_active === 1)
    .sort((a, b) => a.delivery_sequence - b.delivery_sequence);

  // Get or initialize delivery records for this shift
  const deliveriesForShift: Array<DeliveryRecord & { customer: Customer; area_name: string; route_name: string }> = [];

  assignedCustomers.forEach(cust => {
    let delivery = data.delivery_records.find(
      d => d.customer_id === cust.id && d.date === date && d.shift === shift && d.employee_id === employeeId
    );

    // Look for customer's order for today
    const order = data.daily_orders.find(o => o.customer_id === cust.id && o.date === date && o.status !== 'cancelled');
    const orderedQty = order
      ? (shift === 'morning' ? order.morning_qty : order.evening_qty)
      : (shift === 'morning' ? cust.regular_morning_qty : cust.regular_evening_qty);

    if (!delivery) {
      delivery = {
        id: `del-${date}-${shift}-${cust.id}`,
        customer_id: cust.id,
        employee_id: employeeId,
        date,
        shift,
        ordered_qty: Number(orderedQty.toFixed(2)),
        delivered_qty: Number(orderedQty.toFixed(2)), // default actual to ordered for easy 1-tap confirmation
        difference_qty: 0,
        status: 'pending',
        notes: '',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      data.delivery_records.push(delivery);
    }

    const area = data.areas.find(a => a.id === cust.area_id);
    const route = data.routes.find(r => r.id === cust.route_id);

    deliveriesForShift.push({
      ...delivery,
      customer: cust,
      area_name: area ? area.name : 'Area',
      route_name: route ? route.name : 'Route',
    });
  });

  db.persist();

  // Calculate totals
  const totalAssignedCustomers = assignedCustomers.length;
  const totalOrderedQty = deliveriesForShift.reduce((sum, d) => sum + Number(d.ordered_qty || 0), 0);
  const totalDeliveredQty = deliveriesForShift
    .filter(d => d.status === 'delivered' || d.status === 'partially_delivered')
    .reduce((sum, d) => sum + Number(d.delivered_qty || 0), 0);
  const deliveredCount = deliveriesForShift.filter(d => d.status === 'delivered').length;
  const partialCount = deliveriesForShift.filter(d => d.status === 'partially_delivered').length;
  const notDeliveredCount = deliveriesForShift.filter(d => d.status === 'not_delivered').length;
  const pendingCount = deliveriesForShift.filter(d => d.status === 'pending').length;
  const completionPercentage = totalAssignedCustomers > 0 ? Math.round(((deliveredCount + partialCount + notDeliveredCount) / totalAssignedCustomers) * 100) : 0;

  // Check milk issued to this employee for this shift
  const stockIssue = data.stock_issues.find(s => s.employee_id === employeeId && s.date === date && s.shift === shift);
  const milkTaken = stockIssue ? stockIssue.quantity_issued : totalOrderedQty; // fallback to required

  res.json({
    employee: {
      id: employee.id,
      name: employee.name,
      mobile: employee.mobile,
      morning_shift: employee.morning_shift,
      evening_shift: employee.evening_shift,
    },
    date,
    shift,
    summary: {
      total_customers: totalAssignedCustomers,
      total_ordered_qty: Number(totalOrderedQty.toFixed(2)),
      total_delivered_qty: Number(totalDeliveredQty.toFixed(2)),
      remaining_to_deliver: Number(Math.max(0, totalOrderedQty - totalDeliveredQty).toFixed(2)),
      delivered_count: deliveredCount,
      partial_count: partialCount,
      not_delivered_count: notDeliveredCount,
      pending_count: pendingCount,
      completion_percentage: completionPercentage,
      milk_taken_from_stock: Number(milkTaken.toFixed(2)),
      milk_returned: stockIssue ? Number(stockIssue.quantity_returned.toFixed(2)) : 0,
      normal_loss: stockIssue ? Number(stockIssue.normal_loss.toFixed(2)) : 0,
    },
    deliveries: deliveriesForShift,
  });
});

// Record delivery for a single customer
apiRouter.post('/employee/deliveries/record', authenticateToken, requireRole('EMPLOYEE', 'ADMIN'), (req: AuthenticatedRequest, res) => {
  const { customer_id, date, shift, delivered_qty, status, notes } = req.body;
  const employeeId = req.user!.role === 'ADMIN' ? req.body.employee_id || 'emp-shivram' : req.user!.id;

  if (!customer_id || !date || !shift || delivered_qty === undefined || !status) {
    return res.status(400).json({ error: 'Customer ID, date, shift, delivered quantity, and status are required' });
  }

  const deliveredNum = Math.max(0, Number(delivered_qty));
  const data = db.getDB();
  const customer = data.customers.find(c => c.id === customer_id);
  if (!customer) return res.status(404).json({ error: 'Customer not found' });

  let deliveryIndex = data.delivery_records.findIndex(
    d => d.customer_id === customer_id && d.date === date && d.shift === shift
  );

  const order = data.daily_orders.find(o => o.customer_id === customer_id && o.date === date);
  const orderedQty = order
    ? (shift === 'morning' ? order.morning_qty : order.evening_qty)
    : (shift === 'morning' ? customer.regular_morning_qty : customer.regular_evening_qty);

  const diff = Number((deliveredNum - orderedQty).toFixed(2));
  const now = new Date().toISOString();

  let deliveryRecord: DeliveryRecord;

  if (deliveryIndex >= 0) {
    deliveryRecord = {
      ...data.delivery_records[deliveryIndex],
      employee_id: employeeId,
      ordered_qty: Number(orderedQty.toFixed(2)),
      delivered_qty: deliveredNum,
      difference_qty: diff,
      status: status as any,
      notes: notes !== undefined ? notes.trim() : data.delivery_records[deliveryIndex].notes,
      delivered_at: status !== 'pending' ? now : undefined,
      updated_at: now,
    };
    data.delivery_records[deliveryIndex] = deliveryRecord;
  } else {
    deliveryRecord = {
      id: `del-${date}-${shift}-${customer_id}`,
      customer_id,
      employee_id: employeeId,
      date,
      shift: shift as any,
      ordered_qty: Number(orderedQty.toFixed(2)),
      delivered_qty: deliveredNum,
      difference_qty: diff,
      status: status as any,
      notes: notes?.trim() || '',
      delivered_at: status !== 'pending' ? now : undefined,
      created_at: now,
      updated_at: now,
    };
    data.delivery_records.push(deliveryRecord);
  }

  // Create or update Sales record if delivered
  let saleIndex = data.sales_records.findIndex(
    s => s.customer_id === customer_id && s.date === date && s.shift === shift
  );

  if (status === 'delivered' || status === 'partially_delivered') {
    const rate = customer.rate_per_litre || Number(data.settings.default_milk_rate?.value || 65);
    const totalAmount = Number((deliveredNum * rate).toFixed(2));

    if (saleIndex >= 0) {
      data.sales_records[saleIndex].quantity = deliveredNum;
      data.sales_records[saleIndex].rate_per_litre = rate;
      data.sales_records[saleIndex].total_amount = totalAmount;
    } else {
      const newSale: SalesRecord = {
        id: `sale-${date}-${shift}-${customer_id}`,
        customer_id,
        delivery_record_id: deliveryRecord.id,
        date,
        shift: shift as any,
        quantity: deliveredNum,
        rate_per_litre: rate,
        total_amount: totalAmount,
        payment_status: 'unpaid',
        payment_mode: 'cash',
        created_at: now,
      };
      data.sales_records.push(newSale);
    }
  } else if (saleIndex >= 0 && status === 'not_delivered') {
    // If marked not delivered, remove/zero out sale
    data.sales_records.splice(saleIndex, 1);
  }

  db.logAudit({
    user_role: req.user!.role,
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'RECORD_DELIVERY',
    entity: 'DELIVERY_RECORDS',
    entity_id: deliveryRecord.id,
    details: `Delivered ${deliveredNum}L to ${customer.name} (Status: ${status})`,
  });

  db.getOrRecalculateInventory(date);
  db.persist();

  res.json({
    success: true,
    delivery: deliveryRecord,
  });
});

// Batch update deliveries (for fast one-tap checkoffs or offline sync)
apiRouter.post('/employee/deliveries/batch-record', authenticateToken, requireRole('EMPLOYEE', 'ADMIN'), (req: AuthenticatedRequest, res) => {
  const { records } = req.body;
  if (!Array.isArray(records) || records.length === 0) {
    return res.status(400).json({ error: 'Array of delivery records is required' });
  }

  const employeeId = req.user!.role === 'ADMIN' ? req.body.employee_id || 'emp-shivram' : req.user!.id;
  const data = db.getDB();
  const now = new Date().toISOString();
  let updatedDates = new Set<string>();

  records.forEach(rec => {
    const { customer_id, date, shift, delivered_qty, status, notes } = rec;
    if (!customer_id || !date || !shift || delivered_qty === undefined || !status) return;

    updatedDates.add(date);
    const deliveredNum = Math.max(0, Number(delivered_qty));
    const customer = data.customers.find(c => c.id === customer_id);
    if (!customer) return;

    let deliveryIndex = data.delivery_records.findIndex(
      d => d.customer_id === customer_id && d.date === date && d.shift === shift
    );

    const order = data.daily_orders.find(o => o.customer_id === customer_id && o.date === date);
    const orderedQty = order
      ? (shift === 'morning' ? order.morning_qty : order.evening_qty)
      : (shift === 'morning' ? customer.regular_morning_qty : customer.regular_evening_qty);

    const diff = Number((deliveredNum - orderedQty).toFixed(2));

    let deliveryRecord: DeliveryRecord;
    if (deliveryIndex >= 0) {
      deliveryRecord = {
        ...data.delivery_records[deliveryIndex],
        employee_id: employeeId,
        ordered_qty: Number(orderedQty.toFixed(2)),
        delivered_qty: deliveredNum,
        difference_qty: diff,
        status,
        notes: notes !== undefined ? notes.trim() : data.delivery_records[deliveryIndex].notes,
        delivered_at: status !== 'pending' ? now : undefined,
        updated_at: now,
      };
      data.delivery_records[deliveryIndex] = deliveryRecord;
    } else {
      deliveryRecord = {
        id: `del-${date}-${shift}-${customer_id}`,
        customer_id,
        employee_id: employeeId,
        date,
        shift,
        ordered_qty: Number(orderedQty.toFixed(2)),
        delivered_qty: deliveredNum,
        difference_qty: diff,
        status,
        notes: notes?.trim() || '',
        delivered_at: status !== 'pending' ? now : undefined,
        created_at: now,
        updated_at: now,
      };
      data.delivery_records.push(deliveryRecord);
    }

    // Sales sync
    let saleIndex = data.sales_records.findIndex(
      s => s.customer_id === customer_id && s.date === date && s.shift === shift
    );
    if (status === 'delivered' || status === 'partially_delivered') {
      const rate = customer.rate_per_litre || Number(data.settings.default_milk_rate?.value || 65);
      const totalAmount = Number((deliveredNum * rate).toFixed(2));
      if (saleIndex >= 0) {
        data.sales_records[saleIndex].quantity = deliveredNum;
        data.sales_records[saleIndex].rate_per_litre = rate;
        data.sales_records[saleIndex].total_amount = totalAmount;
      } else {
        data.sales_records.push({
          id: `sale-${date}-${shift}-${customer_id}`,
          customer_id,
          delivery_record_id: deliveryRecord.id,
          date,
          shift,
          quantity: deliveredNum,
          rate_per_litre: rate,
          total_amount: totalAmount,
          payment_status: 'unpaid',
          payment_mode: 'cash',
          created_at: now,
        });
      }
    }
  });

  updatedDates.forEach(d => db.getOrRecalculateInventory(d));
  db.persist();

  res.json({ success: true, count: records.length });
});

// Employee Daily Summary
apiRouter.get('/employee/daily-summary', authenticateToken, requireRole('EMPLOYEE', 'ADMIN'), (req: AuthenticatedRequest, res) => {
  const employeeId = req.user!.role === 'ADMIN' ? (req.query.employee_id as string) || 'emp-shivram' : req.user!.id;
  const date = (req.query.date as string) || getTodayDateStr();
  const shift = req.query.shift as 'morning' | 'evening' | undefined;

  const data = db.getDB();
  const employee = data.employees.find(e => e.id === employeeId);
  if (!employee) return res.status(404).json({ error: 'Employee not found' });

  let deliveries = data.delivery_records.filter(d => d.employee_id === employeeId && d.date === date);
  if (shift) deliveries = deliveries.filter(d => d.shift === shift);

  const assignedCustomers = data.customers.filter(c => c.assigned_employee_id === employeeId && c.is_active === 1);
  const totalOrdered = deliveries.reduce((sum, d) => sum + (Number(d.ordered_qty) || 0), 0);
  const totalDelivered = deliveries.filter(d => d.status !== 'not_delivered').reduce((sum, d) => sum + (Number(d.delivered_qty) || 0), 0);
  const undeliveredCount = deliveries.filter(d => d.status === 'not_delivered').length;
  const partialCount = deliveries.filter(d => d.status === 'partially_delivered').length;
  const completedCount = deliveries.filter(d => d.status === 'delivered').length;

  let stockIssues = data.stock_issues.filter(s => s.employee_id === employeeId && s.date === date);
  if (shift) stockIssues = stockIssues.filter(s => s.shift === shift);

  const milkTaken = stockIssues.reduce((sum, s) => sum + (Number(s.quantity_issued) || 0), 0);
  const milkReturned = stockIssues.reduce((sum, s) => sum + (Number(s.quantity_returned) || 0), 0);
  const normalLoss = stockIssues.reduce((sum, s) => sum + (Number(s.normal_loss) || 0), 0);

  res.json({
    employee_name: employee.name,
    date,
    shift: shift || 'All Shifts',
    total_assigned_customers: assignedCustomers.length,
    total_ordered_quantity: Number(totalOrdered.toFixed(2)),
    total_delivered_quantity: Number(totalDelivered.toFixed(2)),
    undelivered_customers_count: undeliveredCount,
    partially_delivered_count: partialCount,
    fully_delivered_count: completedCount,
    milk_quantity_taken_from_stock: Number((milkTaken || totalOrdered).toFixed(2)),
    milk_quantity_returned: Number(milkReturned.toFixed(2)),
    normal_loss_quantity: Number(normalLoss.toFixed(2)),
  });
});

// ----------------------------------------------------
// 7. CUSTOMER API ROUTES
// ----------------------------------------------------

apiRouter.get('/customer/dashboard', authenticateToken, requireRole('CUSTOMER', 'ADMIN'), (req: AuthenticatedRequest, res) => {
  const customerId = req.user!.role === 'ADMIN' ? (req.query.customer_id as string) : req.user!.id;
  const data = db.getDB();
  const customer = data.customers.find(c => c.id === customerId);
  if (!customer) return res.status(404).json({ error: 'Customer not found' });

  const todayStr = getTodayDateStr();
  const tomorrowStr = getTomorrowDateStr();

  const employee = data.employees.find(e => e.id === customer.assigned_employee_id);
  const area = data.areas.find(a => a.id === customer.area_id);
  const route = data.routes.find(r => r.id === customer.route_id);

  // Today's delivery records
  const todayMorningDelivery = data.delivery_records.find(d => d.customer_id === customerId && d.date === todayStr && d.shift === 'morning');
  const todayEveningDelivery = data.delivery_records.find(d => d.customer_id === customerId && d.date === todayStr && d.shift === 'evening');

  // Tomorrow's submitted requirement
  const tomorrowOrder = data.daily_orders.find(o => o.customer_id === customerId && o.date === tomorrowStr);
  const isCutoffPassed = isOrderCutoffPassed(tomorrowStr);

  // Recent history (last 10 deliveries)
  const deliveryHistory = data.delivery_records
    .filter(d => d.customer_id === customerId)
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 10);

  // Unread notifications
  const notifications = data.notifications.filter(n => n.customer_id === customerId).slice(0, 5);

  res.json({
    customer: {
      id: customer.id,
      customer_code: customer.customer_code,
      name: customer.name,
      mobile: customer.mobile,
      address: customer.address,
      area_name: area ? area.name : 'Local Area',
      route_name: route ? route.name : 'Main Route',
      assigned_employee_name: employee ? employee.name : 'Shivram',
      assigned_employee_mobile: employee ? employee.mobile : '',
      regular_morning_qty: customer.regular_morning_qty,
      regular_evening_qty: customer.regular_evening_qty,
      rate_per_litre: customer.rate_per_litre,
    },
    today: {
      date: todayStr,
      morning: todayMorningDelivery || {
        ordered_qty: customer.regular_morning_qty,
        delivered_qty: 0,
        status: 'pending',
      },
      evening: todayEveningDelivery || {
        ordered_qty: customer.regular_evening_qty,
        delivered_qty: 0,
        status: 'pending',
      },
    },
    tomorrow: {
      date: tomorrowStr,
      has_submitted: !!tomorrowOrder && tomorrowOrder.status !== 'cancelled',
      morning_qty: tomorrowOrder ? tomorrowOrder.morning_qty : customer.regular_morning_qty,
      evening_qty: tomorrowOrder ? tomorrowOrder.evening_qty : customer.regular_evening_qty,
      total_qty: tomorrowOrder ? tomorrowOrder.total_qty : (customer.regular_morning_qty + customer.regular_evening_qty),
      status: tomorrowOrder ? tomorrowOrder.status : 'unconfirmed',
      submitted_at: tomorrowOrder ? tomorrowOrder.submitted_at : null,
      cutoff_passed: isCutoffPassed,
      cutoff_deadline: '12:00 AM (Midnight)',
    },
    recent_history: deliveryHistory,
    notifications,
  });
});

// Customer submit / change requirement for tomorrow (Strict Cutoff check)
apiRouter.post('/customer/orders/submit-tomorrow', authenticateToken, requireRole('CUSTOMER', 'ADMIN'), (req: AuthenticatedRequest, res) => {
  const customerId = req.user!.role === 'ADMIN' ? (req.body.customer_id as string) : req.user!.id;
  const { morning_qty, evening_qty, notes, date } = req.body;

  const targetDate = date || getTomorrowDateStr();

  // Check 12:00 AM cutoff rule
  if (isOrderCutoffPassed(targetDate)) {
    return res.status(400).json({
      error: `Order cutoff time (12:00 AM) for ${targetDate} has passed. Please contact Dudhwala admin directly.`,
    });
  }

  const morningNum = Math.max(0, Number(morning_qty) || 0);
  const eveningNum = Math.max(0, Number(evening_qty) || 0);
  const totalNum = Number((morningNum + eveningNum).toFixed(2));

  if (totalNum <= 0 && (!notes || notes.trim() === '')) {
    return res.status(400).json({ error: 'Please specify milk quantity greater than 0 litres or mark cancelled' });
  }

  const data = db.getDB();
  const customer = data.customers.find(c => c.id === customerId);
  if (!customer) return res.status(404).json({ error: 'Customer not found' });

  const now = new Date().toISOString();
  let orderIndex = data.daily_orders.findIndex(o => o.customer_id === customerId && o.date === targetDate);

  let dailyOrder: DailyOrder;
  if (orderIndex >= 0) {
    dailyOrder = {
      ...data.daily_orders[orderIndex],
      morning_qty: morningNum,
      evening_qty: eveningNum,
      total_qty: totalNum,
      status: 'modified',
      notes: notes?.trim() || '',
      updated_at: now,
    };
    data.daily_orders[orderIndex] = dailyOrder;
  } else {
    dailyOrder = {
      id: `ord-${targetDate}-${customerId}`,
      customer_id: customerId,
      date: targetDate,
      morning_qty: morningNum,
      evening_qty: eveningNum,
      total_qty: totalNum,
      status: 'confirmed',
      notes: notes?.trim() || '',
      submitted_at: now,
      updated_at: now,
    };
    data.daily_orders.push(dailyOrder);
  }

  db.logAudit({
    user_role: req.user!.role,
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: orderIndex >= 0 ? 'MODIFY_DAILY_ORDER' : 'SUBMIT_DAILY_ORDER',
    entity: 'DAILY_ORDERS',
    entity_id: dailyOrder.id,
    details: `${customer.name} confirmed requirement for ${targetDate}: Morning=${morningNum}L, Evening=${eveningNum}L (Total ${totalNum}L)`,
  });

  db.persist();

  res.json({
    success: true,
    message: `Milk requirement for ${targetDate} saved successfully!`,
    order: dailyOrder,
  });
});

// Cancel tomorrow's order
apiRouter.post('/customer/orders/cancel-tomorrow', authenticateToken, requireRole('CUSTOMER', 'ADMIN'), (req: AuthenticatedRequest, res) => {
  const customerId = req.user!.role === 'ADMIN' ? (req.body.customer_id as string) : req.user!.id;
  const targetDate = req.body.date || getTomorrowDateStr();

  if (isOrderCutoffPassed(targetDate)) {
    return res.status(400).json({ error: 'Cutoff has passed. Cannot cancel online.' });
  }

  const data = db.getDB();
  const customer = data.customers.find(c => c.id === customerId);
  const now = new Date().toISOString();

  let orderIndex = data.daily_orders.findIndex(o => o.customer_id === customerId && o.date === targetDate);
  if (orderIndex >= 0) {
    data.daily_orders[orderIndex].status = 'cancelled';
    data.daily_orders[orderIndex].morning_qty = 0;
    data.daily_orders[orderIndex].evening_qty = 0;
    data.daily_orders[orderIndex].total_qty = 0;
    data.daily_orders[orderIndex].updated_at = now;
  } else {
    data.daily_orders.push({
      id: `ord-${targetDate}-${customerId}`,
      customer_id: customerId,
      date: targetDate,
      morning_qty: 0,
      evening_qty: 0,
      total_qty: 0,
      status: 'cancelled',
      submitted_at: now,
      updated_at: now,
    });
  }

  db.logAudit({
    user_role: req.user!.role,
    user_id: req.user!.id,
    user_name: req.user!.name,
    action: 'CANCEL_DAILY_ORDER',
    entity: 'DAILY_ORDERS',
    entity_id: `ord-${targetDate}-${customerId}`,
    details: `${customer?.name || customerId} cancelled milk order for ${targetDate}`,
  });
  db.persist();

  res.json({ success: true, message: `Milk order cancelled for ${targetDate}` });
});

``

#### Source File: src/lib/api.ts
``typescript
import { UserSession } from '../types.ts';

const TOKEN_KEY = 'dudhwala_token';
const USER_KEY = 'dudhwala_user';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function getStoredUser(): UserSession | null {
  const data = localStorage.getItem(USER_KEY);
  if (!data) return null;
  try {
    return JSON.parse(data);
  } catch {
    return null;
  }
}

export const getStoredSession = getStoredUser;

export function setSession(token: string, user: UserSession) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}

export function clearSession() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

export async function apiRequest<T = any>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {}),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await res.json();

  if (!res.ok) {
    if (res.status === 401 || res.status === 403) {
      // If token expired, clear invalid session
      if (token && (endpoint.includes('/me') || endpoint.includes('/dashboard'))) {
        clearSession();
      }
    }
    throw new Error(data.error || `HTTP ${res.status}: Request failed`);
  }

  return data as T;
}

// Format Currency in INR â‚¹
export function formatINR(amount: number | string | undefined): string {
  const num = Number(amount) || 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(num);
}

// Format Litres
export function formatLitres(qty: number | string | undefined): string {
  const num = Number(qty) || 0;
  return `${num.toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })} L`;
}

``

#### Source File: src/App.tsx
``tsx
import React, { useState, useEffect } from 'react';
import { UserSession, UserRole } from './types.ts';
import { getStoredSession, getStoredToken, clearSession, apiRequest, setSession } from './lib/api.ts';
import { Header } from './components/Header.tsx';
import { PWAInstallBanner } from './components/PWAInstallBanner.tsx';
import { DeviceAdaptiveBar } from './components/DeviceAdaptiveBar.tsx';
import { AuthView } from './components/AuthView.tsx';
import { EmployeeView } from './components/employee/EmployeeView.tsx';
import { CustomerView } from './components/customer/CustomerView.tsx';
import { AdminView } from './components/admin/AdminView.tsx';
import { Truck, User, Shield, RefreshCw } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserSession | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    // Check existing stored session
    const token = getStoredToken();
    const storedUser = getStoredSession();

    if (token && storedUser) {
      // Verify token
      apiRequest<UserSession>('/api/auth/me')
        .then((user) => {
          setCurrentUser(user);
        })
        .catch(() => {
          clearSession();
          setCurrentUser(null);
        })
        .finally(() => setInitialized(true));
    } else {
      // Default to employee login for instant usability
      setInitialized(true);
    }
  }, []);

  const handleLoginSuccess = (user: UserSession) => {
    setCurrentUser(user);
    setIsAuthOpen(false);
  };

  const handleLogout = () => {
    clearSession();
    setCurrentUser(null);
    setIsAuthOpen(true);
  };

  // Quick 1-click role switcher helper for evaluators
  const handleQuickSwitch = async (role: UserRole, id?: string) => {
    try {
      if (role === 'EMPLOYEE') {
        const empId = id || 'emp-shivram';
        const res = await apiRequest<{ token: string; user: UserSession }>('/api/auth/employee/login', {
          method: 'POST',
          body: JSON.stringify({ employee_id: empId, pin: '1234' }),
        });
        setSession(res.token, res.user);
        setCurrentUser(res.user);
        setIsAuthOpen(false);
      } else if (role === 'CUSTOMER') {
        // Customer login via quick-switch with graceful fallback
        try {
          const res = await apiRequest<{ token: string; user: UserSession }>('/api/auth/customer/quick-switch', {
            method: 'POST',
          });
          setSession(res.token, res.user);
          setCurrentUser(res.user);
          setIsAuthOpen(false);
        } catch {
          const res = await apiRequest<{ token: string; user: UserSession }>('/api/auth/customer/login', {
            method: 'POST',
            body: JSON.stringify({
              mobile: '9876543220',
              otp: '1234',
              name: 'Ramesh Patel',
              address: 'Flat 402, Shivam Enclave',
            }),
          });
          setSession(res.token, res.user);
          setCurrentUser(res.user);
          setIsAuthOpen(false);
        }
      } else if (role === 'ADMIN') {
        const res = await apiRequest<{ token: string; user: UserSession }>('/api/auth/admin/login', {
          method: 'POST',
          body: JSON.stringify({ email: 'admin@dudhwala.com', password: 'admin123' }),
        });
        setSession(res.token, res.user);
        setCurrentUser(res.user);
        setIsAuthOpen(false);
      }
    } catch (err: any) {
      console.error('Quick switch failed:', err);
      setIsAuthOpen(true);
    }
  };

  if (!initialized) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F1F5F9] text-slate-800 flex flex-col font-['Plus_Jakarta_Sans'] antialiased">
      {/* Universal Header */}
      <Header
        user={currentUser}
        onLogout={handleLogout}
        onSwitchRole={() => setIsAuthOpen(true)}
        activeRole={currentUser?.role}
      />

      {/* Progressive Web App Install Promotion Bar */}
      <PWAInstallBanner />

      {/* Main View Area */}
      <main className="flex-1 pb-24 md:pb-20">
        {!currentUser || isAuthOpen ? (
          <AuthView onLoginSuccess={handleLoginSuccess} />
        ) : currentUser.role === 'EMPLOYEE' ? (
          <EmployeeView user={currentUser} />
        ) : currentUser.role === 'CUSTOMER' ? (
          <CustomerView user={currentUser} />
        ) : currentUser.role === 'ADMIN' ? (
          <AdminView user={currentUser} />
        ) : (
          <AuthView onLoginSuccess={handleLoginSuccess} />
        )}
      </main>

      {/* Device Adaptation, Sync & Offline Backup Bar */}
      <DeviceAdaptiveBar />

      {/* Quick Role Switcher Floating Dock */}
      {currentUser && !isAuthOpen && (
        <aside aria-label="Role Switcher Dock" className="fixed bottom-12 left-1/2 -translate-x-1/2 z-40 bg-slate-900/95 backdrop-blur-md text-white px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-full shadow-2xl border border-slate-700/60 flex items-center gap-1.5 sm:gap-2 text-xs max-w-[95vw] overflow-x-auto no-print">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1 hidden sm:inline whitespace-nowrap">
            Switch:
          </span>

          <button
            onClick={() => handleQuickSwitch('EMPLOYEE', 'emp-shivram')}
            className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-[11px] font-bold transition-all flex items-center gap-1 sm:gap-1.5 whitespace-nowrap shrink-0 ${
              currentUser.role === 'EMPLOYEE' && currentUser.id === 'emp-shivram'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30'
                : 'hover:bg-white/10 text-slate-300'
            }`}
          >
            <Truck className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            <span>Shivram</span>
          </button>

          <button
            onClick={() => handleQuickSwitch('EMPLOYEE', 'emp-samar')}
            className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-[11px] font-bold transition-all hidden md:flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
              currentUser.role === 'EMPLOYEE' && currentUser.id === 'emp-samar'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30'
                : 'hover:bg-white/10 text-slate-300'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            <span>Samar</span>
          </button>

          <button
            onClick={() => handleQuickSwitch('CUSTOMER')}
            className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-[11px] font-bold transition-all flex items-center gap-1 sm:gap-1.5 whitespace-nowrap shrink-0 ${
              currentUser.role === 'CUSTOMER'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-500/30'
                : 'hover:bg-white/10 text-slate-300'
            }`}
          >
            <User className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            <span>Customer</span>
          </button>

          <button
            onClick={() => handleQuickSwitch('ADMIN')}
            className={`px-2.5 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-[11px] font-bold transition-all flex items-center gap-1 sm:gap-1.5 whitespace-nowrap shrink-0 ${
              currentUser.role === 'ADMIN'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30'
                : 'hover:bg-white/10 text-slate-300'
            }`}
          >
            <Shield className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            <span>Admin</span>
          </button>
        </aside>
      )}
    </div>
  );
}

``

#### Source File: src/components/Header.tsx
``tsx
import React, { useState, useEffect } from 'react';
import { Milk, Shield, User, Truck, LogOut, Download, RefreshCw, Smartphone, Laptop, Tablet } from 'lucide-react';
import { UserSession } from '../types.ts';
import { usePWAInstall } from '../hooks/usePWAInstall.ts';
import { useDeviceType } from '../hooks/useDeviceType.ts';

interface HeaderProps {
  user: UserSession | null;
  onLogout: () => void;
  onSwitchRole: () => void;
  activeRole?: string;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  onLogout,
  onSwitchRole,
  activeRole,
}) => {
  const { canInstall, isInstalled, promptInstall, isOnline } = usePWAInstall();
  const { deviceType, isDesktop, isMobile } = useDeviceType();
  const [currentTime, setCurrentTime] = useState<string>(() => {
    return new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }));
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const getRoleBadge = (role?: string) => {
    switch (role) {
      case 'ADMIN':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
            <Shield className="w-3 h-3" /> Admin
          </span>
        );
      case 'EMPLOYEE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <Truck className="w-3 h-3" /> Delivery Partner
          </span>
        );
      case 'CUSTOMER':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
            <User className="w-3 h-3" /> Customer
          </span>
        );
      default:
        return null;
    }
  };

  const getInitials = (name?: string, role?: string) => {
    if (!name) return role ? role[0] : 'D';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return name.slice(0, 2).toUpperCase();
  };

  const todayFormatted = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  return (
    <header className="sticky top-0 z-40 h-20 bg-white border-b border-slate-200 shadow-xs flex items-center justify-between px-4 sm:px-8 no-print">
      <div className="w-full max-w-7xl mx-auto flex items-center justify-between">
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-3 sm:gap-4">
          <div className="w-11 h-11 sm:w-12 sm:h-12 bg-blue-600 rounded-xl sm:rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-200">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="w-6 h-6 sm:w-7 sm:h-7"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"
              />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black tracking-tighter text-blue-900 font-['Outfit']">
                Dudhwala
              </h1>
              <span className="hidden sm:inline-block text-[9px] font-bold uppercase tracking-widest bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full border border-blue-200">
                PRO
              </span>
            </div>
            <p className="text-[10px] sm:text-xs font-semibold text-slate-400 uppercase tracking-widest">
              {user?.role === 'ADMIN'
                ? 'Admin Command Center'
                : user?.role === 'EMPLOYEE'
                ? 'Delivery Partner Portal'
                : user?.role === 'CUSTOMER'
                ? 'Customer Milk Portal'
                : 'Milk Logistics Platform'}
            </p>
          </div>
        </div>

        {/* Center/Right Shift Date Tracker & User Actions */}
        <div className="flex items-center gap-3 sm:gap-6">
          {/* Shift Time Badge */}
          <div className="hidden lg:block text-right">
            <p className="text-xs font-bold text-slate-700">Daily Operations</p>
            <p className="text-[11px] text-slate-500 font-medium">
              {todayFormatted} â€¢ {currentTime}
            </p>
          </div>

          {/* PWA Install Button */}
          {canInstall && !isInstalled && (
            <button
              id="btn-header-install-pwa"
              onClick={() => promptInstall()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white transition-all shadow-xs hover:scale-105 active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isDesktop ? 'Install App' : 'Add to Home Screen'}</span>
            </button>
          )}

          {user ? (
            <div className="flex items-center gap-3">
              <div className="flex flex-col items-end">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-slate-800 hidden sm:inline">
                    {user.name}
                  </span>
                  {getRoleBadge(user.role)}
                </div>
                {user.mobile && (
                  <span className="text-[11px] text-slate-400 font-mono hidden md:inline">
                    +91 {user.mobile}
                  </span>
                )}
              </div>

              {/* Avatar Pill */}
              <div
                title={user.name}
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-blue-100 border-2 border-blue-600 flex items-center justify-center text-blue-700 font-black text-xs sm:text-sm shadow-xs"
              >
                {getInitials(user.name, user.role)}
              </div>

              {/* Switch Role Button */}
              <button
                id="btn-switch-role"
                onClick={onSwitchRole}
                title="Switch Role / View Other Portals"
                className="p-2 sm:px-3 sm:py-2 text-xs font-bold text-slate-700 hover:text-blue-600 bg-slate-100 hover:bg-blue-50 rounded-xl border border-slate-200 transition-colors flex items-center gap-1.5 shadow-xs"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Switch Role</span>
              </button>

              {/* Logout Button */}
              <button
                id="btn-logout"
                onClick={onLogout}
                title="Log Out"
                className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors border border-transparent hover:border-rose-200"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              id="btn-nav-login"
              onClick={onSwitchRole}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md shadow-blue-500/20 transition-all hover:scale-105"
            >
              <User className="w-4 h-4" />
              Login / Switch User
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

``

